﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Data.SqlClient;
using System.Configuration;
namespace UploadGrade
{
    public partial class Form1 : Form
    {
        string con = ConfigurationManager.ConnectionStrings["Education"].ToString();
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            TcpClient tc = new TcpClient();

            if ((textBox1.Text == "") && (textBox2.Text == ""))
            {
                MessageBox.Show("UserName and Password cannot be Empty! Please Enter the Correct Value to the Provided space", "SRMS Applications", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if ((string.IsNullOrWhiteSpace(textBox1.Text)) && (string.IsNullOrWhiteSpace(textBox2.Text)))
            {
                MessageBox.Show("whitespace cannot be considered as a username or password!", "SRMS Applications", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                using (SqlConnection conn = new SqlConnection(con))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT * FROM Education.dbo.Employee", conn);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        if ((this.textBox1.Text == dr["UserName"].ToString()) && (this.textBox2.Text == dr["Password"].ToString()))
                        {

                            Form f2 = new Form2();
                            f2.Text = "Student Record Management System-" + this.textBox1.Text;
                            f2.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("INVALID");
                        }
                    }
                }
            }
        }
    }
}