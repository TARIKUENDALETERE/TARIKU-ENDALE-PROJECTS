﻿namespace UploadGrade
    {
    partial class DepartmentHead
        {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose ( bool disposing )
            {
            if (disposing && (components != null))
                {
                components.Dispose ( );
                }
            base.Dispose ( disposing );
            }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent ( )
            {
            DevExpress.XtraEditors.TileItemElement tileItemElement1 = new DevExpress.XtraEditors.TileItemElement ( );
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager ( typeof ( DepartmentHead ) );
            this.tileNavCategory1 = new DevExpress.XtraBars.Navigation.TileNavCategory ( );
            this.tileBarItem2 = new DevExpress.XtraBars.Navigation.TileBarItem ( );
            this.statusStrip1 = new System.Windows.Forms.StatusStrip ( );
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel ( );
            this.formAssistant1 = new DevExpress.XtraBars.FormAssistant ( );
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl ( );
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage ( );
            this.toolStrip1 = new System.Windows.Forms.ToolStrip ( );
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton ( );
            this.registerInstructorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem ( );
            this.assignCourseToSemesterForRegistrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem ( );
            this.statusStrip1.SuspendLayout ( );
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit ( );
            this.toolStrip1.SuspendLayout ( );
            this.SuspendLayout ( );
            // 
            // tileNavCategory1
            // 
            this.tileNavCategory1.Name = "tileNavCategory1";
            this.tileNavCategory1.OwnerCollection = null;
            // 
            // 
            // 
            this.tileNavCategory1.Tile.DropDownOptions.BeakColor = System.Drawing.Color.Empty;
            // 
            // tileBarItem2
            // 
            this.tileBarItem2.DropDownOptions.BeakColor = System.Drawing.Color.Empty;
            tileItemElement1.Text = "tileNavCategory3";
            this.tileBarItem2.Elements.Add ( tileItemElement1 );
            this.tileBarItem2.Name = "tileBarItem2";
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.FromArgb ( ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))) );
            this.statusStrip1.Font = new System.Drawing.Font ( "Times New Roman", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)) );
            this.statusStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.statusStrip1.Items.AddRange ( new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1} );
            this.statusStrip1.Location = new System.Drawing.Point ( 0, 675 );
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size ( 1284, 22 );
            this.statusStrip1.TabIndex = 8;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BackColor = System.Drawing.Color.FromArgb ( ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))) );
            this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.Cornsilk;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size ( 687, 17 );
            this.toolStripStatusLabel1.Text = "Student Record Management System Dashboard:  Developed By: Tariku Endale.   Email" +
                ": tendalet2016@gmail.com   Mobile: +251920822030";
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ApplicationButtonDropDownControl = this.statusStrip1;
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange ( new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem} );
            this.ribbonControl1.Location = new System.Drawing.Point ( 0, 0 );
            this.ribbonControl1.MaxItemId = 1;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Size = new System.Drawing.Size ( 1284, 49 );
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "ribbonPage2";
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.DarkOrange;
            this.toolStrip1.Font = new System.Drawing.Font ( "Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)) );
            this.toolStrip1.Items.AddRange ( new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1} );
            this.toolStrip1.Location = new System.Drawing.Point ( 0, 49 );
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size ( 1284, 26 );
            this.toolStrip1.TabIndex = 10;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler ( this.toolStrip1_ItemClicked );
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton1.DropDownItems.AddRange ( new System.Windows.Forms.ToolStripItem[] {
            this.registerInstructorToolStripMenuItem,
            this.assignCourseToSemesterForRegistrationToolStripMenuItem} );
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject ( "toolStripDropDownButton1.Image" )));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size ( 68, 23 );
            this.toolStripDropDownButton1.Text = "Actions";
            // 
            // registerInstructorToolStripMenuItem
            // 
            this.registerInstructorToolStripMenuItem.Checked = true;
            this.registerInstructorToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.registerInstructorToolStripMenuItem.Name = "registerInstructorToolStripMenuItem";
            this.registerInstructorToolStripMenuItem.Size = new System.Drawing.Size ( 338, 24 );
            this.registerInstructorToolStripMenuItem.Text = "Register Instructor";
            // 
            // assignCourseToSemesterForRegistrationToolStripMenuItem
            // 
            this.assignCourseToSemesterForRegistrationToolStripMenuItem.Checked = true;
            this.assignCourseToSemesterForRegistrationToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.assignCourseToSemesterForRegistrationToolStripMenuItem.Name = "assignCourseToSemesterForRegistrationToolStripMenuItem";
            this.assignCourseToSemesterForRegistrationToolStripMenuItem.Size = new System.Drawing.Size ( 338, 24 );
            this.assignCourseToSemesterForRegistrationToolStripMenuItem.Text = "Assign Course to Semester for Registration";
            this.assignCourseToSemesterForRegistrationToolStripMenuItem.Click += new System.EventHandler ( this.assignCourseToSemesterForRegistrationToolStripMenuItem_Click );
            // 
            // DepartmentHead
            // 
            this.AllowFormGlass = DevExpress.Utils.DefaultBoolean.False;
            this.AutoScaleDimensions = new System.Drawing.SizeF ( 6F, 13F );
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size ( 1284, 697 );
            this.Controls.Add ( this.toolStrip1 );
            this.Controls.Add ( this.statusStrip1 );
            this.Controls.Add ( this.ribbonControl1 );
            this.Name = "DepartmentHead";
            this.Ribbon = this.ribbonControl1;
            this.ShowIcon = false;
            this.Text = "Instructor Grade Uploading Pad";
            this.statusStrip1.ResumeLayout ( false );
            this.statusStrip1.PerformLayout ( );
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit ( );
            this.toolStrip1.ResumeLayout ( false );
            this.toolStrip1.PerformLayout ( );
            this.ResumeLayout ( false );
            this.PerformLayout ( );

            }

        #endregion

        private DevExpress.XtraBars.Navigation.TileNavCategory tileNavCategory1;
        private DevExpress.XtraBars.Navigation.TileBarItem tileBarItem2;
        public System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private DevExpress.XtraBars.FormAssistant formAssistant1;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem registerInstructorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem assignCourseToSemesterForRegistrationToolStripMenuItem;

        }
    }