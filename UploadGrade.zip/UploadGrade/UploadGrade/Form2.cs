﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Microsoft.Runtime.Hosting;
using Microsoft.CSharp.RuntimeBinder;

namespace UploadGrade
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        //DataTableCollection tablecollection;
        private void button3_Click(object sender, EventArgs e)
        {
          
            using(OpenFileDialog ofd=new OpenFileDialog() { Filter="Excel 97-2003 workbook|*.xls|Excel Workbook|*.xlsx"})
            {
               /* if(ofd.ShowDialog()==DialogResult.OK)
                {
                    txtFile.Text = ofd.FileName;
                    using(var stream= File.Open(ofd.FileName, FileMode.Open, FileAccess.Read))
                    {
                        using (IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream))
                        {
                            DataSet result = reader.AsDataSet(new ExcelDataSetConfiguration()

                            { 
                                ConfigureDataTable = (_) => new ExcelDataTableConfiguration() { UseHeaderRow = true }
                               } );
                            tablecollection = result.Tables;
                            cbosheet.Items.Clear();
                            foreach (DataTable table in tablecollection)
                                cbosheet.Items.Add(table.TableName);
                            
                        }
                    }
                }  */
            }
            
              try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.ShowDialog();
                int importedrecord = 0;
                int invaliditem = 0;
                string sourceURI = "";
                if (dialog.FileName != "")
                {
                    if (dialog.FileName.EndsWith(".csv"))
                    {
                        DataTable dt = new DataTable();
                        dt = GetDataTabletFromCSVFile(dialog.FileName);
                        if (Convert.ToString(dt.Columns[0]).ToLower() != "STUID")
                        {
                            MessageBox.Show( "Invalid File Format","SRMS Registrar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            button3.Enabled = true;
                            return;
                        }
                        txtFile.Text = dialog.SafeFileName;
                        sourceURI = dialog.FileName;
                        if (dt.Rows != null && dt.Rows.ToString() != string.Empty)
                        {
                            dataGridView1.DataSource = dt;
                        }
                        foreach (DataGridViewRow row in dataGridView1.Rows)
                        {
                              if (Convert.ToString(row.Cells["STUID"].Value) == "" || row.Cells["STUID"].Value == null
                                || Convert.ToString(row.Cells["CCode"].Value) == "" || row.Cells["CCode"].Value == null
                                || Convert.ToString(row.Cells["IID"].Value) == "" || row.Cells["IID"].Value == null
                                || Convert.ToString(row.Cells["Chrs"].Value) == "" || row.Cells["Chrs"].Value == null
                                || Convert.ToString(row.Cells["Semester"].Value) == "" || row.Cells["Semester"].Value == null
                                || Convert.ToString(row.Cells["Midtest"].Value) == "" || row.Cells["Midtest"].Value == null
                                || Convert.ToString(row.Cells["Midtest1"].Value) == "" || row.Cells["Midtest1"].Value == null
                                || Convert.ToString(row.Cells["Assignment"].Value) == "" || row.Cells["Assignment"].Value == null
                                || Convert.ToString(row.Cells["Assignment1"].Value) == "" || row.Cells["Assignment1"].Value == null
                                || Convert.ToString(row.Cells["Labtest"].Value) == "" || row.Cells["Labtest"].Value == null
                                || Convert.ToString(row.Cells["Labtest1"].Value) == "" || row.Cells["Labtest1"].Value == null
                                || Convert.ToString(row.Cells["Project"].Value) == "" || row.Cells["Project"].Value == null
                                || Convert.ToString(row.Cells["Final"].Value) == "" || row.Cells["Final"].Value == null
                                || Convert.ToString(row.Cells["Remarks"].Value) == "" || row.Cells["Remarks"].Value == null)
                            {
                                row.DefaultCellStyle.BackColor = Color.Red;
                                invaliditem += 1;
                            }
                            else
                            {
                                importedrecord += 1;
                            }
                        }
                        if (dataGridView1.Rows.Count == 0)
                        {
                            button2.Enabled = false;
                            MessageBox.Show("There is no data in this file!", "SRMS Registrar", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        MessageBox.Show("You Selected an Invalid File!", "SRMS Registrar", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Error!", "SRMS Registrar" + ex);
            }
        }
        private DataTable GetDataTabletFromCSVFile(string p)
        {
            DataTable csvData = new DataTable();
            try
            {
                if (p.EndsWith(".csv"))
                {
                    using (Microsoft.VisualBasic.FileIO.TextFieldParser csvReader = new Microsoft.VisualBasic.FileIO.TextFieldParser(p))
                    {
                        csvReader.SetDelimiters(new string[] { "," });
                        csvReader.HasFieldsEnclosedInQuotes = true;
                        string[] colfields = csvReader.ReadFields();
                        foreach (string column in colfields)
                        {
                            DataColumn dc = new DataColumn(column);
                            dc.AllowDBNull = true;
                            csvData.Columns.Add(dc);
                        }
                        while (!csvReader.EndOfData)
                        {
                            string[] fieldData = csvReader.ReadFields();
                            for (int i = 0; i < fieldData.Length; i++)
                            {
                                if (fieldData[i] == "")
                                {
                                    fieldData[i] = null;
                                }
                            }
                            csvData.Rows.Add(fieldData);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Message:" + ex, "SRMS Registrar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return csvData;

        }
          
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void departmentHeadToolStripMenuItem_Click ( object sender, EventArgs e )
            {
            
            }

    }
}