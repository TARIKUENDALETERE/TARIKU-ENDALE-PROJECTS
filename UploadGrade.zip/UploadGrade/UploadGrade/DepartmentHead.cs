﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace UploadGrade
    {
    public partial class DepartmentHead : DevExpress.XtraBars.Ribbon.RibbonForm
        {
        public DepartmentHead ( )
            {
            InitializeComponent ( );
            }

        private void toolStrip1_ItemClicked ( object sender, ToolStripItemClickedEventArgs e )
            {

            }

        private void assignCourseToSemesterForRegistrationToolStripMenuItem_Click ( object sender, EventArgs e )
            {
            Form3 f3 = new Form3 ( );
            f3.Show ( );
            }
        }
    }