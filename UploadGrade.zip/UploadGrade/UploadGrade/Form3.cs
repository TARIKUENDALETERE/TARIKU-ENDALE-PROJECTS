﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace UploadGrade
{
    public partial class Form3 : Form
    {
        string con = ConfigurationManager.ConnectionStrings["Education"].ToString ( );
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load ( object sender, EventArgs e )
            {
            using (SqlConnection conn = new SqlConnection ( con ))
                {
                SqlDataAdapter sda = new SqlDataAdapter ( "SELECT Name FROM Education.dbo.Department", conn );
                DataTable dt = new DataTable ( );
                sda.Fill ( dt );
                foreach (DataRow dr in dt.Rows)
                    {
                    dep.Items.Add ( dr["Name"].ToString ( ) );
                    }
                }
            
            using (SqlConnection conn = new SqlConnection ( con ))
                {
                conn.Open ( );
                SqlCommand cmd = new SqlCommand ( "select * from Education.dbo.classyear", conn );
                SqlDataAdapter sad = new SqlDataAdapter ( cmd );
                DataTable dt = new DataTable ( );
                sad.Fill ( dt );
                SqlDataReader dr = cmd.ExecuteReader ( );
                while (dr.Read ( ))
                    {
                    // Label2.Text = dr["Maqaa"].ToString();
                    year.Items.Add ( dr["cyear"].ToString ( ) );
                    //Label3.Text = "Contact Details:  Tele: " + dr["Telephone"].ToString();
                    }
                }
            using (SqlConnection conn = new SqlConnection ( con ))
                {
                conn.Open ( );
                SqlCommand cmd = new SqlCommand ( "select * from Education.dbo.Semester", conn );
                SqlDataAdapter sad = new SqlDataAdapter ( cmd );
                DataTable dt = new DataTable ( );
                sad.Fill ( dt );
                SqlDataReader dr = cmd.ExecuteReader ( );
                while (dr.Read ( ))
                    {
                    // Label2.Text = dr["Maqaa"].ToString();
                    sem.Items.Add ( dr["Semester"].ToString ( ) );
                    //Label3.Text = "Contact Details:  Tele: " + dr["Telephone"].ToString();
                    }
                }
            
            }
    }
}
