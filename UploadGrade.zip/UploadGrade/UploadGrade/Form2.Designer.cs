﻿namespace UploadGrade
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager ( typeof ( Form2 ) );
        this.toolStrip1 = new System.Windows.Forms.ToolStrip ( );
        this.statusStrip1 = new System.Windows.Forms.StatusStrip ( );
        this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel ( );
        this.panel1 = new System.Windows.Forms.Panel ( );
        this.label2 = new System.Windows.Forms.Label ( );
        this.cbosheet = new System.Windows.Forms.ComboBox ( );
        this.txtFile = new System.Windows.Forms.TextBox ( );
        this.label1 = new System.Windows.Forms.Label ( );
        this.button3 = new System.Windows.Forms.Button ( );
        this.button2 = new System.Windows.Forms.Button ( );
        this.button1 = new System.Windows.Forms.Button ( );
        this.dataGridView1 = new System.Windows.Forms.DataGridView ( );
        this.STUID = new System.Windows.Forms.DataGridViewTextBoxColumn ( );
        this.CCode = new System.Windows.Forms.DataGridViewTextBoxColumn ( );
        this.IID = new System.Windows.Forms.DataGridViewTextBoxColumn ( );
        this.Chrs = new System.Windows.Forms.DataGridViewTextBoxColumn ( );
        this.Semester = new System.Windows.Forms.DataGridViewTextBoxColumn ( );
        this.Midtest = new System.Windows.Forms.DataGridViewTextBoxColumn ( );
        this.Midtest1 = new System.Windows.Forms.DataGridViewTextBoxColumn ( );
        this.Assignment = new System.Windows.Forms.DataGridViewTextBoxColumn ( );
        this.Assignment1 = new System.Windows.Forms.DataGridViewTextBoxColumn ( );
        this.Labtest = new System.Windows.Forms.DataGridViewTextBoxColumn ( );
        this.Labtest1 = new System.Windows.Forms.DataGridViewTextBoxColumn ( );
        this.Project = new System.Windows.Forms.DataGridViewTextBoxColumn ( );
        this.Final = new System.Windows.Forms.DataGridViewTextBoxColumn ( );
        this.Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn ( );
        this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton ( );
        this.departmentHeadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem ( );
        this.toolStrip1.SuspendLayout ( );
        this.statusStrip1.SuspendLayout ( );
        this.panel1.SuspendLayout ( );
        ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit ( );
        this.SuspendLayout ( );
        // 
        // toolStrip1
        // 
        this.toolStrip1.BackColor = System.Drawing.Color.OrangeRed;
        this.toolStrip1.Font = new System.Drawing.Font ( "Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)) );
        this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
        this.toolStrip1.Items.AddRange ( new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1} );
        this.toolStrip1.Location = new System.Drawing.Point ( 10, 10 );
        this.toolStrip1.Name = "toolStrip1";
        this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
        this.toolStrip1.Size = new System.Drawing.Size ( 1264, 25 );
        this.toolStrip1.TabIndex = 0;
        this.toolStrip1.Text = "toolStrip1";
        // 
        // statusStrip1
        // 
        this.statusStrip1.BackColor = System.Drawing.Color.FromArgb ( ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))) );
        this.statusStrip1.Font = new System.Drawing.Font ( "Times New Roman", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)) );
        this.statusStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
        this.statusStrip1.Items.AddRange ( new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1} );
        this.statusStrip1.Location = new System.Drawing.Point ( 10, 669 );
        this.statusStrip1.Name = "statusStrip1";
        this.statusStrip1.Size = new System.Drawing.Size ( 1264, 22 );
        this.statusStrip1.TabIndex = 7;
        this.statusStrip1.Text = "statusStrip1";
        // 
        // toolStripStatusLabel1
        // 
        this.toolStripStatusLabel1.BackColor = System.Drawing.Color.FromArgb ( ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))) );
        this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.Cornsilk;
        this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
        this.toolStripStatusLabel1.Size = new System.Drawing.Size ( 687, 17 );
        this.toolStripStatusLabel1.Text = "Student Record Management System Dashboard:  Developed By: Tariku Endale.   Email" +
            ": tendalet2016@gmail.com   Mobile: +251920822030";
        // 
        // panel1
        // 
        this.panel1.Controls.Add ( this.label2 );
        this.panel1.Controls.Add ( this.cbosheet );
        this.panel1.Controls.Add ( this.txtFile );
        this.panel1.Controls.Add ( this.label1 );
        this.panel1.Controls.Add ( this.button3 );
        this.panel1.Controls.Add ( this.button2 );
        this.panel1.Controls.Add ( this.button1 );
        this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
        this.panel1.ForeColor = System.Drawing.Color.Coral;
        this.panel1.Location = new System.Drawing.Point ( 10, 35 );
        this.panel1.Name = "panel1";
        this.panel1.Size = new System.Drawing.Size ( 1264, 40 );
        this.panel1.TabIndex = 8;
        // 
        // label2
        // 
        this.label2.AutoSize = true;
        this.label2.ForeColor = System.Drawing.Color.FromArgb ( ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))) );
        this.label2.Location = new System.Drawing.Point ( 487, 10 );
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size ( 81, 17 );
        this.label2.TabIndex = 6;
        this.label2.Text = "Select Sheet";
        // 
        // cbosheet
        // 
        this.cbosheet.FormattingEnabled = true;
        this.cbosheet.Location = new System.Drawing.Point ( 581, 7 );
        this.cbosheet.Name = "cbosheet";
        this.cbosheet.Size = new System.Drawing.Size ( 121, 25 );
        this.cbosheet.TabIndex = 5;
        // 
        // txtFile
        // 
        this.txtFile.Location = new System.Drawing.Point ( 129, 7 );
        this.txtFile.Name = "txtFile";
        this.txtFile.Size = new System.Drawing.Size ( 271, 25 );
        this.txtFile.TabIndex = 4;
        // 
        // label1
        // 
        this.label1.AutoSize = true;
        this.label1.ForeColor = System.Drawing.Color.FromArgb ( ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))) );
        this.label1.Location = new System.Drawing.Point ( 4, 10 );
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size ( 119, 17 );
        this.label1.TabIndex = 3;
        this.label1.Text = "Browse Excel File:";
        // 
        // button3
        // 
        this.button3.BackColor = System.Drawing.Color.FromArgb ( ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))) );
        this.button3.Font = new System.Drawing.Font ( "Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)) );
        this.button3.Location = new System.Drawing.Point ( 406, 3 );
        this.button3.Name = "button3";
        this.button3.Size = new System.Drawing.Size ( 75, 32 );
        this.button3.TabIndex = 2;
        this.button3.Text = "....";
        this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
        this.button3.UseVisualStyleBackColor = false;
        this.button3.Click += new System.EventHandler ( this.button3_Click );
        // 
        // button2
        // 
        this.button2.BackColor = System.Drawing.Color.Navy;
        this.button2.ForeColor = System.Drawing.Color.Cornsilk;
        this.button2.Location = new System.Drawing.Point ( 789, 2 );
        this.button2.Name = "button2";
        this.button2.Size = new System.Drawing.Size ( 75, 32 );
        this.button2.TabIndex = 1;
        this.button2.Text = "Show";
        this.button2.UseVisualStyleBackColor = false;
        this.button2.Click += new System.EventHandler ( this.button2_Click );
        // 
        // button1
        // 
        this.button1.BackColor = System.Drawing.Color.Navy;
        this.button1.ForeColor = System.Drawing.Color.Cornsilk;
        this.button1.Location = new System.Drawing.Point ( 708, 2 );
        this.button1.Name = "button1";
        this.button1.Size = new System.Drawing.Size ( 75, 32 );
        this.button1.TabIndex = 0;
        this.button1.Text = "Upload";
        this.button1.UseVisualStyleBackColor = false;
        this.button1.Click += new System.EventHandler ( this.button1_Click );
        // 
        // dataGridView1
        // 
        this.dataGridView1.BackgroundColor = System.Drawing.Color.Azure;
        this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        this.dataGridView1.Columns.AddRange ( new System.Windows.Forms.DataGridViewColumn[] {
            this.STUID,
            this.CCode,
            this.IID,
            this.Chrs,
            this.Semester,
            this.Midtest,
            this.Midtest1,
            this.Assignment,
            this.Assignment1,
            this.Labtest,
            this.Labtest1,
            this.Project,
            this.Final,
            this.Remarks} );
        this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
        this.dataGridView1.GridColor = System.Drawing.Color.Cornsilk;
        this.dataGridView1.Location = new System.Drawing.Point ( 10, 75 );
        this.dataGridView1.Name = "dataGridView1";
        this.dataGridView1.Size = new System.Drawing.Size ( 1264, 594 );
        this.dataGridView1.TabIndex = 9;
        // 
        // STUID
        // 
        this.STUID.DataPropertyName = "STUID";
        this.STUID.HeaderText = "STUID";
        this.STUID.Name = "STUID";
        // 
        // CCode
        // 
        this.CCode.DataPropertyName = "CCode";
        this.CCode.HeaderText = "CCode";
        this.CCode.Name = "CCode";
        // 
        // IID
        // 
        this.IID.DataPropertyName = "IID";
        this.IID.HeaderText = "IID";
        this.IID.Name = "IID";
        // 
        // Chrs
        // 
        this.Chrs.DataPropertyName = "Chrs";
        this.Chrs.HeaderText = "Chrs";
        this.Chrs.Name = "Chrs";
        // 
        // Semester
        // 
        this.Semester.DataPropertyName = "Semester";
        this.Semester.HeaderText = "Semester";
        this.Semester.Name = "Semester";
        // 
        // Midtest
        // 
        this.Midtest.DataPropertyName = "Midtest";
        this.Midtest.HeaderText = "Midtest";
        this.Midtest.Name = "Midtest";
        // 
        // Midtest1
        // 
        this.Midtest1.DataPropertyName = "Midtest1";
        this.Midtest1.HeaderText = "Midtest1";
        this.Midtest1.Name = "Midtest1";
        // 
        // Assignment
        // 
        this.Assignment.DataPropertyName = "Assignment";
        this.Assignment.HeaderText = "Assignment";
        this.Assignment.Name = "Assignment";
        // 
        // Assignment1
        // 
        this.Assignment1.DataPropertyName = "Assignment1";
        this.Assignment1.HeaderText = "Assignment1";
        this.Assignment1.Name = "Assignment1";
        // 
        // Labtest
        // 
        this.Labtest.DataPropertyName = "Labtest";
        this.Labtest.HeaderText = "Labtest";
        this.Labtest.Name = "Labtest";
        // 
        // Labtest1
        // 
        this.Labtest1.DataPropertyName = "Labtest1";
        this.Labtest1.HeaderText = "Labtest1";
        this.Labtest1.Name = "Labtest1";
        // 
        // Project
        // 
        this.Project.DataPropertyName = "Project";
        this.Project.HeaderText = "Project";
        this.Project.Name = "Project";
        // 
        // Final
        // 
        this.Final.DataPropertyName = "Final";
        this.Final.HeaderText = "Final";
        this.Final.Name = "Final";
        // 
        // Remarks
        // 
        this.Remarks.DataPropertyName = "Remarks";
        this.Remarks.HeaderText = "Remarks";
        this.Remarks.Name = "Remarks";
        // 
        // toolStripDropDownButton1
        // 
        this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
        this.toolStripDropDownButton1.DropDownItems.AddRange ( new System.Windows.Forms.ToolStripItem[] {
            this.departmentHeadToolStripMenuItem} );
        this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject ( "toolStripDropDownButton1.Image" )));
        this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
        this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
        this.toolStripDropDownButton1.Size = new System.Drawing.Size ( 29, 22 );
        this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
        // 
        // departmentHeadToolStripMenuItem
        // 
        this.departmentHeadToolStripMenuItem.Name = "departmentHeadToolStripMenuItem";
        this.departmentHeadToolStripMenuItem.Size = new System.Drawing.Size ( 186, 24 );
        this.departmentHeadToolStripMenuItem.Text = "Department Head";
        this.departmentHeadToolStripMenuItem.Click += new System.EventHandler ( this.departmentHeadToolStripMenuItem_Click );
        // 
        // Form2
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF ( 8F, 17F );
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.BackColor = System.Drawing.Color.MistyRose;
        this.ClientSize = new System.Drawing.Size ( 1284, 701 );
        this.Controls.Add ( this.dataGridView1 );
        this.Controls.Add ( this.panel1 );
        this.Controls.Add ( this.statusStrip1 );
        this.Controls.Add ( this.toolStrip1 );
        this.DoubleBuffered = true;
        this.Font = new System.Drawing.Font ( "Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)) );
        this.Icon = ((System.Drawing.Icon)(resources.GetObject ( "$this.Icon" )));
        this.Margin = new System.Windows.Forms.Padding ( 4 );
        this.MinimumSize = new System.Drawing.Size ( 16, 39 );
        this.Name = "Form2";
        this.Padding = new System.Windows.Forms.Padding ( 10 );
        this.Text = "Academic Staff Dashboard and Grade Uploading Portal";
        this.toolStrip1.ResumeLayout ( false );
        this.toolStrip1.PerformLayout ( );
        this.statusStrip1.ResumeLayout ( false );
        this.statusStrip1.PerformLayout ( );
        this.panel1.ResumeLayout ( false );
        this.panel1.PerformLayout ( );
        ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit ( );
        this.ResumeLayout ( false );
        this.PerformLayout ( );

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        public System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        public System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox txtFile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn STUID;
        private System.Windows.Forms.DataGridViewTextBoxColumn CCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn IID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Chrs;
        private System.Windows.Forms.DataGridViewTextBoxColumn Semester;
        private System.Windows.Forms.DataGridViewTextBoxColumn Midtest;
        private System.Windows.Forms.DataGridViewTextBoxColumn Midtest1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Assignment;
        private System.Windows.Forms.DataGridViewTextBoxColumn Assignment1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Labtest;
        private System.Windows.Forms.DataGridViewTextBoxColumn Labtest1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Project;
        private System.Windows.Forms.DataGridViewTextBoxColumn Final;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remarks;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbosheet;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem departmentHeadToolStripMenuItem;
    }
}