﻿namespace HRMSystem
{
    partial class dashboarddesigner
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dashboarddesigner));
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup1 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem1 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem2 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem3 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem4 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem5 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem6 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem7 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem8 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem9 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem10 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem11 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem12 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem13 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem14 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem15 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem16 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem17 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup2 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup3 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup4 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem18 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.Skins.SkinPaddingEdges skinPaddingEdges1 = new DevExpress.Skins.SkinPaddingEdges();
            DevExpress.DashboardWin.Bars.ChartInsideHorizontalLegendGalleryGroup chartInsideHorizontalLegendGalleryGroup1 = new DevExpress.DashboardWin.Bars.ChartInsideHorizontalLegendGalleryGroup();
            DevExpress.DashboardWin.Bars.ChartLegendInsideTopLeftHorizontalGalleryItem chartLegendInsideTopLeftHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendInsideTopLeftHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideTopCenterHorizontalGalleryItem chartLegendInsideTopCenterHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendInsideTopCenterHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideTopRightHorizontalGalleryItem chartLegendInsideTopRightHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendInsideTopRightHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideBottomLeftHorizontalGalleryItem chartLegendInsideBottomLeftHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendInsideBottomLeftHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideBottomCenterHorizontalGalleryItem chartLegendInsideBottomCenterHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendInsideBottomCenterHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideBottomRightHorizontalGalleryItem chartLegendInsideBottomRightHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendInsideBottomRightHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartInsideVerticalLegendGalleryGroup chartInsideVerticalLegendGalleryGroup1 = new DevExpress.DashboardWin.Bars.ChartInsideVerticalLegendGalleryGroup();
            DevExpress.DashboardWin.Bars.ChartLegendInsideTopLeftVerticalGalleryItem chartLegendInsideTopLeftVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendInsideTopLeftVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideTopCenterVerticalGalleryItem chartLegendInsideTopCenterVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendInsideTopCenterVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideTopRightVerticalGalleryItem chartLegendInsideTopRightVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendInsideTopRightVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideBottomLeftVerticalGalleryItem chartLegendInsideBottomLeftVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendInsideBottomLeftVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideBottomCenterVerticalGalleryItem chartLegendInsideBottomCenterVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendInsideBottomCenterVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideBottomRightVerticalGalleryItem chartLegendInsideBottomRightVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendInsideBottomRightVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartOutsideHorizontalLegendGalleryGroup chartOutsideHorizontalLegendGalleryGroup1 = new DevExpress.DashboardWin.Bars.ChartOutsideHorizontalLegendGalleryGroup();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideTopLeftHorizontalGalleryItem chartLegendOutsideTopLeftHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideTopLeftHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideTopCenterHorizontalGalleryItem chartLegendOutsideTopCenterHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideTopCenterHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideTopRightHorizontalGalleryItem chartLegendOutsideTopRightHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideTopRightHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomLeftHorizontalGalleryItem chartLegendOutsideBottomLeftHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomLeftHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomCenterHorizontalGalleryItem chartLegendOutsideBottomCenterHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomCenterHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomRightHorizontalGalleryItem chartLegendOutsideBottomRightHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomRightHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartOutsideVerticalLegendGalleryGroup chartOutsideVerticalLegendGalleryGroup1 = new DevExpress.DashboardWin.Bars.ChartOutsideVerticalLegendGalleryGroup();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideTopLeftVerticalGalleryItem chartLegendOutsideTopLeftVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideTopLeftVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideTopRightVerticalGalleryItem chartLegendOutsideTopRightVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideTopRightVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomLeftVerticalGalleryItem chartLegendOutsideBottomLeftVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomLeftVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomRightVerticalGalleryItem chartLegendOutsideBottomRightVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomRightVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartBarSeriesGalleryGroup chartBarSeriesGalleryGroup1 = new DevExpress.DashboardWin.Bars.ChartBarSeriesGalleryGroup();
            DevExpress.DashboardWin.Bars.ChartBarSeriesGalleryItem chartBarSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartBarSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartStackedBarSeriesGalleryItem chartStackedBarSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartStackedBarSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartFullStackedBarSeriesGalleryItem chartFullStackedBarSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartFullStackedBarSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartPointLineSeriesGalleryGroup chartPointLineSeriesGalleryGroup1 = new DevExpress.DashboardWin.Bars.ChartPointLineSeriesGalleryGroup();
            DevExpress.DashboardWin.Bars.ChartPointSeriesGalleryItem chartPointSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartPointSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLineSeriesGalleryItem chartLineSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartLineSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartStackedLineSeriesGalleryItem chartStackedLineSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartStackedLineSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartFullStackedLineSeriesGalleryItem chartFullStackedLineSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartFullStackedLineSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartStepLineSeriesGalleryItem chartStepLineSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartStepLineSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartSplineSeriesGalleryItem chartSplineSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartSplineSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartAreaSeriesGalleryGroup chartAreaSeriesGalleryGroup1 = new DevExpress.DashboardWin.Bars.ChartAreaSeriesGalleryGroup();
            DevExpress.DashboardWin.Bars.ChartAreaSeriesGalleryItem chartAreaSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartAreaSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartStackedAreaSeriesGalleryItem chartStackedAreaSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartStackedAreaSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartFullStackedAreaSeriesGalleryItem chartFullStackedAreaSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartFullStackedAreaSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartStepAreaSeriesGalleryItem chartStepAreaSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartStepAreaSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartSplineAreaSeriesGalleryItem chartSplineAreaSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartSplineAreaSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartStackedSplineAreaSeriesGalleryItem chartStackedSplineAreaSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartStackedSplineAreaSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartFullStackedSplineAreaSeriesGalleryItem chartFullStackedSplineAreaSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartFullStackedSplineAreaSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartRangeSeriesGalleryGroup chartRangeSeriesGalleryGroup1 = new DevExpress.DashboardWin.Bars.ChartRangeSeriesGalleryGroup();
            DevExpress.DashboardWin.Bars.ChartSideBySideRangeBarSeriesGalleryItem chartSideBySideRangeBarSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartSideBySideRangeBarSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartRangeAreaSeriesGalleryItem chartRangeAreaSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartRangeAreaSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartBubbleSeriesGalleryGroup chartBubbleSeriesGalleryGroup1 = new DevExpress.DashboardWin.Bars.ChartBubbleSeriesGalleryGroup();
            DevExpress.DashboardWin.Bars.ChartWeightedSeriesGalleryItem chartWeightedSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartWeightedSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartFinancialSeriesGalleryGroup chartFinancialSeriesGalleryGroup1 = new DevExpress.DashboardWin.Bars.ChartFinancialSeriesGalleryGroup();
            DevExpress.DashboardWin.Bars.ChartHighLowCloseSeriesGalleryItem chartHighLowCloseSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartHighLowCloseSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartCandleStickSeriesGalleryItem chartCandleStickSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartCandleStickSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartStockSeriesGalleryItem chartStockSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.ChartStockSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.ChartInsideHorizontalLegendGalleryGroup chartInsideHorizontalLegendGalleryGroup2 = new DevExpress.DashboardWin.Bars.ChartInsideHorizontalLegendGalleryGroup();
            DevExpress.DashboardWin.Bars.ChartLegendInsideTopLeftHorizontalGalleryItem chartLegendInsideTopLeftHorizontalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendInsideTopLeftHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideTopCenterHorizontalGalleryItem chartLegendInsideTopCenterHorizontalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendInsideTopCenterHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideTopRightHorizontalGalleryItem chartLegendInsideTopRightHorizontalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendInsideTopRightHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideBottomLeftHorizontalGalleryItem chartLegendInsideBottomLeftHorizontalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendInsideBottomLeftHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideBottomCenterHorizontalGalleryItem chartLegendInsideBottomCenterHorizontalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendInsideBottomCenterHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideBottomRightHorizontalGalleryItem chartLegendInsideBottomRightHorizontalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendInsideBottomRightHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartInsideVerticalLegendGalleryGroup chartInsideVerticalLegendGalleryGroup2 = new DevExpress.DashboardWin.Bars.ChartInsideVerticalLegendGalleryGroup();
            DevExpress.DashboardWin.Bars.ChartLegendInsideTopLeftVerticalGalleryItem chartLegendInsideTopLeftVerticalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendInsideTopLeftVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideTopCenterVerticalGalleryItem chartLegendInsideTopCenterVerticalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendInsideTopCenterVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideTopRightVerticalGalleryItem chartLegendInsideTopRightVerticalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendInsideTopRightVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideBottomLeftVerticalGalleryItem chartLegendInsideBottomLeftVerticalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendInsideBottomLeftVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideBottomCenterVerticalGalleryItem chartLegendInsideBottomCenterVerticalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendInsideBottomCenterVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendInsideBottomRightVerticalGalleryItem chartLegendInsideBottomRightVerticalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendInsideBottomRightVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartOutsideHorizontalLegendGalleryGroup chartOutsideHorizontalLegendGalleryGroup2 = new DevExpress.DashboardWin.Bars.ChartOutsideHorizontalLegendGalleryGroup();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideTopLeftHorizontalGalleryItem chartLegendOutsideTopLeftHorizontalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideTopLeftHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideTopCenterHorizontalGalleryItem chartLegendOutsideTopCenterHorizontalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideTopCenterHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideTopRightHorizontalGalleryItem chartLegendOutsideTopRightHorizontalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideTopRightHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomLeftHorizontalGalleryItem chartLegendOutsideBottomLeftHorizontalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomLeftHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomCenterHorizontalGalleryItem chartLegendOutsideBottomCenterHorizontalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomCenterHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomRightHorizontalGalleryItem chartLegendOutsideBottomRightHorizontalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomRightHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartOutsideVerticalLegendGalleryGroup chartOutsideVerticalLegendGalleryGroup2 = new DevExpress.DashboardWin.Bars.ChartOutsideVerticalLegendGalleryGroup();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideTopLeftVerticalGalleryItem chartLegendOutsideTopLeftVerticalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideTopLeftVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideTopRightVerticalGalleryItem chartLegendOutsideTopRightVerticalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideTopRightVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomLeftVerticalGalleryItem chartLegendOutsideBottomLeftVerticalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomLeftVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomRightVerticalGalleryItem chartLegendOutsideBottomRightVerticalGalleryItem2 = new DevExpress.DashboardWin.Bars.ChartLegendOutsideBottomRightVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.RangePointLineSeriesGalleryGroup rangePointLineSeriesGalleryGroup1 = new DevExpress.DashboardWin.Bars.RangePointLineSeriesGalleryGroup();
            DevExpress.DashboardWin.Bars.RangeLineSeriesGalleryItem rangeLineSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.RangeLineSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.RangeStackedLineSeriesGalleryItem rangeStackedLineSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.RangeStackedLineSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.RangeFullStackedLineSeriesGalleryItem rangeFullStackedLineSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.RangeFullStackedLineSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.RangeAreaSeriesGalleryGroup rangeAreaSeriesGalleryGroup1 = new DevExpress.DashboardWin.Bars.RangeAreaSeriesGalleryGroup();
            DevExpress.DashboardWin.Bars.RangeAreaSeriesGalleryItem rangeAreaSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.RangeAreaSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.RangeStackedAreaSeriesGalleryItem rangeStackedAreaSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.RangeStackedAreaSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.RangeFullStackedAreaSeriesGalleryItem rangeFullStackedAreaSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.RangeFullStackedAreaSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.RangeBarSeriesGalleryGroup rangeBarSeriesGalleryGroup1 = new DevExpress.DashboardWin.Bars.RangeBarSeriesGalleryGroup();
            DevExpress.DashboardWin.Bars.RangeBarSeriesGalleryItem rangeBarSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.RangeBarSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.RangeStackedBarSeriesGalleryItem rangeStackedBarSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.RangeStackedBarSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.RangeFullStackedBarSeriesGalleryItem rangeFullStackedBarSeriesGalleryItem1 = new DevExpress.DashboardWin.Bars.RangeFullStackedBarSeriesGalleryItem();
            DevExpress.DashboardWin.Bars.MapVerticalLegendGalleryGroup mapVerticalLegendGalleryGroup1 = new DevExpress.DashboardWin.Bars.MapVerticalLegendGalleryGroup();
            DevExpress.DashboardWin.Bars.MapLegendTopLeftVerticalGalleryItem mapLegendTopLeftVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.MapLegendTopLeftVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.MapLegendTopCenterVerticalGalleryItem mapLegendTopCenterVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.MapLegendTopCenterVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.MapLegendTopRightVerticalGalleryItem mapLegendTopRightVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.MapLegendTopRightVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.MapLegendBottomLeftVerticalGalleryItem mapLegendBottomLeftVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.MapLegendBottomLeftVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.MapLegendBottomCenterVerticalGalleryItem mapLegendBottomCenterVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.MapLegendBottomCenterVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.MapLegendBottomRightVerticalGalleryItem mapLegendBottomRightVerticalGalleryItem1 = new DevExpress.DashboardWin.Bars.MapLegendBottomRightVerticalGalleryItem();
            DevExpress.DashboardWin.Bars.MapHorizontalLegendGalleryGroup mapHorizontalLegendGalleryGroup1 = new DevExpress.DashboardWin.Bars.MapHorizontalLegendGalleryGroup();
            DevExpress.DashboardWin.Bars.MapLegendTopLeftHorizontalGalleryItem mapLegendTopLeftHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.MapLegendTopLeftHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.MapLegendTopCenterHorizontalGalleryItem mapLegendTopCenterHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.MapLegendTopCenterHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.MapLegendTopRightHorizontalGalleryItem mapLegendTopRightHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.MapLegendTopRightHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.MapLegendBottomLeftHorizontalGalleryItem mapLegendBottomLeftHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.MapLegendBottomLeftHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.MapLegendBottomCenterHorizontalGalleryItem mapLegendBottomCenterHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.MapLegendBottomCenterHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.MapLegendBottomRightHorizontalGalleryItem mapLegendBottomRightHorizontalGalleryItem1 = new DevExpress.DashboardWin.Bars.MapLegendBottomRightHorizontalGalleryItem();
            DevExpress.DashboardWin.Bars.MapWeightedLegendGalleryGroup mapWeightedLegendGalleryGroup1 = new DevExpress.DashboardWin.Bars.MapWeightedLegendGalleryGroup();
            DevExpress.DashboardWin.Bars.MapWeightedLegendTopLeftGalleryItem mapWeightedLegendTopLeftGalleryItem1 = new DevExpress.DashboardWin.Bars.MapWeightedLegendTopLeftGalleryItem();
            DevExpress.DashboardWin.Bars.MapWeightedLegendTopCenterGalleryItem mapWeightedLegendTopCenterGalleryItem1 = new DevExpress.DashboardWin.Bars.MapWeightedLegendTopCenterGalleryItem();
            DevExpress.DashboardWin.Bars.MapWeightedLegendTopRightGalleryItem mapWeightedLegendTopRightGalleryItem1 = new DevExpress.DashboardWin.Bars.MapWeightedLegendTopRightGalleryItem();
            DevExpress.DashboardWin.Bars.MapWeightedLegendBottomLeftGalleryItem mapWeightedLegendBottomLeftGalleryItem1 = new DevExpress.DashboardWin.Bars.MapWeightedLegendBottomLeftGalleryItem();
            DevExpress.DashboardWin.Bars.MapWeightedLegendBottomCenterGalleryItem mapWeightedLegendBottomCenterGalleryItem1 = new DevExpress.DashboardWin.Bars.MapWeightedLegendBottomCenterGalleryItem();
            DevExpress.DashboardWin.Bars.MapWeightedLegendBottomRightGalleryItem mapWeightedLegendBottomRightGalleryItem1 = new DevExpress.DashboardWin.Bars.MapWeightedLegendBottomRightGalleryItem();
            DevExpress.XtraBars.Ribbon.ReduceOperation reduceOperation1 = new DevExpress.XtraBars.Ribbon.ReduceOperation();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup5 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup6 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            this.dashboardDesigner1 = new DevExpress.DashboardWin.DashboardDesigner();
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.dashboardBackstageViewControl1 = new DevExpress.DashboardWin.Bars.DashboardBackstageViewControl();
            this.dashboardBackstageNewButton1 = new DevExpress.DashboardWin.Bars.DashboardBackstageNewButton();
            this.dashboardBackstageOpenButton1 = new DevExpress.DashboardWin.Bars.DashboardBackstageOpenButton();
            this.dashboardBackstageSaveButton1 = new DevExpress.DashboardWin.Bars.DashboardBackstageSaveButton();
            this.dashboardBackstageSaveAsButton1 = new DevExpress.DashboardWin.Bars.DashboardBackstageSaveAsButton();
            this.dashboardBackstageRecentTab1 = new DevExpress.DashboardWin.Bars.DashboardBackstageRecentTab();
            this.backstageViewClientControl1 = new DevExpress.XtraBars.Ribbon.BackstageViewClientControl();
            this.recentDashboardsControl1 = new DevExpress.DashboardWin.Bars.RecentDashboardsControl();
            this.dashboardBarAndDockingController1 = new DevExpress.DashboardWin.Native.DashboardBarAndDockingController(this.components);
            this.dashboardBarController1 = new DevExpress.DashboardWin.Bars.DashboardBarController(this.components);
            this.fileRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.FileRibbonPageGroup();
            this.homeRibbonPage1 = new DevExpress.DashboardWin.Bars.HomeRibbonPage();
            this.fileNewBarItem1 = new DevExpress.DashboardWin.Bars.FileNewBarItem();
            this.fileOpenBarItem1 = new DevExpress.DashboardWin.Bars.FileOpenBarItem();
            this.fileSaveBarItem1 = new DevExpress.DashboardWin.Bars.FileSaveBarItem();
            this.fileSaveAsBarItem1 = new DevExpress.DashboardWin.Bars.FileSaveAsBarItem();
            this.quickAccessHistoryRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.QuickAccessHistoryRibbonPageGroup();
            this.quickAccessUndoBarItem1 = new DevExpress.DashboardWin.Bars.QuickAccessUndoBarItem();
            this.quickAccessRedoBarItem1 = new DevExpress.DashboardWin.Bars.QuickAccessRedoBarItem();
            this.historyRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.HistoryRibbonPageGroup();
            this.undoBarItem1 = new DevExpress.DashboardWin.Bars.UndoBarItem();
            this.redoBarItem1 = new DevExpress.DashboardWin.Bars.RedoBarItem();
            this.insertRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.InsertRibbonPageGroup();
            this.insertPivotBarItem1 = new DevExpress.DashboardWin.Bars.InsertPivotBarItem();
            this.insertGridBarItem1 = new DevExpress.DashboardWin.Bars.InsertGridBarItem();
            this.insertChartBarItem1 = new DevExpress.DashboardWin.Bars.InsertChartBarItem();
            this.insertScatterChartBarItem1 = new DevExpress.DashboardWin.Bars.InsertScatterChartBarItem();
            this.insertPiesBarItem1 = new DevExpress.DashboardWin.Bars.InsertPiesBarItem();
            this.insertGaugesBarItem1 = new DevExpress.DashboardWin.Bars.InsertGaugesBarItem();
            this.insertCardsBarItem1 = new DevExpress.DashboardWin.Bars.InsertCardsBarItem();
            this.insertTreemapBarItem1 = new DevExpress.DashboardWin.Bars.InsertTreemapBarItem();
            this.insertChoroplethMapBarItem1 = new DevExpress.DashboardWin.Bars.InsertChoroplethMapBarItem();
            this.insertGeoPointMapBarSubItem1 = new DevExpress.DashboardWin.Bars.InsertGeoPointMapBarSubItem();
            this.insertGeoPointMapBarItem1 = new DevExpress.DashboardWin.Bars.InsertGeoPointMapBarItem();
            this.insertBubbleMapBarItem1 = new DevExpress.DashboardWin.Bars.InsertBubbleMapBarItem();
            this.insertPieMapBarItem1 = new DevExpress.DashboardWin.Bars.InsertPieMapBarItem();
            this.insertRangeFilterBarItem1 = new DevExpress.DashboardWin.Bars.InsertRangeFilterBarItem();
            this.insertFilterElementSubItem1 = new DevExpress.DashboardWin.Bars.InsertFilterElementSubItem();
            this.insertComboBoxBarItem1 = new DevExpress.DashboardWin.Bars.InsertComboBoxBarItem();
            this.insertListBoxBarItem1 = new DevExpress.DashboardWin.Bars.InsertListBoxBarItem();
            this.insertTreeViewBarItem1 = new DevExpress.DashboardWin.Bars.InsertTreeViewBarItem();
            this.insertImagesBarSubItem1 = new DevExpress.DashboardWin.Bars.InsertImagesBarSubItem();
            this.insertImageBarItem1 = new DevExpress.DashboardWin.Bars.InsertImageBarItem();
            this.insertBoundImageBarItem1 = new DevExpress.DashboardWin.Bars.InsertBoundImageBarItem();
            this.insertTextBoxBarItem1 = new DevExpress.DashboardWin.Bars.InsertTextBoxBarItem();
            this.insertGroupBarItem1 = new DevExpress.DashboardWin.Bars.InsertGroupBarItem();
            this.itemOperationRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.ItemOperationRibbonPageGroup();
            this.duplicateItemBarItem1 = new DevExpress.DashboardWin.Bars.DuplicateItemBarItem();
            this.deleteItemBarItem1 = new DevExpress.DashboardWin.Bars.DeleteItemBarItem();
            this.convertDashboardItemTypeBarItem1 = new DevExpress.DashboardWin.Bars.ConvertDashboardItemTypeBarItem();
            this.convertToPivotBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToPivotBarItem();
            this.convertToGridBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToGridBarItem();
            this.convertToChartBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToChartBarItem();
            this.convertToScatterChartBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToScatterChartBarItem();
            this.convertToPieBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToPieBarItem();
            this.convertToGaugeBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToGaugeBarItem();
            this.convertToCardBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToCardBarItem();
            this.convertToTreemapBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToTreemapBarItem();
            this.convertToChoroplethMapBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToChoroplethMapBarItem();
            this.convertGeoPointMapBaseBarItem1 = new DevExpress.DashboardWin.Bars.ConvertGeoPointMapBaseBarItem();
            this.convertToGeoPointMapBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToGeoPointMapBarItem();
            this.convertToBubbleMapBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToBubbleMapBarItem();
            this.convertToPieMapBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToPieMapBarItem();
            this.convertToRangeFilterBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToRangeFilterBarItem();
            this.convertToFilterElementsBaseBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToFilterElementsBaseBarItem();
            this.convertToComboBoxBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToComboBoxBarItem();
            this.convertToListBoxBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToListBoxBarItem();
            this.convertToTreeViewBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToTreeViewBarItem();
            this.convertToBoundImageBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToBoundImageBarItem();
            this.convertToTextBoxBarItem1 = new DevExpress.DashboardWin.Bars.ConvertToTextBoxBarItem();
            this.removeDataItemsBarItem1 = new DevExpress.DashboardWin.Bars.RemoveDataItemsBarItem();
            this.transposeItemBarItem1 = new DevExpress.DashboardWin.Bars.TransposeItemBarItem();
            this.editRulesBarItem1 = new DevExpress.DashboardWin.Bars.EditRulesBarItem();
            this.groupOperationRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.GroupOperationRibbonPageGroup();
            this.deleteGroupBarItem1 = new DevExpress.DashboardWin.Bars.DeleteGroupBarItem();
            this.dashboardDesignRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.DashboardDesignRibbonPageGroup();
            this.dashboardTitleBarItem1 = new DevExpress.DashboardWin.Bars.DashboardTitleBarItem();
            this.setCurrencyCultureBarItem1 = new DevExpress.DashboardWin.Bars.SetCurrencyCultureBarItem();
            this.dashboardColorSchemeBarItem1 = new DevExpress.DashboardWin.Bars.DashboardColorSchemeBarItem();
            this.dashboardParametersBarItem1 = new DevExpress.DashboardWin.Bars.DashboardParametersBarItem();
            this.dashboardAutomaticUpdatesBarItem1 = new DevExpress.DashboardWin.Bars.DashboardAutomaticUpdatesBarItem();
            this.updateDataBarItem1 = new DevExpress.DashboardWin.Bars.UpdateDataBarItem();
            this.dataSourceRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.DataSourceRibbonPageGroup();
            this.dataSourceRibbonPage1 = new DevExpress.DashboardWin.Bars.DataSourceRibbonPage();
            this.newDataSourceBarItem1 = new DevExpress.DashboardWin.Bars.NewDataSourceBarItem();
            this.editSqlConnectionBarItem1 = new DevExpress.DashboardWin.Bars.EditSqlConnectionBarItem();
            this.editOlapConnectionBarItem1 = new DevExpress.DashboardWin.Bars.EditOlapConnectionBarItem();
            this.editObjectDataSourceBarItem1 = new DevExpress.DashboardWin.Bars.EditObjectDataSourceBarItem();
            this.editExcelDataSourceBarItem1 = new DevExpress.DashboardWin.Bars.EditExcelDataSourceBarItem();
            this.editEFDataSourceBarItem1 = new DevExpress.DashboardWin.Bars.EditEFDataSourceBarItem();
            this.editExtractOptionsBarItem1 = new DevExpress.DashboardWin.Bars.EditExtractOptionsBarItem();
            this.renameDataSourceBarItem1 = new DevExpress.DashboardWin.Bars.RenameDataSourceBarItem();
            this.deleteDataSourceBarItem1 = new DevExpress.DashboardWin.Bars.DeleteDataSourceBarItem();
            this.serverModeBarItem1 = new DevExpress.DashboardWin.Bars.ServerModeBarItem();
            this.upateDataExtractBarItem1 = new DevExpress.DashboardWin.Bars.UpateDataExtractBarItem();
            this.addCalculatedFieldBarItem1 = new DevExpress.DashboardWin.Bars.AddCalculatedFieldBarItem();
            this.sqlDataSourceQueryRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.SqlDataSourceQueryRibbonPageGroup();
            this.addQueryBarItem1 = new DevExpress.DashboardWin.Bars.AddQueryBarItem();
            this.editQueryBarItem1 = new DevExpress.DashboardWin.Bars.EditQueryBarItem();
            this.renameQueryBarItem1 = new DevExpress.DashboardWin.Bars.RenameQueryBarItem();
            this.editQueryFilterBarItem1 = new DevExpress.DashboardWin.Bars.EditQueryFilterBarItem();
            this.deleteQueryBarItem1 = new DevExpress.DashboardWin.Bars.DeleteQueryBarItem();
            this.extractSourceRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.ExtractSourceRibbonPageGroup();
            this.editExtractSourceConnectionBarItem1 = new DevExpress.DashboardWin.Bars.EditExtractSourceConnectionBarItem();
            this.editExtractSourceBarItem1 = new DevExpress.DashboardWin.Bars.EditExtractSourceBarItem();
            this.editExtractSourceQueryBarItem1 = new DevExpress.DashboardWin.Bars.EditExtractSourceQueryBarItem();
            this.dataSourceFilteringRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.DataSourceFilteringRibbonPageGroup();
            this.editDataSourceFilterBarItem1 = new DevExpress.DashboardWin.Bars.EditDataSourceFilterBarItem();
            this.clearDataSourceFilterBarItem1 = new DevExpress.DashboardWin.Bars.ClearDataSourceFilterBarItem();
            this.skinsRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.SkinsRibbonPageGroup();
            this.viewRibbonPage1 = new DevExpress.DashboardWin.Bars.ViewRibbonPage();
            this.dashboardSkinsBarItem1 = new DevExpress.DashboardWin.Bars.DashboardSkinsBarItem();
            this.filteringRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage1 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.pivotToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.PivotToolsRibbonPageCategory();
            this.editFilterBarItem1 = new DevExpress.DashboardWin.Bars.EditFilterBarItem();
            this.clearFilterBarItem1 = new DevExpress.DashboardWin.Bars.ClearFilterBarItem();
            this.interactivitySettingsRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.ignoreMasterFiltersBarItem1 = new DevExpress.DashboardWin.Bars.IgnoreMasterFiltersBarItem();
            this.commonItemDesignRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage1 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.showItemCaptionBarItem1 = new DevExpress.DashboardWin.Bars.ShowItemCaptionBarItem();
            this.editItemNamesBarItem1 = new DevExpress.DashboardWin.Bars.EditItemNamesBarItem();
            this.pivotInitialStateRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.PivotInitialStateRibbonPageGroup();
            this.pivotInitialStateBarItem1 = new DevExpress.DashboardWin.Bars.PivotInitialStateBarItem();
            this.pivotAutoExpandColumnBarItem1 = new DevExpress.DashboardWin.Bars.PivotAutoExpandColumnBarItem();
            this.pivotAutoExpandRowBarItem1 = new DevExpress.DashboardWin.Bars.PivotAutoExpandRowBarItem();
            this.pivotLayoutRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.PivotLayoutRibbonPageGroup();
            this.pivotShowTotalsBarItem1 = new DevExpress.DashboardWin.Bars.PivotShowTotalsBarItem();
            this.pivotShowColumnTotalsBarItem1 = new DevExpress.DashboardWin.Bars.PivotShowColumnTotalsBarItem();
            this.pivotShowRowTotalsBarItem1 = new DevExpress.DashboardWin.Bars.PivotShowRowTotalsBarItem();
            this.pivotShowGrandTotalsBarItem1 = new DevExpress.DashboardWin.Bars.PivotShowGrandTotalsBarItem();
            this.pivotShowColumnGrandTotalsBarItem1 = new DevExpress.DashboardWin.Bars.PivotShowColumnGrandTotalsBarItem();
            this.pivotShowRowGrandTotalsBarItem1 = new DevExpress.DashboardWin.Bars.PivotShowRowGrandTotalsBarItem();
            this.pivotLayoutTypeBarItem1 = new DevExpress.DashboardWin.Bars.PivotLayoutTypeBarItem();
            this.pivotLayoutTypeCompactBarItem1 = new DevExpress.DashboardWin.Bars.PivotLayoutTypeCompactBarItem();
            this.pivotLayoutTypeTabularBarItem1 = new DevExpress.DashboardWin.Bars.PivotLayoutTypeTabularBarItem();
            this.pivotRowTotalsPositionBarItem1 = new DevExpress.DashboardWin.Bars.PivotRowTotalsPositionBarItem();
            this.pivotRowTotalsPositionTopBarItem1 = new DevExpress.DashboardWin.Bars.PivotRowTotalsPositionTopBarItem();
            this.pivotRowTotalsPositionBottomBarItem1 = new DevExpress.DashboardWin.Bars.PivotRowTotalsPositionBottomBarItem();
            this.pivotColumnTotalsPositionBarItem1 = new DevExpress.DashboardWin.Bars.PivotColumnTotalsPositionBarItem();
            this.pivotColumnTotalsPositionNearBarItem1 = new DevExpress.DashboardWin.Bars.PivotColumnTotalsPositionNearBarItem();
            this.pivotColumnTotalsPositionFarBarItem1 = new DevExpress.DashboardWin.Bars.PivotColumnTotalsPositionFarBarItem();
            this.pivotValuesPositionBarItem1 = new DevExpress.DashboardWin.Bars.PivotValuesPositionBarItem();
            this.pivotValuesPositionColumnsBarItem1 = new DevExpress.DashboardWin.Bars.PivotValuesPositionColumnsBarItem();
            this.pivotValuesPositionRowsBarItem1 = new DevExpress.DashboardWin.Bars.PivotValuesPositionRowsBarItem();
            this.pivotResetLayoutOptionsBarItem1 = new DevExpress.DashboardWin.Bars.PivotResetLayoutOptionsBarItem();
            this.filteringRibbonPageGroup2 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage2 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.gridToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.GridToolsRibbonPageCategory();
            this.masterFilterRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup();
            this.masterFilterBarItem1 = new DevExpress.DashboardWin.Bars.MasterFilterBarItem();
            this.multipleValuesMasterFilterBarItem1 = new DevExpress.DashboardWin.Bars.MultipleValuesMasterFilterBarItem();
            this.drillDownBarItem1 = new DevExpress.DashboardWin.Bars.DrillDownBarItem();
            this.interactivitySettingsRibbonPageGroup2 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.crossDataSourceFilteringBarItem1 = new DevExpress.DashboardWin.Bars.CrossDataSourceFilteringBarItem();
            this.commonItemDesignRibbonPageGroup2 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage2 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.gridStyleRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.GridStyleRibbonPageGroup();
            this.gridHorizontalLinesBarItem1 = new DevExpress.DashboardWin.Bars.GridHorizontalLinesBarItem();
            this.gridVerticalLinesBarItem1 = new DevExpress.DashboardWin.Bars.GridVerticalLinesBarItem();
            this.gridBandedRowsBarItem1 = new DevExpress.DashboardWin.Bars.GridBandedRowsBarItem();
            this.gridLayoutRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.GridLayoutRibbonPageGroup();
            this.gridMergeCellsBarItem1 = new DevExpress.DashboardWin.Bars.GridMergeCellsBarItem();
            this.gridColumnHeadersBarItem1 = new DevExpress.DashboardWin.Bars.GridColumnHeadersBarItem();
            this.gridWordWrapBarItem1 = new DevExpress.DashboardWin.Bars.GridWordWrapBarItem();
            this.gridColumnWidthModeRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.GridColumnWidthModeRibbonPageGroup();
            this.gridAutoFitToContentsColumnWidthModeBarItem1 = new DevExpress.DashboardWin.Bars.GridAutoFitToContentsColumnWidthModeBarItem();
            this.gridAutoFitToGridColumnWidthModeBarItem1 = new DevExpress.DashboardWin.Bars.GridAutoFitToGridColumnWidthModeBarItem();
            this.manualGridColumnWidthModeBarItem1 = new DevExpress.DashboardWin.Bars.ManualGridColumnWidthModeBarItem();
            this.filteringRibbonPageGroup3 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage3 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.chartToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.ChartToolsRibbonPageCategory();
            this.masterFilterRibbonPageGroup2 = new DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup();
            this.interactivitySettingsRibbonPageGroup3 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.targetDimensionsRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.TargetDimensionsRibbonPageGroup();
            this.chartTargetDimensionsArgumentsBarItem1 = new DevExpress.DashboardWin.Bars.ChartTargetDimensionsArgumentsBarItem();
            this.chartTargetDimensionsSeriesBarItem1 = new DevExpress.DashboardWin.Bars.ChartTargetDimensionsSeriesBarItem();
            this.chartTargetDimensionsPointsBarItem1 = new DevExpress.DashboardWin.Bars.ChartTargetDimensionsPointsBarItem();
            this.commonItemDesignRibbonPageGroup3 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage3 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.chartLayoutPageGroup1 = new DevExpress.DashboardWin.Bars.ChartLayoutPageGroup();
            this.chartRotateBarItem1 = new DevExpress.DashboardWin.Bars.ChartRotateBarItem();
            this.chartXAxisSettingsBarItem1 = new DevExpress.DashboardWin.Bars.ChartXAxisSettingsBarItem();
            this.chartYAxisSettingsBarItem1 = new DevExpress.DashboardWin.Bars.ChartYAxisSettingsBarItem();
            this.chartLegendPositionPageGroup1 = new DevExpress.DashboardWin.Bars.ChartLegendPositionPageGroup();
            this.chartShowLegendBarItem1 = new DevExpress.DashboardWin.Bars.ChartShowLegendBarItem();
            this.galleryChartLegendPositionItem1 = new DevExpress.DashboardWin.Bars.GalleryChartLegendPositionItem();
            this.chartStylePageGroup1 = new DevExpress.DashboardWin.Bars.ChartStylePageGroup();
            this.galleryChartSeriesTypeItem1 = new DevExpress.DashboardWin.Bars.GalleryChartSeriesTypeItem();
            this.coloringOptionsRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.ColoringOptionsRibbonPageGroup();
            this.useGlobalColorsBarItem1 = new DevExpress.DashboardWin.Bars.UseGlobalColorsBarItem();
            this.useLocalColorsBarItem1 = new DevExpress.DashboardWin.Bars.UseLocalColorsBarItem();
            this.editActualColorsBarItem1 = new DevExpress.DashboardWin.Bars.EditActualColorsBarItem();
            this.filteringRibbonPageGroup4 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage4 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.scatterChartToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.ScatterChartToolsRibbonPageCategory();
            this.masterFilterRibbonPageGroup3 = new DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup();
            this.interactivitySettingsRibbonPageGroup4 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.commonItemDesignRibbonPageGroup4 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage4 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.scatterChartLayoutPageGroup1 = new DevExpress.DashboardWin.Bars.ScatterChartLayoutPageGroup();
            this.scatterChartRotateBarItem1 = new DevExpress.DashboardWin.Bars.ScatterChartRotateBarItem();
            this.scatterChartXAxisSettingsBarItem1 = new DevExpress.DashboardWin.Bars.ScatterChartXAxisSettingsBarItem();
            this.scatterChartYAxisSettingsBarItem1 = new DevExpress.DashboardWin.Bars.ScatterChartYAxisSettingsBarItem();
            this.scatterChartPointLabelPageGroup1 = new DevExpress.DashboardWin.Bars.ScatterChartPointLabelPageGroup();
            this.scatterChartPointLabelOptionsBarItem1 = new DevExpress.DashboardWin.Bars.ScatterChartPointLabelOptionsBarItem();
            this.scatterChartLegendPositionPageGroup1 = new DevExpress.DashboardWin.Bars.ScatterChartLegendPositionPageGroup();
            this.scatterChartShowLegendBarItem1 = new DevExpress.DashboardWin.Bars.ScatterChartShowLegendBarItem();
            this.galleryScatterChartLegendPositionItem1 = new DevExpress.DashboardWin.Bars.GalleryScatterChartLegendPositionItem();
            this.coloringOptionsRibbonPageGroup2 = new DevExpress.DashboardWin.Bars.ColoringOptionsRibbonPageGroup();
            this.filteringRibbonPageGroup5 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage5 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.piesToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.PiesToolsRibbonPageCategory();
            this.masterFilterRibbonPageGroup4 = new DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup();
            this.interactivitySettingsRibbonPageGroup5 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.targetDimensionsRibbonPageGroup2 = new DevExpress.DashboardWin.Bars.TargetDimensionsRibbonPageGroup();
            this.pieTargetDimensionsArgumentsBarItem1 = new DevExpress.DashboardWin.Bars.PieTargetDimensionsArgumentsBarItem();
            this.pieTargetDimensionsSeriesBarItem1 = new DevExpress.DashboardWin.Bars.PieTargetDimensionsSeriesBarItem();
            this.pieTargetDimensionsPointsBarItem1 = new DevExpress.DashboardWin.Bars.PieTargetDimensionsPointsBarItem();
            this.commonItemDesignRibbonPageGroup5 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage5 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.contentArrangementRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.ContentArrangementRibbonPageGroup();
            this.contentAutoArrangeBarItem1 = new DevExpress.DashboardWin.Bars.ContentAutoArrangeBarItem();
            this.contentArrangeInColumnsBarItem1 = new DevExpress.DashboardWin.Bars.ContentArrangeInColumnsBarItem();
            this.contentArrangeInRowsBarItem1 = new DevExpress.DashboardWin.Bars.ContentArrangeInRowsBarItem();
            this.contentArrangementCountBarItem1 = new DevExpress.DashboardWin.Bars.ContentArrangementCountBarItem();
            this.repositoryItemSpinEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.pieLabelsRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.PieLabelsRibbonPageGroup();
            this.pieLabelsDataLabelsBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsDataLabelsBarItem();
            this.pieLabelsDataLabelsNoneBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsDataLabelsNoneBarItem();
            this.pieLabelsDataLabelArgumentBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsDataLabelArgumentBarItem();
            this.pieLabelsDataLabelsValueBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsDataLabelsValueBarItem();
            this.pieLabelsDataLabelsArgumentAndValueBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsDataLabelsArgumentAndValueBarItem();
            this.pieLabelsDataLabelsPercentBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsDataLabelsPercentBarItem();
            this.pieLabelsDataLabelsValueAndPercentBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsDataLabelsValueAndPercentBarItem();
            this.pieLabelsDataLabelsArgumentAndPercentBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsDataLabelsArgumentAndPercentBarItem();
            this.pieLabelsDataLabelsArgumentValueAndPercentBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsDataLabelsArgumentValueAndPercentBarItem();
            this.pieLabelPositionBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelPositionBarItem();
            this.pieLabelPositionOutsideBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelPositionOutsideBarItem();
            this.pieLabelPositionInsideBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelPositionInsideBarItem();
            this.pieTooltipsBarItem1 = new DevExpress.DashboardWin.Bars.PieTooltipsBarItem();
            this.pieLabelsTooltipsNoneBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsTooltipsNoneBarItem();
            this.pieLabelsTooltipsArgumentBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsTooltipsArgumentBarItem();
            this.pieLabelsTooltipsValueBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsTooltipsValueBarItem();
            this.pieLabelsTooltipsArgumentAndValueBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsTooltipsArgumentAndValueBarItem();
            this.pieLabelsTooltipsPercentBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsTooltipsPercentBarItem();
            this.pieLabelsTooltipsValueAndPercentBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsTooltipsValueAndPercentBarItem();
            this.pieLabelsTooltipsArgumentAndPercentBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsTooltipsArgumentAndPercentBarItem();
            this.pieLabelsTooltipsArgumentValueAndPercentBarItem1 = new DevExpress.DashboardWin.Bars.PieLabelsTooltipsArgumentValueAndPercentBarItem();
            this.pieStyleRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.PieStyleRibbonPageGroup();
            this.pieStylePieBarItem1 = new DevExpress.DashboardWin.Bars.PieStylePieBarItem();
            this.pieStyleDonutBarItem1 = new DevExpress.DashboardWin.Bars.PieStyleDonutBarItem();
            this.pieShowCaptionsBarItem1 = new DevExpress.DashboardWin.Bars.PieShowCaptionsBarItem();
            this.coloringOptionsRibbonPageGroup3 = new DevExpress.DashboardWin.Bars.ColoringOptionsRibbonPageGroup();
            this.filteringRibbonPageGroup6 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage6 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.gaugesToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.GaugesToolsRibbonPageCategory();
            this.masterFilterRibbonPageGroup5 = new DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup();
            this.interactivitySettingsRibbonPageGroup6 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.commonItemDesignRibbonPageGroup6 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage6 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.contentArrangementRibbonPageGroup2 = new DevExpress.DashboardWin.Bars.ContentArrangementRibbonPageGroup();
            this.gaugeStyleRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.GaugeStyleRibbonPageGroup();
            this.gaugeStyleFullCircularBarItem1 = new DevExpress.DashboardWin.Bars.GaugeStyleFullCircularBarItem();
            this.gaugeStyleHalfCircularBarItem1 = new DevExpress.DashboardWin.Bars.GaugeStyleHalfCircularBarItem();
            this.gaugeStyleLeftQuarterCircularBarItem1 = new DevExpress.DashboardWin.Bars.GaugeStyleLeftQuarterCircularBarItem();
            this.gaugeStyleRightQuarterCircularBarItem1 = new DevExpress.DashboardWin.Bars.GaugeStyleRightQuarterCircularBarItem();
            this.gaugeStyleThreeForthCircularBarItem1 = new DevExpress.DashboardWin.Bars.GaugeStyleThreeForthCircularBarItem();
            this.gaugeStyleLinearHorizontalBarItem1 = new DevExpress.DashboardWin.Bars.GaugeStyleLinearHorizontalBarItem();
            this.gaugeStyleLinearVerticalBarItem1 = new DevExpress.DashboardWin.Bars.GaugeStyleLinearVerticalBarItem();
            this.gaugesLabelsRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.GaugesLabelsRibbonPageGroup();
            this.gaugeShowCaptionsBarItem1 = new DevExpress.DashboardWin.Bars.GaugeShowCaptionsBarItem();
            this.filteringRibbonPageGroup7 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage7 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.cardsToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.CardsToolsRibbonPageCategory();
            this.masterFilterRibbonPageGroup6 = new DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup();
            this.interactivitySettingsRibbonPageGroup7 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.commonItemDesignRibbonPageGroup7 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage7 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.contentArrangementRibbonPageGroup3 = new DevExpress.DashboardWin.Bars.ContentArrangementRibbonPageGroup();
            this.filteringRibbonPageGroup8 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage8 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.rangeFilterToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.RangeFilterToolsRibbonPageCategory();
            this.interactivitySettingsRibbonPageGroup8 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.commonItemDesignRibbonPageGroup8 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage8 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.rangeFilterSeriesTypeRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.RangeFilterSeriesTypeRibbonPageGroup();
            this.galleryRangeFilterSeriesTypeItem1 = new DevExpress.DashboardWin.Bars.GalleryRangeFilterSeriesTypeItem();
            this.rangeFilterInteractivityRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.RangeFilterInteractivityRibbonPageGroup();
            this.rangeFilterEditDateTimePeriodsBarItem1 = new DevExpress.DashboardWin.Bars.RangeFilterEditDateTimePeriodsBarItem();
            this.coloringOptionsRibbonPageGroup4 = new DevExpress.DashboardWin.Bars.ColoringOptionsRibbonPageGroup();
            this.filteringRibbonPageGroup9 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage9 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.choroplethMapToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.ChoroplethMapToolsRibbonPageCategory();
            this.masterFilterRibbonPageGroup7 = new DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup();
            this.interactivitySettingsRibbonPageGroup9 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.commonItemDesignRibbonPageGroup9 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage9 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.mapShapefileRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.MapShapefileRibbonPageGroup();
            this.mapLoadBarItem1 = new DevExpress.DashboardWin.Bars.MapLoadBarItem();
            this.mapImportBarItem1 = new DevExpress.DashboardWin.Bars.MapImportBarItem();
            this.mapDefaultShapefileBarItem1 = new DevExpress.DashboardWin.Bars.MapDefaultShapefileBarItem();
            this.mapWorldCountriesBarItem1 = new DevExpress.DashboardWin.Bars.MapWorldCountriesBarItem();
            this.mapEuropeBarItem1 = new DevExpress.DashboardWin.Bars.MapEuropeBarItem();
            this.mapAsiaBarItem1 = new DevExpress.DashboardWin.Bars.MapAsiaBarItem();
            this.mapNorthAmericaBarItem1 = new DevExpress.DashboardWin.Bars.MapNorthAmericaBarItem();
            this.mapSouthAmericaBarItem1 = new DevExpress.DashboardWin.Bars.MapSouthAmericaBarItem();
            this.mapAfricaBarItem1 = new DevExpress.DashboardWin.Bars.MapAfricaBarItem();
            this.mapUSABarItem1 = new DevExpress.DashboardWin.Bars.MapUSABarItem();
            this.mapCanadaBarItem1 = new DevExpress.DashboardWin.Bars.MapCanadaBarItem();
            this.mapNavigationPageGroup1 = new DevExpress.DashboardWin.Bars.MapNavigationPageGroup();
            this.mapLockNavigationBarItem1 = new DevExpress.DashboardWin.Bars.MapLockNavigationBarItem();
            this.mapFullExtentBarItem1 = new DevExpress.DashboardWin.Bars.MapFullExtentBarItem();
            this.mapShapeLabelsAttributePageGroup1 = new DevExpress.DashboardWin.Bars.MapShapeLabelsAttributePageGroup();
            this.choroplethMapShapeLabelsAttributeBarItem1 = new DevExpress.DashboardWin.Bars.ChoroplethMapShapeLabelsAttributeBarItem();
            this.mapLegendPositionPageGroup1 = new DevExpress.DashboardWin.Bars.MapLegendPositionPageGroup();
            this.mapShowLegendBarItem1 = new DevExpress.DashboardWin.Bars.MapShowLegendBarItem();
            this.galleryMapLegendPositionItem1 = new DevExpress.DashboardWin.Bars.GalleryMapLegendPositionItem();
            this.filteringRibbonPageGroup10 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage10 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.geoPointMapToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.GeoPointMapToolsRibbonPageCategory();
            this.masterFilterRibbonPageGroup8 = new DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup();
            this.interactivitySettingsRibbonPageGroup10 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.geoPointMapClusterizationRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.GeoPointMapClusterizationRibbonPageGroup();
            this.geoPointMapClusterizationBarItem1 = new DevExpress.DashboardWin.Bars.GeoPointMapClusterizationBarItem();
            this.commonItemDesignRibbonPageGroup10 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage10 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.mapShapefileRibbonPageGroup2 = new DevExpress.DashboardWin.Bars.MapShapefileRibbonPageGroup();
            this.mapNavigationPageGroup2 = new DevExpress.DashboardWin.Bars.MapNavigationPageGroup();
            this.mapShapeLabelsAttributePageGroup2 = new DevExpress.DashboardWin.Bars.MapShapeLabelsAttributePageGroup();
            this.mapShapeTitleAttributeBarItem1 = new DevExpress.DashboardWin.Bars.MapShapeTitleAttributeBarItem();
            this.filteringRibbonPageGroup11 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage11 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.bubbleMapToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.BubbleMapToolsRibbonPageCategory();
            this.masterFilterRibbonPageGroup9 = new DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup();
            this.interactivitySettingsRibbonPageGroup11 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.geoPointMapClusterizationRibbonPageGroup2 = new DevExpress.DashboardWin.Bars.GeoPointMapClusterizationRibbonPageGroup();
            this.commonItemDesignRibbonPageGroup11 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage11 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.mapShapefileRibbonPageGroup3 = new DevExpress.DashboardWin.Bars.MapShapefileRibbonPageGroup();
            this.mapNavigationPageGroup3 = new DevExpress.DashboardWin.Bars.MapNavigationPageGroup();
            this.mapShapeLabelsAttributePageGroup3 = new DevExpress.DashboardWin.Bars.MapShapeLabelsAttributePageGroup();
            this.mapLegendPositionPageGroup2 = new DevExpress.DashboardWin.Bars.MapLegendPositionPageGroup();
            this.weightedLegendPageGroup1 = new DevExpress.DashboardWin.Bars.WeightedLegendPageGroup();
            this.changeWeightedLegendTypeBarItem1 = new DevExpress.DashboardWin.Bars.ChangeWeightedLegendTypeBarItem();
            this.weightedLegendNoneBarItem1 = new DevExpress.DashboardWin.Bars.WeightedLegendNoneBarItem();
            this.weightedLegendLinearBarItem1 = new DevExpress.DashboardWin.Bars.WeightedLegendLinearBarItem();
            this.weightedLegendNestedBarItem1 = new DevExpress.DashboardWin.Bars.WeightedLegendNestedBarItem();
            this.galleryWeightedLegendPositionItem1 = new DevExpress.DashboardWin.Bars.GalleryWeightedLegendPositionItem();
            this.filteringRibbonPageGroup12 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage12 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.pieMapToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.PieMapToolsRibbonPageCategory();
            this.masterFilterRibbonPageGroup10 = new DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup();
            this.interactivitySettingsRibbonPageGroup12 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.geoPointMapClusterizationRibbonPageGroup3 = new DevExpress.DashboardWin.Bars.GeoPointMapClusterizationRibbonPageGroup();
            this.commonItemDesignRibbonPageGroup12 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage12 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.mapShapefileRibbonPageGroup4 = new DevExpress.DashboardWin.Bars.MapShapefileRibbonPageGroup();
            this.mapNavigationPageGroup4 = new DevExpress.DashboardWin.Bars.MapNavigationPageGroup();
            this.mapShapeLabelsAttributePageGroup4 = new DevExpress.DashboardWin.Bars.MapShapeLabelsAttributePageGroup();
            this.mapLegendPositionPageGroup3 = new DevExpress.DashboardWin.Bars.MapLegendPositionPageGroup();
            this.weightedLegendPageGroup2 = new DevExpress.DashboardWin.Bars.WeightedLegendPageGroup();
            this.pieMapOptionsPageGroup1 = new DevExpress.DashboardWin.Bars.PieMapOptionsPageGroup();
            this.pieMapIsWeightedBarItem1 = new DevExpress.DashboardWin.Bars.PieMapIsWeightedBarItem();
            this.coloringOptionsRibbonPageGroup5 = new DevExpress.DashboardWin.Bars.ColoringOptionsRibbonPageGroup();
            this.filteringRibbonPageGroup13 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage13 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.filterElementToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.FilterElementToolsRibbonPageCategory();
            this.interactivitySettingsRibbonPageGroup13 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.commonItemDesignRibbonPageGroup13 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage13 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.filterElementTypeRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.FilterElementTypeRibbonPageGroup();
            this.comboBoxStandardTypeBarItem1 = new DevExpress.DashboardWin.Bars.ComboBoxStandardTypeBarItem();
            this.comboBoxCheckedTypeBarItem1 = new DevExpress.DashboardWin.Bars.ComboBoxCheckedTypeBarItem();
            this.listBoxCheckedTypeBarItem1 = new DevExpress.DashboardWin.Bars.ListBoxCheckedTypeBarItem();
            this.listBoxRadioTypeBarItem1 = new DevExpress.DashboardWin.Bars.ListBoxRadioTypeBarItem();
            this.filterElementItemOptionsRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.FilterElementItemOptionsRibbonPageGroup();
            this.filterElementShowAllValueBarItem1 = new DevExpress.DashboardWin.Bars.FilterElementShowAllValueBarItem();
            this.filterElementEnableSearchBarItem1 = new DevExpress.DashboardWin.Bars.FilterElementEnableSearchBarItem();
            this.treeViewOptionsRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.TreeViewOptionsRibbonPageGroup();
            this.treeViewLayoutRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.TreeViewLayoutRibbonPageGroup();
            this.treeViewAutoExpandBarItem1 = new DevExpress.DashboardWin.Bars.TreeViewAutoExpandBarItem();
            this.filteringRibbonPageGroup14 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage14 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.boundImageToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.BoundImageToolsRibbonPageCategory();
            this.interactivitySettingsRibbonPageGroup14 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.commonItemDesignRibbonPageGroup14 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage14 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.imageSizeModeRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.ImageSizeModeRibbonPageGroup();
            this.imageSizeModeClipBarItem1 = new DevExpress.DashboardWin.Bars.ImageSizeModeClipBarItem();
            this.imageSizeModeStretchBarItem1 = new DevExpress.DashboardWin.Bars.ImageSizeModeStretchBarItem();
            this.imageSizeModeSqueezeBarItem1 = new DevExpress.DashboardWin.Bars.ImageSizeModeSqueezeBarItem();
            this.imageSizeModeZoomBarItem1 = new DevExpress.DashboardWin.Bars.ImageSizeModeZoomBarItem();
            this.imageAlignmentRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.ImageAlignmentRibbonPageGroup();
            this.imageAlignmentTopLeftBarItem1 = new DevExpress.DashboardWin.Bars.ImageAlignmentTopLeftBarItem();
            this.imageAlignmentCenterLeftBarItem1 = new DevExpress.DashboardWin.Bars.ImageAlignmentCenterLeftBarItem();
            this.imageAlignmentBottomLeftBarItem1 = new DevExpress.DashboardWin.Bars.ImageAlignmentBottomLeftBarItem();
            this.imageAlignmentTopCenterBarItem1 = new DevExpress.DashboardWin.Bars.ImageAlignmentTopCenterBarItem();
            this.imageAlignmentCenterCenterBarItem1 = new DevExpress.DashboardWin.Bars.ImageAlignmentCenterCenterBarItem();
            this.imageAlignmentBottomCenterBarItem1 = new DevExpress.DashboardWin.Bars.ImageAlignmentBottomCenterBarItem();
            this.imageAlignmentTopRightBarItem1 = new DevExpress.DashboardWin.Bars.ImageAlignmentTopRightBarItem();
            this.imageAlignmentCenterRightBarItem1 = new DevExpress.DashboardWin.Bars.ImageAlignmentCenterRightBarItem();
            this.imageAlignmentBottomRightBarItem1 = new DevExpress.DashboardWin.Bars.ImageAlignmentBottomRightBarItem();
            this.filteringRibbonPageGroup15 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage15 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.textBoxToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.TextBoxToolsRibbonPageCategory();
            this.interactivitySettingsRibbonPageGroup15 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.commonItemDesignRibbonPageGroup15 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage15 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.textBoxEditingRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.TextBoxEditingRibbonPageGroup();
            this.textBoxEditTextBarItem1 = new DevExpress.DashboardWin.Bars.TextBoxEditTextBarItem();
            this.textBoxInsertFieldBarItem1 = new DevExpress.DashboardWin.Bars.TextBoxInsertFieldBarItem();
            this.filteringRibbonPageGroup16 = new DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup();
            this.dataRibbonPage16 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.treemapToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.TreemapToolsRibbonPageCategory();
            this.masterFilterRibbonPageGroup11 = new DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup();
            this.interactivitySettingsRibbonPageGroup16 = new DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup();
            this.commonItemDesignRibbonPageGroup16 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage16 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.treemapLayoutRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.TreemapLayoutRibbonPageGroup();
            this.treemapSliceAndDiceLayoutAlgorithmBarItem1 = new DevExpress.DashboardWin.Bars.TreemapSliceAndDiceLayoutAlgorithmBarItem();
            this.treemapSquarifiedLayoutAlgorithmBarItem1 = new DevExpress.DashboardWin.Bars.TreemapSquarifiedLayoutAlgorithmBarItem();
            this.treemapStripedLayoutAlgorithmBarItem1 = new DevExpress.DashboardWin.Bars.TreemapStripedLayoutAlgorithmBarItem();
            this.treemapLayoutDirectionBarItem1 = new DevExpress.DashboardWin.Bars.TreemapLayoutDirectionBarItem();
            this.treemapBottomLeftToTopRightLayoutDirectionBarItem1 = new DevExpress.DashboardWin.Bars.TreemapBottomLeftToTopRightLayoutDirectionBarItem();
            this.treemapBottomRightToTopLeftLayoutDirectionBarItem1 = new DevExpress.DashboardWin.Bars.TreemapBottomRightToTopLeftLayoutDirectionBarItem();
            this.treemapTopLeftToBottomRightLayoutDirectionBarItem1 = new DevExpress.DashboardWin.Bars.TreemapTopLeftToBottomRightLayoutDirectionBarItem();
            this.treemapTopRightToBottomLeftLayoutDirectionBarItem1 = new DevExpress.DashboardWin.Bars.TreemapTopRightToBottomLeftLayoutDirectionBarItem();
            this.treemapTileLabelsRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.TreemapTileLabelsRibbonPageGroup();
            this.treemapTileLabelsBarItem1 = new DevExpress.DashboardWin.Bars.TreemapTileLabelsBarItem();
            this.treemapTileLabelsNoneBarItem1 = new DevExpress.DashboardWin.Bars.TreemapTileLabelsNoneBarItem();
            this.treemapTileLabelsArgumentBarItem1 = new DevExpress.DashboardWin.Bars.TreemapTileLabelsArgumentBarItem();
            this.treemapTileLabelsValueBarItem1 = new DevExpress.DashboardWin.Bars.TreemapTileLabelsValueBarItem();
            this.treemapTileLabelsArgumentAndValueBarItem1 = new DevExpress.DashboardWin.Bars.TreemapTileLabelsArgumentAndValueBarItem();
            this.treemapTileTooltipsBarItem1 = new DevExpress.DashboardWin.Bars.TreemapTileTooltipsBarItem();
            this.treemapTileTooltipsNoneBarItem1 = new DevExpress.DashboardWin.Bars.TreemapTileTooltipsNoneBarItem();
            this.treemapTileTooltipsArgumentBarItem1 = new DevExpress.DashboardWin.Bars.TreemapTileTooltipsArgumentBarItem();
            this.treemapTileTooltipsValueBarItem1 = new DevExpress.DashboardWin.Bars.TreemapTileTooltipsValueBarItem();
            this.treemapTileTooltipsArgumentAndValueBarItem1 = new DevExpress.DashboardWin.Bars.TreemapTileTooltipsArgumentAndValueBarItem();
            this.treemapGroupLabelsRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.TreemapGroupLabelsRibbonPageGroup();
            this.treemapGroupLabelsBarItem1 = new DevExpress.DashboardWin.Bars.TreemapGroupLabelsBarItem();
            this.treemapGroupLabelsNoneBarItem1 = new DevExpress.DashboardWin.Bars.TreemapGroupLabelsNoneBarItem();
            this.treemapGroupLabelsArgumentBarItem1 = new DevExpress.DashboardWin.Bars.TreemapGroupLabelsArgumentBarItem();
            this.treemapGroupLabelsValueBarItem1 = new DevExpress.DashboardWin.Bars.TreemapGroupLabelsValueBarItem();
            this.treemapGroupLabelsArgumentAndValueBarItem1 = new DevExpress.DashboardWin.Bars.TreemapGroupLabelsArgumentAndValueBarItem();
            this.treemapGroupTooltipsBarItem1 = new DevExpress.DashboardWin.Bars.TreemapGroupTooltipsBarItem();
            this.treemapGroupTooltipsNoneBarItem1 = new DevExpress.DashboardWin.Bars.TreemapGroupTooltipsNoneBarItem();
            this.treemapGroupTooltipsArgumentBarItem1 = new DevExpress.DashboardWin.Bars.TreemapGroupTooltipsArgumentBarItem();
            this.treemapGroupTooltipsValueBarItem1 = new DevExpress.DashboardWin.Bars.TreemapGroupTooltipsValueBarItem();
            this.treemapGroupTooltipsArgumentAndValueBarItem1 = new DevExpress.DashboardWin.Bars.TreemapGroupTooltipsArgumentAndValueBarItem();
            this.coloringOptionsRibbonPageGroup6 = new DevExpress.DashboardWin.Bars.ColoringOptionsRibbonPageGroup();
            this.commonItemDesignRibbonPageGroup17 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage17 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.imageToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.ImageToolsRibbonPageCategory();
            this.imageOpenRibbonPageGroup1 = new DevExpress.DashboardWin.Bars.ImageOpenRibbonPageGroup();
            this.imageLoadBarItem1 = new DevExpress.DashboardWin.Bars.ImageLoadBarItem();
            this.imageImportBarItem1 = new DevExpress.DashboardWin.Bars.ImageImportBarItem();
            this.imageSizeModeRibbonPageGroup2 = new DevExpress.DashboardWin.Bars.ImageSizeModeRibbonPageGroup();
            this.imageAlignmentRibbonPageGroup2 = new DevExpress.DashboardWin.Bars.ImageAlignmentRibbonPageGroup();
            this.masterFilterRibbonPageGroup12 = new DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup();
            this.dataRibbonPage17 = new DevExpress.DashboardWin.Bars.DataRibbonPage();
            this.groupToolsRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.GroupToolsRibbonPageCategory();
            this.groupMasterFilterBarItem1 = new DevExpress.DashboardWin.Bars.GroupMasterFilterBarItem();
            this.groupIgnoreMasterFilterBarItem1 = new DevExpress.DashboardWin.Bars.GroupIgnoreMasterFilterBarItem();
            this.commonItemDesignRibbonPageGroup18 = new DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup();
            this.dashboardItemDesignRibbonPage18 = new DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage();
            this.textBoxEditorBarController1 = new DevExpress.DashboardWin.Bars.TextBoxEditorBarController(this.components);
            this.commonRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.CommonRibbonPageGroup();
            this.fileRibbonPage1 = new DevExpress.XtraRichEdit.UI.FileRibbonPage();
            this.textBoxEditorRibbonPageCategory1 = new DevExpress.DashboardWin.Bars.TextBoxEditorRibbonPageCategory();
            this.undoItem1 = new DevExpress.XtraRichEdit.UI.UndoItem();
            this.redoItem1 = new DevExpress.XtraRichEdit.UI.RedoItem();
            this.fileOpenItem1 = new DevExpress.XtraRichEdit.UI.FileOpenItem();
            this.clipboardRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.ClipboardRibbonPageGroup();
            this.homeRibbonPage2 = new DevExpress.XtraRichEdit.UI.HomeRibbonPage();
            this.pasteItem1 = new DevExpress.XtraRichEdit.UI.PasteItem();
            this.cutItem1 = new DevExpress.XtraRichEdit.UI.CutItem();
            this.copyItem1 = new DevExpress.XtraRichEdit.UI.CopyItem();
            this.pasteSpecialItem1 = new DevExpress.XtraRichEdit.UI.PasteSpecialItem();
            this.fontRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.FontRibbonPageGroup();
            this.changeFontNameItem1 = new DevExpress.XtraRichEdit.UI.ChangeFontNameItem();
            this.changeFontSizeItem1 = new DevExpress.XtraRichEdit.UI.ChangeFontSizeItem();
            this.fontSizeIncreaseItem1 = new DevExpress.XtraRichEdit.UI.FontSizeIncreaseItem();
            this.fontSizeDecreaseItem1 = new DevExpress.XtraRichEdit.UI.FontSizeDecreaseItem();
            this.toggleFontBoldItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontBoldItem();
            this.toggleFontItalicItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontItalicItem();
            this.toggleFontUnderlineItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontUnderlineItem();
            this.toggleFontDoubleUnderlineItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontDoubleUnderlineItem();
            this.toggleFontStrikeoutItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontStrikeoutItem();
            this.toggleFontDoubleStrikeoutItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontDoubleStrikeoutItem();
            this.toggleFontSuperscriptItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontSuperscriptItem();
            this.toggleFontSubscriptItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontSubscriptItem();
            this.changeFontColorItem1 = new DevExpress.XtraRichEdit.UI.ChangeFontColorItem();
            this.changeFontHighlightColorItem1 = new DevExpress.XtraRichEdit.UI.ChangeFontHighlightColorItem();
            this.changeTextCaseItem1 = new DevExpress.XtraRichEdit.UI.ChangeTextCaseItem();
            this.makeTextUpperCaseItem1 = new DevExpress.XtraRichEdit.UI.MakeTextUpperCaseItem();
            this.makeTextLowerCaseItem1 = new DevExpress.XtraRichEdit.UI.MakeTextLowerCaseItem();
            this.capitalizeEachWordCaseItem1 = new DevExpress.XtraRichEdit.UI.CapitalizeEachWordCaseItem();
            this.toggleTextCaseItem1 = new DevExpress.XtraRichEdit.UI.ToggleTextCaseItem();
            this.clearFormattingItem1 = new DevExpress.XtraRichEdit.UI.ClearFormattingItem();
            this.barButtonGroup1 = new DevExpress.XtraBars.BarButtonGroup();
            this.repositoryItemFontEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemFontEdit();
            this.repositoryItemRichEditFontSizeEdit1 = new DevExpress.XtraRichEdit.Design.RepositoryItemRichEditFontSizeEdit();
            this.barButtonGroup2 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup3 = new DevExpress.XtraBars.BarButtonGroup();
            this.paragraphRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.ParagraphRibbonPageGroup();
            this.toggleBulletedListItem1 = new DevExpress.XtraRichEdit.UI.ToggleBulletedListItem();
            this.toggleNumberingListItem1 = new DevExpress.XtraRichEdit.UI.ToggleNumberingListItem();
            this.toggleMultiLevelListItem1 = new DevExpress.XtraRichEdit.UI.ToggleMultiLevelListItem();
            this.decreaseIndentItem1 = new DevExpress.XtraRichEdit.UI.DecreaseIndentItem();
            this.increaseIndentItem1 = new DevExpress.XtraRichEdit.UI.IncreaseIndentItem();
            this.toggleParagraphAlignmentLeftItem1 = new DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentLeftItem();
            this.toggleParagraphAlignmentCenterItem1 = new DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentCenterItem();
            this.toggleParagraphAlignmentRightItem1 = new DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentRightItem();
            this.toggleParagraphAlignmentJustifyItem1 = new DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentJustifyItem();
            this.toggleShowWhitespaceItem1 = new DevExpress.XtraRichEdit.UI.ToggleShowWhitespaceItem();
            this.changeParagraphLineSpacingItem1 = new DevExpress.XtraRichEdit.UI.ChangeParagraphLineSpacingItem();
            this.setSingleParagraphSpacingItem1 = new DevExpress.XtraRichEdit.UI.SetSingleParagraphSpacingItem();
            this.setSesquialteralParagraphSpacingItem1 = new DevExpress.XtraRichEdit.UI.SetSesquialteralParagraphSpacingItem();
            this.setDoubleParagraphSpacingItem1 = new DevExpress.XtraRichEdit.UI.SetDoubleParagraphSpacingItem();
            this.showLineSpacingFormItem1 = new DevExpress.XtraRichEdit.UI.ShowLineSpacingFormItem();
            this.addSpacingBeforeParagraphItem1 = new DevExpress.XtraRichEdit.UI.AddSpacingBeforeParagraphItem();
            this.removeSpacingBeforeParagraphItem1 = new DevExpress.XtraRichEdit.UI.RemoveSpacingBeforeParagraphItem();
            this.addSpacingAfterParagraphItem1 = new DevExpress.XtraRichEdit.UI.AddSpacingAfterParagraphItem();
            this.removeSpacingAfterParagraphItem1 = new DevExpress.XtraRichEdit.UI.RemoveSpacingAfterParagraphItem();
            this.changeParagraphBackColorItem1 = new DevExpress.XtraRichEdit.UI.ChangeParagraphBackColorItem();
            this.barButtonGroup4 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup5 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup6 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup7 = new DevExpress.XtraBars.BarButtonGroup();
            this.stylesRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.StylesRibbonPageGroup();
            this.galleryChangeStyleItem1 = new DevExpress.XtraRichEdit.UI.GalleryChangeStyleItem();
            this.editingRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.EditingRibbonPageGroup();
            this.findItem1 = new DevExpress.XtraRichEdit.UI.FindItem();
            this.replaceItem1 = new DevExpress.XtraRichEdit.UI.ReplaceItem();
            this.tablesRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TablesRibbonPageGroup();
            this.insertRibbonPage1 = new DevExpress.XtraRichEdit.UI.InsertRibbonPage();
            this.insertTableItem1 = new DevExpress.XtraRichEdit.UI.InsertTableItem();
            this.illustrationsRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.IllustrationsRibbonPageGroup();
            this.insertPictureItem1 = new DevExpress.XtraRichEdit.UI.InsertPictureItem();
            this.insertFloatingPictureItem1 = new DevExpress.XtraRichEdit.UI.InsertFloatingPictureItem();
            this.linksRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.LinksRibbonPageGroup();
            this.insertBookmarkItem1 = new DevExpress.XtraRichEdit.UI.InsertBookmarkItem();
            this.insertHyperlinkItem1 = new DevExpress.XtraRichEdit.UI.InsertHyperlinkItem();
            this.symbolsRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.SymbolsRibbonPageGroup();
            this.insertSymbolItem1 = new DevExpress.XtraRichEdit.UI.InsertSymbolItem();
            this.pageBackgroundRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.PageBackgroundRibbonPageGroup();
            this.pageLayoutRibbonPage1 = new DevExpress.XtraRichEdit.UI.PageLayoutRibbonPage();
            this.changePageColorItem1 = new DevExpress.XtraRichEdit.UI.ChangePageColorItem();
            this.tableStyleOptionsRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableStyleOptionsRibbonPageGroup();
            this.tableDesignRibbonPage1 = new DevExpress.XtraRichEdit.UI.TableDesignRibbonPage();
            this.toggleFirstRowItem1 = new DevExpress.XtraRichEdit.UI.ToggleFirstRowItem();
            this.toggleLastRowItem1 = new DevExpress.XtraRichEdit.UI.ToggleLastRowItem();
            this.toggleBandedRowsItem1 = new DevExpress.XtraRichEdit.UI.ToggleBandedRowsItem();
            this.toggleFirstColumnItem1 = new DevExpress.XtraRichEdit.UI.ToggleFirstColumnItem();
            this.toggleLastColumnItem1 = new DevExpress.XtraRichEdit.UI.ToggleLastColumnItem();
            this.toggleBandedColumnsItem1 = new DevExpress.XtraRichEdit.UI.ToggleBandedColumnsItem();
            this.tableStylesRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableStylesRibbonPageGroup();
            this.galleryChangeTableStyleItem1 = new DevExpress.XtraRichEdit.UI.GalleryChangeTableStyleItem();
            this.tableDrawBordersRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableDrawBordersRibbonPageGroup();
            this.changeTableBorderLineStyleItem1 = new DevExpress.XtraRichEdit.UI.ChangeTableBorderLineStyleItem();
            this.changeTableBorderLineWeightItem1 = new DevExpress.XtraRichEdit.UI.ChangeTableBorderLineWeightItem();
            this.changeTableBorderColorItem1 = new DevExpress.XtraRichEdit.UI.ChangeTableBorderColorItem();
            this.changeTableBordersItem1 = new DevExpress.XtraRichEdit.UI.ChangeTableBordersItem();
            this.toggleTableCellsBottomBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomBorderItem();
            this.toggleTableCellsTopBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsTopBorderItem();
            this.toggleTableCellsLeftBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsLeftBorderItem();
            this.toggleTableCellsRightBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsRightBorderItem();
            this.resetTableCellsAllBordersItem1 = new DevExpress.XtraRichEdit.UI.ResetTableCellsAllBordersItem();
            this.toggleTableCellsAllBordersItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsAllBordersItem();
            this.toggleTableCellsOutsideBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsOutsideBorderItem();
            this.toggleTableCellsInsideBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsInsideBorderItem();
            this.toggleTableCellsInsideHorizontalBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsInsideHorizontalBorderItem();
            this.toggleTableCellsInsideVerticalBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsInsideVerticalBorderItem();
            this.toggleShowTableGridLinesItem1 = new DevExpress.XtraRichEdit.UI.ToggleShowTableGridLinesItem();
            this.changeTableCellsShadingItem1 = new DevExpress.XtraRichEdit.UI.ChangeTableCellsShadingItem();
            this.repositoryItemBorderLineStyle1 = new DevExpress.XtraRichEdit.Forms.Design.RepositoryItemBorderLineStyle();
            this.repositoryItemBorderLineWeight1 = new DevExpress.XtraRichEdit.Forms.Design.RepositoryItemBorderLineWeight();
            this.tableTableRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableTableRibbonPageGroup();
            this.tableLayoutRibbonPage1 = new DevExpress.XtraRichEdit.UI.TableLayoutRibbonPage();
            this.selectTableElementsItem1 = new DevExpress.XtraRichEdit.UI.SelectTableElementsItem();
            this.selectTableCellItem1 = new DevExpress.XtraRichEdit.UI.SelectTableCellItem();
            this.selectTableColumnItem1 = new DevExpress.XtraRichEdit.UI.SelectTableColumnItem();
            this.selectTableRowItem1 = new DevExpress.XtraRichEdit.UI.SelectTableRowItem();
            this.selectTableItem1 = new DevExpress.XtraRichEdit.UI.SelectTableItem();
            this.showTablePropertiesFormItem1 = new DevExpress.XtraRichEdit.UI.ShowTablePropertiesFormItem();
            this.tableRowsAndColumnsRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableRowsAndColumnsRibbonPageGroup();
            this.deleteTableElementsItem1 = new DevExpress.XtraRichEdit.UI.DeleteTableElementsItem();
            this.showDeleteTableCellsFormItem1 = new DevExpress.XtraRichEdit.UI.ShowDeleteTableCellsFormItem();
            this.deleteTableColumnsItem1 = new DevExpress.XtraRichEdit.UI.DeleteTableColumnsItem();
            this.deleteTableRowsItem1 = new DevExpress.XtraRichEdit.UI.DeleteTableRowsItem();
            this.deleteTableItem1 = new DevExpress.XtraRichEdit.UI.DeleteTableItem();
            this.insertTableRowAboveItem1 = new DevExpress.XtraRichEdit.UI.InsertTableRowAboveItem();
            this.insertTableRowBelowItem1 = new DevExpress.XtraRichEdit.UI.InsertTableRowBelowItem();
            this.insertTableColumnToLeftItem1 = new DevExpress.XtraRichEdit.UI.InsertTableColumnToLeftItem();
            this.insertTableColumnToRightItem1 = new DevExpress.XtraRichEdit.UI.InsertTableColumnToRightItem();
            this.tableMergeRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableMergeRibbonPageGroup();
            this.mergeTableCellsItem1 = new DevExpress.XtraRichEdit.UI.MergeTableCellsItem();
            this.showSplitTableCellsForm1 = new DevExpress.XtraRichEdit.UI.ShowSplitTableCellsForm();
            this.splitTableItem1 = new DevExpress.XtraRichEdit.UI.SplitTableItem();
            this.tableCellSizeRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableCellSizeRibbonPageGroup();
            this.toggleTableAutoFitItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableAutoFitItem();
            this.toggleTableAutoFitContentsItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableAutoFitContentsItem();
            this.toggleTableAutoFitWindowItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableAutoFitWindowItem();
            this.toggleTableFixedColumnWidthItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableFixedColumnWidthItem();
            this.tableAlignmentRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableAlignmentRibbonPageGroup();
            this.toggleTableCellsTopLeftAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsTopLeftAlignmentItem();
            this.toggleTableCellsMiddleLeftAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsMiddleLeftAlignmentItem();
            this.toggleTableCellsBottomLeftAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomLeftAlignmentItem();
            this.toggleTableCellsTopCenterAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsTopCenterAlignmentItem();
            this.toggleTableCellsMiddleCenterAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsMiddleCenterAlignmentItem();
            this.toggleTableCellsBottomCenterAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomCenterAlignmentItem();
            this.toggleTableCellsTopRightAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsTopRightAlignmentItem();
            this.toggleTableCellsMiddleRightAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsMiddleRightAlignmentItem();
            this.toggleTableCellsBottomRightAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomRightAlignmentItem();
            this.showTableOptionsFormItem1 = new DevExpress.XtraRichEdit.UI.ShowTableOptionsFormItem();
            this.floatingPictureToolsShapeStylesPageGroup1 = new DevExpress.XtraRichEdit.UI.FloatingPictureToolsShapeStylesPageGroup();
            this.floatingPictureToolsFormatPage1 = new DevExpress.XtraRichEdit.UI.FloatingPictureToolsFormatPage();
            this.changeFloatingObjectFillColorItem1 = new DevExpress.XtraRichEdit.UI.ChangeFloatingObjectFillColorItem();
            this.changeFloatingObjectOutlineColorItem1 = new DevExpress.XtraRichEdit.UI.ChangeFloatingObjectOutlineColorItem();
            this.changeFloatingObjectOutlineWeightItem1 = new DevExpress.XtraRichEdit.UI.ChangeFloatingObjectOutlineWeightItem();
            this.repositoryItemFloatingObjectOutlineWeight1 = new DevExpress.XtraRichEdit.Forms.Design.RepositoryItemFloatingObjectOutlineWeight();
            this.floatingPictureToolsArrangePageGroup1 = new DevExpress.XtraRichEdit.UI.FloatingPictureToolsArrangePageGroup();
            this.changeFloatingObjectTextWrapTypeItem1 = new DevExpress.XtraRichEdit.UI.ChangeFloatingObjectTextWrapTypeItem();
            this.setFloatingObjectSquareTextWrapTypeItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectSquareTextWrapTypeItem();
            this.setFloatingObjectTightTextWrapTypeItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectTightTextWrapTypeItem();
            this.setFloatingObjectThroughTextWrapTypeItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectThroughTextWrapTypeItem();
            this.setFloatingObjectTopAndBottomTextWrapTypeItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectTopAndBottomTextWrapTypeItem();
            this.setFloatingObjectBehindTextWrapTypeItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectBehindTextWrapTypeItem();
            this.setFloatingObjectInFrontOfTextWrapTypeItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectInFrontOfTextWrapTypeItem();
            this.changeFloatingObjectAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ChangeFloatingObjectAlignmentItem();
            this.setFloatingObjectTopLeftAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectTopLeftAlignmentItem();
            this.setFloatingObjectTopCenterAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectTopCenterAlignmentItem();
            this.setFloatingObjectTopRightAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectTopRightAlignmentItem();
            this.setFloatingObjectMiddleLeftAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectMiddleLeftAlignmentItem();
            this.setFloatingObjectMiddleCenterAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectMiddleCenterAlignmentItem();
            this.setFloatingObjectMiddleRightAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectMiddleRightAlignmentItem();
            this.setFloatingObjectBottomLeftAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectBottomLeftAlignmentItem();
            this.setFloatingObjectBottomCenterAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectBottomCenterAlignmentItem();
            this.setFloatingObjectBottomRightAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectBottomRightAlignmentItem();
            this.floatingObjectBringForwardSubItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectBringForwardSubItem();
            this.floatingObjectBringForwardItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectBringForwardItem();
            this.floatingObjectBringToFrontItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectBringToFrontItem();
            this.floatingObjectBringInFrontOfTextItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectBringInFrontOfTextItem();
            this.floatingObjectSendBackwardSubItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectSendBackwardSubItem();
            this.floatingObjectSendBackwardItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectSendBackwardItem();
            this.floatingObjectSendToBackItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectSendToBackItem();
            this.floatingObjectSendBehindTextItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectSendBehindTextItem();
            this.dashboardPopupMenu1 = new DevExpress.DashboardWin.DashboardPopupMenu(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardBackstageViewControl1)).BeginInit();
            this.dashboardBackstageViewControl1.SuspendLayout();
            this.backstageViewClientControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardBarAndDockingController1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardBarController1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBoxEditorBarController1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemFontEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichEditFontSizeEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemBorderLineStyle1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemBorderLineWeight1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemFloatingObjectOutlineWeight1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardPopupMenu1)).BeginInit();
            this.SuspendLayout();
            // 
            // dashboardDesigner1
            // 
            this.dashboardDesigner1.AllowPrintDashboard = true;
            this.dashboardDesigner1.AllowPrintDashboardItems = true;
            this.dashboardDesigner1.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashboardDesigner1.Appearance.Options.UseFont = true;
            this.dashboardDesigner1.BarAndDockingController = this.dashboardBarAndDockingController1;
            this.dashboardDesigner1.Location = new System.Drawing.Point(18, 99);
            this.dashboardDesigner1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dashboardDesigner1.MenuManager = this.ribbonControl1;
            this.dashboardDesigner1.Name = "dashboardDesigner1";
            this.dashboardDesigner1.PopupMenu = this.dashboardPopupMenu1;
            this.dashboardDesigner1.Size = new System.Drawing.Size(1996, 763);
            this.dashboardDesigner1.TabIndex = 0;
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ApplicationButtonDropDownControl = this.dashboardBackstageViewControl1;
            this.ribbonControl1.Controller = this.dashboardBarAndDockingController1;
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.fileNewBarItem1,
            this.fileOpenBarItem1,
            this.fileSaveBarItem1,
            this.fileSaveAsBarItem1,
            this.quickAccessUndoBarItem1,
            this.quickAccessRedoBarItem1,
            this.undoBarItem1,
            this.redoBarItem1,
            this.insertPivotBarItem1,
            this.insertGridBarItem1,
            this.insertChartBarItem1,
            this.insertScatterChartBarItem1,
            this.insertPiesBarItem1,
            this.insertGaugesBarItem1,
            this.insertCardsBarItem1,
            this.insertTreemapBarItem1,
            this.insertChoroplethMapBarItem1,
            this.insertGeoPointMapBarSubItem1,
            this.insertGeoPointMapBarItem1,
            this.insertBubbleMapBarItem1,
            this.insertPieMapBarItem1,
            this.insertRangeFilterBarItem1,
            this.insertFilterElementSubItem1,
            this.insertComboBoxBarItem1,
            this.insertListBoxBarItem1,
            this.insertTreeViewBarItem1,
            this.insertImagesBarSubItem1,
            this.insertImageBarItem1,
            this.insertBoundImageBarItem1,
            this.insertTextBoxBarItem1,
            this.insertGroupBarItem1,
            this.duplicateItemBarItem1,
            this.deleteItemBarItem1,
            this.convertDashboardItemTypeBarItem1,
            this.convertToPivotBarItem1,
            this.convertToGridBarItem1,
            this.convertToChartBarItem1,
            this.convertToScatterChartBarItem1,
            this.convertToPieBarItem1,
            this.convertToGaugeBarItem1,
            this.convertToCardBarItem1,
            this.convertToTreemapBarItem1,
            this.convertToChoroplethMapBarItem1,
            this.convertToGeoPointMapBarItem1,
            this.convertToBubbleMapBarItem1,
            this.convertToPieMapBarItem1,
            this.convertGeoPointMapBaseBarItem1,
            this.convertToRangeFilterBarItem1,
            this.convertToComboBoxBarItem1,
            this.convertToListBoxBarItem1,
            this.convertToTreeViewBarItem1,
            this.convertToFilterElementsBaseBarItem1,
            this.convertToBoundImageBarItem1,
            this.convertToTextBoxBarItem1,
            this.removeDataItemsBarItem1,
            this.transposeItemBarItem1,
            this.editRulesBarItem1,
            this.deleteGroupBarItem1,
            this.dashboardTitleBarItem1,
            this.setCurrencyCultureBarItem1,
            this.dashboardColorSchemeBarItem1,
            this.dashboardParametersBarItem1,
            this.dashboardAutomaticUpdatesBarItem1,
            this.updateDataBarItem1,
            this.newDataSourceBarItem1,
            this.editSqlConnectionBarItem1,
            this.editOlapConnectionBarItem1,
            this.editObjectDataSourceBarItem1,
            this.editExcelDataSourceBarItem1,
            this.editEFDataSourceBarItem1,
            this.editExtractOptionsBarItem1,
            this.renameDataSourceBarItem1,
            this.deleteDataSourceBarItem1,
            this.serverModeBarItem1,
            this.upateDataExtractBarItem1,
            this.addCalculatedFieldBarItem1,
            this.addQueryBarItem1,
            this.editQueryBarItem1,
            this.renameQueryBarItem1,
            this.editQueryFilterBarItem1,
            this.deleteQueryBarItem1,
            this.editExtractSourceConnectionBarItem1,
            this.editExtractSourceBarItem1,
            this.editExtractSourceQueryBarItem1,
            this.editDataSourceFilterBarItem1,
            this.clearDataSourceFilterBarItem1,
            this.dashboardSkinsBarItem1,
            this.editFilterBarItem1,
            this.clearFilterBarItem1,
            this.ignoreMasterFiltersBarItem1,
            this.showItemCaptionBarItem1,
            this.editItemNamesBarItem1,
            this.pivotInitialStateBarItem1,
            this.pivotAutoExpandColumnBarItem1,
            this.pivotAutoExpandRowBarItem1,
            this.pivotShowTotalsBarItem1,
            this.pivotShowColumnTotalsBarItem1,
            this.pivotShowRowTotalsBarItem1,
            this.pivotShowGrandTotalsBarItem1,
            this.pivotShowColumnGrandTotalsBarItem1,
            this.pivotShowRowGrandTotalsBarItem1,
            this.pivotLayoutTypeBarItem1,
            this.pivotLayoutTypeCompactBarItem1,
            this.pivotLayoutTypeTabularBarItem1,
            this.pivotRowTotalsPositionBarItem1,
            this.pivotRowTotalsPositionTopBarItem1,
            this.pivotRowTotalsPositionBottomBarItem1,
            this.pivotColumnTotalsPositionBarItem1,
            this.pivotColumnTotalsPositionNearBarItem1,
            this.pivotColumnTotalsPositionFarBarItem1,
            this.pivotValuesPositionBarItem1,
            this.pivotValuesPositionColumnsBarItem1,
            this.pivotValuesPositionRowsBarItem1,
            this.pivotResetLayoutOptionsBarItem1,
            this.masterFilterBarItem1,
            this.multipleValuesMasterFilterBarItem1,
            this.drillDownBarItem1,
            this.crossDataSourceFilteringBarItem1,
            this.gridHorizontalLinesBarItem1,
            this.gridVerticalLinesBarItem1,
            this.gridBandedRowsBarItem1,
            this.gridMergeCellsBarItem1,
            this.gridColumnHeadersBarItem1,
            this.gridWordWrapBarItem1,
            this.gridAutoFitToContentsColumnWidthModeBarItem1,
            this.gridAutoFitToGridColumnWidthModeBarItem1,
            this.manualGridColumnWidthModeBarItem1,
            this.chartTargetDimensionsArgumentsBarItem1,
            this.chartTargetDimensionsSeriesBarItem1,
            this.chartTargetDimensionsPointsBarItem1,
            this.chartRotateBarItem1,
            this.chartXAxisSettingsBarItem1,
            this.chartYAxisSettingsBarItem1,
            this.chartShowLegendBarItem1,
            this.galleryChartLegendPositionItem1,
            this.galleryChartSeriesTypeItem1,
            this.useGlobalColorsBarItem1,
            this.useLocalColorsBarItem1,
            this.editActualColorsBarItem1,
            this.scatterChartRotateBarItem1,
            this.scatterChartXAxisSettingsBarItem1,
            this.scatterChartYAxisSettingsBarItem1,
            this.scatterChartPointLabelOptionsBarItem1,
            this.scatterChartShowLegendBarItem1,
            this.galleryScatterChartLegendPositionItem1,
            this.pieTargetDimensionsArgumentsBarItem1,
            this.pieTargetDimensionsSeriesBarItem1,
            this.pieTargetDimensionsPointsBarItem1,
            this.contentAutoArrangeBarItem1,
            this.contentArrangeInColumnsBarItem1,
            this.contentArrangeInRowsBarItem1,
            this.contentArrangementCountBarItem1,
            this.pieLabelsDataLabelsBarItem1,
            this.pieLabelsDataLabelsNoneBarItem1,
            this.pieLabelsDataLabelArgumentBarItem1,
            this.pieLabelsDataLabelsValueBarItem1,
            this.pieLabelsDataLabelsArgumentAndValueBarItem1,
            this.pieLabelsDataLabelsPercentBarItem1,
            this.pieLabelsDataLabelsValueAndPercentBarItem1,
            this.pieLabelsDataLabelsArgumentAndPercentBarItem1,
            this.pieLabelsDataLabelsArgumentValueAndPercentBarItem1,
            this.pieLabelPositionBarItem1,
            this.pieLabelPositionOutsideBarItem1,
            this.pieLabelPositionInsideBarItem1,
            this.pieTooltipsBarItem1,
            this.pieLabelsTooltipsNoneBarItem1,
            this.pieLabelsTooltipsArgumentBarItem1,
            this.pieLabelsTooltipsValueBarItem1,
            this.pieLabelsTooltipsArgumentAndValueBarItem1,
            this.pieLabelsTooltipsPercentBarItem1,
            this.pieLabelsTooltipsValueAndPercentBarItem1,
            this.pieLabelsTooltipsArgumentAndPercentBarItem1,
            this.pieLabelsTooltipsArgumentValueAndPercentBarItem1,
            this.pieStylePieBarItem1,
            this.pieStyleDonutBarItem1,
            this.pieShowCaptionsBarItem1,
            this.gaugeStyleFullCircularBarItem1,
            this.gaugeStyleHalfCircularBarItem1,
            this.gaugeStyleLeftQuarterCircularBarItem1,
            this.gaugeStyleRightQuarterCircularBarItem1,
            this.gaugeStyleThreeForthCircularBarItem1,
            this.gaugeStyleLinearHorizontalBarItem1,
            this.gaugeStyleLinearVerticalBarItem1,
            this.gaugeShowCaptionsBarItem1,
            this.galleryRangeFilterSeriesTypeItem1,
            this.rangeFilterEditDateTimePeriodsBarItem1,
            this.mapLoadBarItem1,
            this.mapImportBarItem1,
            this.mapDefaultShapefileBarItem1,
            this.mapWorldCountriesBarItem1,
            this.mapEuropeBarItem1,
            this.mapAsiaBarItem1,
            this.mapNorthAmericaBarItem1,
            this.mapSouthAmericaBarItem1,
            this.mapAfricaBarItem1,
            this.mapUSABarItem1,
            this.mapCanadaBarItem1,
            this.mapLockNavigationBarItem1,
            this.mapFullExtentBarItem1,
            this.choroplethMapShapeLabelsAttributeBarItem1,
            this.mapShowLegendBarItem1,
            this.galleryMapLegendPositionItem1,
            this.geoPointMapClusterizationBarItem1,
            this.mapShapeTitleAttributeBarItem1,
            this.changeWeightedLegendTypeBarItem1,
            this.weightedLegendNoneBarItem1,
            this.weightedLegendLinearBarItem1,
            this.weightedLegendNestedBarItem1,
            this.galleryWeightedLegendPositionItem1,
            this.pieMapIsWeightedBarItem1,
            this.comboBoxStandardTypeBarItem1,
            this.comboBoxCheckedTypeBarItem1,
            this.listBoxCheckedTypeBarItem1,
            this.listBoxRadioTypeBarItem1,
            this.filterElementShowAllValueBarItem1,
            this.filterElementEnableSearchBarItem1,
            this.treeViewAutoExpandBarItem1,
            this.imageSizeModeClipBarItem1,
            this.imageSizeModeStretchBarItem1,
            this.imageSizeModeSqueezeBarItem1,
            this.imageSizeModeZoomBarItem1,
            this.imageAlignmentTopLeftBarItem1,
            this.imageAlignmentCenterLeftBarItem1,
            this.imageAlignmentBottomLeftBarItem1,
            this.imageAlignmentTopCenterBarItem1,
            this.imageAlignmentCenterCenterBarItem1,
            this.imageAlignmentBottomCenterBarItem1,
            this.imageAlignmentTopRightBarItem1,
            this.imageAlignmentCenterRightBarItem1,
            this.imageAlignmentBottomRightBarItem1,
            this.textBoxEditTextBarItem1,
            this.textBoxInsertFieldBarItem1,
            this.treemapSliceAndDiceLayoutAlgorithmBarItem1,
            this.treemapSquarifiedLayoutAlgorithmBarItem1,
            this.treemapStripedLayoutAlgorithmBarItem1,
            this.treemapLayoutDirectionBarItem1,
            this.treemapBottomLeftToTopRightLayoutDirectionBarItem1,
            this.treemapBottomRightToTopLeftLayoutDirectionBarItem1,
            this.treemapTopLeftToBottomRightLayoutDirectionBarItem1,
            this.treemapTopRightToBottomLeftLayoutDirectionBarItem1,
            this.treemapTileLabelsBarItem1,
            this.treemapTileLabelsNoneBarItem1,
            this.treemapTileLabelsArgumentBarItem1,
            this.treemapTileLabelsValueBarItem1,
            this.treemapTileLabelsArgumentAndValueBarItem1,
            this.treemapTileTooltipsBarItem1,
            this.treemapTileTooltipsNoneBarItem1,
            this.treemapTileTooltipsArgumentBarItem1,
            this.treemapTileTooltipsValueBarItem1,
            this.treemapTileTooltipsArgumentAndValueBarItem1,
            this.treemapGroupLabelsBarItem1,
            this.treemapGroupLabelsNoneBarItem1,
            this.treemapGroupLabelsArgumentBarItem1,
            this.treemapGroupLabelsValueBarItem1,
            this.treemapGroupLabelsArgumentAndValueBarItem1,
            this.treemapGroupTooltipsBarItem1,
            this.treemapGroupTooltipsNoneBarItem1,
            this.treemapGroupTooltipsArgumentBarItem1,
            this.treemapGroupTooltipsValueBarItem1,
            this.treemapGroupTooltipsArgumentAndValueBarItem1,
            this.imageLoadBarItem1,
            this.imageImportBarItem1,
            this.groupMasterFilterBarItem1,
            this.groupIgnoreMasterFilterBarItem1,
            this.undoItem1,
            this.redoItem1,
            this.fileOpenItem1,
            this.pasteItem1,
            this.cutItem1,
            this.copyItem1,
            this.pasteSpecialItem1,
            this.barButtonGroup1,
            this.changeFontNameItem1,
            this.changeFontSizeItem1,
            this.fontSizeIncreaseItem1,
            this.fontSizeDecreaseItem1,
            this.barButtonGroup2,
            this.toggleFontBoldItem1,
            this.toggleFontItalicItem1,
            this.toggleFontUnderlineItem1,
            this.toggleFontDoubleUnderlineItem1,
            this.toggleFontStrikeoutItem1,
            this.toggleFontDoubleStrikeoutItem1,
            this.toggleFontSuperscriptItem1,
            this.toggleFontSubscriptItem1,
            this.barButtonGroup3,
            this.changeFontColorItem1,
            this.changeFontHighlightColorItem1,
            this.changeTextCaseItem1,
            this.makeTextUpperCaseItem1,
            this.makeTextLowerCaseItem1,
            this.capitalizeEachWordCaseItem1,
            this.toggleTextCaseItem1,
            this.clearFormattingItem1,
            this.barButtonGroup4,
            this.toggleBulletedListItem1,
            this.toggleNumberingListItem1,
            this.toggleMultiLevelListItem1,
            this.barButtonGroup5,
            this.decreaseIndentItem1,
            this.increaseIndentItem1,
            this.barButtonGroup6,
            this.toggleParagraphAlignmentLeftItem1,
            this.toggleParagraphAlignmentCenterItem1,
            this.toggleParagraphAlignmentRightItem1,
            this.toggleParagraphAlignmentJustifyItem1,
            this.toggleShowWhitespaceItem1,
            this.barButtonGroup7,
            this.changeParagraphLineSpacingItem1,
            this.setSingleParagraphSpacingItem1,
            this.setSesquialteralParagraphSpacingItem1,
            this.setDoubleParagraphSpacingItem1,
            this.showLineSpacingFormItem1,
            this.addSpacingBeforeParagraphItem1,
            this.removeSpacingBeforeParagraphItem1,
            this.addSpacingAfterParagraphItem1,
            this.removeSpacingAfterParagraphItem1,
            this.changeParagraphBackColorItem1,
            this.galleryChangeStyleItem1,
            this.findItem1,
            this.replaceItem1,
            this.insertTableItem1,
            this.insertPictureItem1,
            this.insertFloatingPictureItem1,
            this.insertBookmarkItem1,
            this.insertHyperlinkItem1,
            this.insertSymbolItem1,
            this.changePageColorItem1,
            this.toggleFirstRowItem1,
            this.toggleLastRowItem1,
            this.toggleBandedRowsItem1,
            this.toggleFirstColumnItem1,
            this.toggleLastColumnItem1,
            this.toggleBandedColumnsItem1,
            this.galleryChangeTableStyleItem1,
            this.changeTableBorderLineStyleItem1,
            this.changeTableBorderLineWeightItem1,
            this.changeTableBorderColorItem1,
            this.changeTableBordersItem1,
            this.toggleTableCellsBottomBorderItem1,
            this.toggleTableCellsTopBorderItem1,
            this.toggleTableCellsLeftBorderItem1,
            this.toggleTableCellsRightBorderItem1,
            this.resetTableCellsAllBordersItem1,
            this.toggleTableCellsAllBordersItem1,
            this.toggleTableCellsOutsideBorderItem1,
            this.toggleTableCellsInsideBorderItem1,
            this.toggleTableCellsInsideHorizontalBorderItem1,
            this.toggleTableCellsInsideVerticalBorderItem1,
            this.toggleShowTableGridLinesItem1,
            this.changeTableCellsShadingItem1,
            this.selectTableElementsItem1,
            this.selectTableCellItem1,
            this.selectTableColumnItem1,
            this.selectTableRowItem1,
            this.selectTableItem1,
            this.showTablePropertiesFormItem1,
            this.deleteTableElementsItem1,
            this.showDeleteTableCellsFormItem1,
            this.deleteTableColumnsItem1,
            this.deleteTableRowsItem1,
            this.deleteTableItem1,
            this.insertTableRowAboveItem1,
            this.insertTableRowBelowItem1,
            this.insertTableColumnToLeftItem1,
            this.insertTableColumnToRightItem1,
            this.mergeTableCellsItem1,
            this.showSplitTableCellsForm1,
            this.splitTableItem1,
            this.toggleTableAutoFitItem1,
            this.toggleTableAutoFitContentsItem1,
            this.toggleTableAutoFitWindowItem1,
            this.toggleTableFixedColumnWidthItem1,
            this.toggleTableCellsTopLeftAlignmentItem1,
            this.toggleTableCellsMiddleLeftAlignmentItem1,
            this.toggleTableCellsBottomLeftAlignmentItem1,
            this.toggleTableCellsTopCenterAlignmentItem1,
            this.toggleTableCellsMiddleCenterAlignmentItem1,
            this.toggleTableCellsBottomCenterAlignmentItem1,
            this.toggleTableCellsTopRightAlignmentItem1,
            this.toggleTableCellsMiddleRightAlignmentItem1,
            this.toggleTableCellsBottomRightAlignmentItem1,
            this.showTableOptionsFormItem1,
            this.changeFloatingObjectFillColorItem1,
            this.changeFloatingObjectOutlineColorItem1,
            this.changeFloatingObjectOutlineWeightItem1,
            this.changeFloatingObjectTextWrapTypeItem1,
            this.setFloatingObjectSquareTextWrapTypeItem1,
            this.setFloatingObjectTightTextWrapTypeItem1,
            this.setFloatingObjectThroughTextWrapTypeItem1,
            this.setFloatingObjectTopAndBottomTextWrapTypeItem1,
            this.setFloatingObjectBehindTextWrapTypeItem1,
            this.setFloatingObjectInFrontOfTextWrapTypeItem1,
            this.changeFloatingObjectAlignmentItem1,
            this.setFloatingObjectTopLeftAlignmentItem1,
            this.setFloatingObjectTopCenterAlignmentItem1,
            this.setFloatingObjectTopRightAlignmentItem1,
            this.setFloatingObjectMiddleLeftAlignmentItem1,
            this.setFloatingObjectMiddleCenterAlignmentItem1,
            this.setFloatingObjectMiddleRightAlignmentItem1,
            this.setFloatingObjectBottomLeftAlignmentItem1,
            this.setFloatingObjectBottomCenterAlignmentItem1,
            this.setFloatingObjectBottomRightAlignmentItem1,
            this.floatingObjectBringForwardSubItem1,
            this.floatingObjectBringForwardItem1,
            this.floatingObjectBringToFrontItem1,
            this.floatingObjectBringInFrontOfTextItem1,
            this.floatingObjectSendBackwardSubItem1,
            this.floatingObjectSendBackwardItem1,
            this.floatingObjectSendToBackItem1,
            this.floatingObjectSendBehindTextItem1});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.MaxItemId = 412;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.PageCategories.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageCategory[] {
            this.pivotToolsRibbonPageCategory1,
            this.gridToolsRibbonPageCategory1,
            this.chartToolsRibbonPageCategory1,
            this.scatterChartToolsRibbonPageCategory1,
            this.piesToolsRibbonPageCategory1,
            this.gaugesToolsRibbonPageCategory1,
            this.cardsToolsRibbonPageCategory1,
            this.rangeFilterToolsRibbonPageCategory1,
            this.choroplethMapToolsRibbonPageCategory1,
            this.geoPointMapToolsRibbonPageCategory1,
            this.bubbleMapToolsRibbonPageCategory1,
            this.pieMapToolsRibbonPageCategory1,
            this.filterElementToolsRibbonPageCategory1,
            this.boundImageToolsRibbonPageCategory1,
            this.textBoxToolsRibbonPageCategory1,
            this.treemapToolsRibbonPageCategory1,
            this.imageToolsRibbonPageCategory1,
            this.groupToolsRibbonPageCategory1,
            this.textBoxEditorRibbonPageCategory1});
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.homeRibbonPage1,
            this.dataSourceRibbonPage1,
            this.viewRibbonPage1});
            this.ribbonControl1.QuickToolbarItemLinks.Add(this.fileSaveBarItem1);
            this.ribbonControl1.QuickToolbarItemLinks.Add(this.quickAccessUndoBarItem1);
            this.ribbonControl1.QuickToolbarItemLinks.Add(this.quickAccessRedoBarItem1);
            this.ribbonControl1.QuickToolbarItemLinks.Add(this.updateDataBarItem1);
            this.ribbonControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemSpinEdit1,
            this.repositoryItemFontEdit1,
            this.repositoryItemRichEditFontSizeEdit1,
            this.repositoryItemBorderLineStyle1,
            this.repositoryItemBorderLineWeight1,
            this.repositoryItemFloatingObjectOutlineWeight1});
            this.ribbonControl1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.Office2010;
            this.ribbonControl1.Size = new System.Drawing.Size(1370, 141);
            this.ribbonControl1.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Above;
            // 
            // dashboardBackstageViewControl1
            // 
            this.dashboardBackstageViewControl1.Controller = this.dashboardBarAndDockingController1;
            this.dashboardBackstageViewControl1.Controls.Add(this.backstageViewClientControl1);
            this.dashboardBackstageViewControl1.DashboardRecentTab = this.dashboardBackstageRecentTab1;
            this.dashboardBackstageViewControl1.Items.Add(this.dashboardBackstageNewButton1);
            this.dashboardBackstageViewControl1.Items.Add(this.dashboardBackstageOpenButton1);
            this.dashboardBackstageViewControl1.Items.Add(this.dashboardBackstageSaveButton1);
            this.dashboardBackstageViewControl1.Items.Add(this.dashboardBackstageSaveAsButton1);
            this.dashboardBackstageViewControl1.Items.Add(this.dashboardBackstageRecentTab1);
            this.dashboardBackstageViewControl1.Location = new System.Drawing.Point(0, 0);
            this.dashboardBackstageViewControl1.Name = "dashboardBackstageViewControl1";
            this.dashboardBackstageViewControl1.OwnerControl = this.ribbonControl1;
            this.dashboardBackstageViewControl1.SelectedTab = this.dashboardBackstageRecentTab1;
            this.dashboardBackstageViewControl1.SelectedTabIndex = 4;
            this.dashboardBackstageViewControl1.Size = new System.Drawing.Size(240, 150);
            this.dashboardBackstageViewControl1.TabIndex = 2;
            // 
            // dashboardBackstageNewButton1
            // 
            this.dashboardBackstageNewButton1.Glyph = ((System.Drawing.Image)(resources.GetObject("dashboardBackstageNewButton1.Glyph")));
            this.dashboardBackstageNewButton1.Name = "dashboardBackstageNewButton1";
            this.dashboardBackstageNewButton1.ServiceProvider = this.dashboardDesigner1;
            // 
            // dashboardBackstageOpenButton1
            // 
            this.dashboardBackstageOpenButton1.Glyph = ((System.Drawing.Image)(resources.GetObject("dashboardBackstageOpenButton1.Glyph")));
            this.dashboardBackstageOpenButton1.Name = "dashboardBackstageOpenButton1";
            this.dashboardBackstageOpenButton1.ServiceProvider = this.dashboardDesigner1;
            // 
            // dashboardBackstageSaveButton1
            // 
            this.dashboardBackstageSaveButton1.Glyph = ((System.Drawing.Image)(resources.GetObject("dashboardBackstageSaveButton1.Glyph")));
            this.dashboardBackstageSaveButton1.Name = "dashboardBackstageSaveButton1";
            this.dashboardBackstageSaveButton1.ServiceProvider = this.dashboardDesigner1;
            // 
            // dashboardBackstageSaveAsButton1
            // 
            this.dashboardBackstageSaveAsButton1.Glyph = ((System.Drawing.Image)(resources.GetObject("dashboardBackstageSaveAsButton1.Glyph")));
            this.dashboardBackstageSaveAsButton1.Name = "dashboardBackstageSaveAsButton1";
            this.dashboardBackstageSaveAsButton1.ServiceProvider = this.dashboardDesigner1;
            // 
            // dashboardBackstageRecentTab1
            // 
            this.dashboardBackstageRecentTab1.ContentControl = this.backstageViewClientControl1;
            this.dashboardBackstageRecentTab1.Name = "dashboardBackstageRecentTab1";
            this.dashboardBackstageRecentTab1.RecentDashboardsControl = this.recentDashboardsControl1;
            this.dashboardBackstageRecentTab1.Selected = true;
            // 
            // backstageViewClientControl1
            // 
            this.backstageViewClientControl1.Controls.Add(this.recentDashboardsControl1);
            this.backstageViewClientControl1.Location = new System.Drawing.Point(0, 0);
            this.backstageViewClientControl1.Name = "backstageViewClientControl1";
            this.backstageViewClientControl1.Size = new System.Drawing.Size(150, 150);
            this.backstageViewClientControl1.TabIndex = 1;
            // 
            // recentDashboardsControl1
            // 
            this.recentDashboardsControl1.Appearance.ForeColor = System.Drawing.Color.Transparent;
            this.recentDashboardsControl1.Appearance.Options.UseForeColor = true;
            this.recentDashboardsControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.recentDashboardsControl1.Location = new System.Drawing.Point(0, 0);
            this.recentDashboardsControl1.Name = "recentDashboardsControl1";
            this.recentDashboardsControl1.ServiceProvider = this.dashboardDesigner1;
            this.recentDashboardsControl1.Size = new System.Drawing.Size(150, 150);
            this.recentDashboardsControl1.TabIndex = 0;
            // 
            // dashboardBarAndDockingController1
            // 
            this.dashboardBarAndDockingController1.PropertiesBar.DefaultGlyphSize = new System.Drawing.Size(16, 16);
            this.dashboardBarAndDockingController1.PropertiesBar.DefaultLargeGlyphSize = new System.Drawing.Size(32, 32);
            // 
            // dashboardBarController1
            // 
            this.dashboardBarController1.BarItems.Add(this.fileNewBarItem1);
            this.dashboardBarController1.BarItems.Add(this.fileOpenBarItem1);
            this.dashboardBarController1.BarItems.Add(this.fileSaveBarItem1);
            this.dashboardBarController1.BarItems.Add(this.fileSaveAsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.quickAccessUndoBarItem1);
            this.dashboardBarController1.BarItems.Add(this.quickAccessRedoBarItem1);
            this.dashboardBarController1.BarItems.Add(this.undoBarItem1);
            this.dashboardBarController1.BarItems.Add(this.redoBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertPivotBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertGridBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertChartBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertScatterChartBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertPiesBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertGaugesBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertCardsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertTreemapBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertChoroplethMapBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertGeoPointMapBarSubItem1);
            this.dashboardBarController1.BarItems.Add(this.insertGeoPointMapBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertBubbleMapBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertPieMapBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertRangeFilterBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertFilterElementSubItem1);
            this.dashboardBarController1.BarItems.Add(this.insertComboBoxBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertListBoxBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertTreeViewBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertImagesBarSubItem1);
            this.dashboardBarController1.BarItems.Add(this.insertImageBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertBoundImageBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertTextBoxBarItem1);
            this.dashboardBarController1.BarItems.Add(this.insertGroupBarItem1);
            this.dashboardBarController1.BarItems.Add(this.duplicateItemBarItem1);
            this.dashboardBarController1.BarItems.Add(this.deleteItemBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertDashboardItemTypeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToPivotBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToGridBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToChartBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToScatterChartBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToPieBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToGaugeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToCardBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToTreemapBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToChoroplethMapBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertGeoPointMapBaseBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToGeoPointMapBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToBubbleMapBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToPieMapBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToRangeFilterBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToFilterElementsBaseBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToComboBoxBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToListBoxBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToTreeViewBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToBoundImageBarItem1);
            this.dashboardBarController1.BarItems.Add(this.convertToTextBoxBarItem1);
            this.dashboardBarController1.BarItems.Add(this.removeDataItemsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.transposeItemBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editRulesBarItem1);
            this.dashboardBarController1.BarItems.Add(this.deleteGroupBarItem1);
            this.dashboardBarController1.BarItems.Add(this.dashboardTitleBarItem1);
            this.dashboardBarController1.BarItems.Add(this.setCurrencyCultureBarItem1);
            this.dashboardBarController1.BarItems.Add(this.dashboardColorSchemeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.dashboardParametersBarItem1);
            this.dashboardBarController1.BarItems.Add(this.dashboardAutomaticUpdatesBarItem1);
            this.dashboardBarController1.BarItems.Add(this.updateDataBarItem1);
            this.dashboardBarController1.BarItems.Add(this.newDataSourceBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editSqlConnectionBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editOlapConnectionBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editObjectDataSourceBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editExcelDataSourceBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editEFDataSourceBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editExtractOptionsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.renameDataSourceBarItem1);
            this.dashboardBarController1.BarItems.Add(this.deleteDataSourceBarItem1);
            this.dashboardBarController1.BarItems.Add(this.serverModeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.upateDataExtractBarItem1);
            this.dashboardBarController1.BarItems.Add(this.addCalculatedFieldBarItem1);
            this.dashboardBarController1.BarItems.Add(this.addQueryBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editQueryBarItem1);
            this.dashboardBarController1.BarItems.Add(this.renameQueryBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editQueryFilterBarItem1);
            this.dashboardBarController1.BarItems.Add(this.deleteQueryBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editExtractSourceConnectionBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editExtractSourceBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editExtractSourceQueryBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editDataSourceFilterBarItem1);
            this.dashboardBarController1.BarItems.Add(this.clearDataSourceFilterBarItem1);
            this.dashboardBarController1.BarItems.Add(this.dashboardSkinsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editFilterBarItem1);
            this.dashboardBarController1.BarItems.Add(this.clearFilterBarItem1);
            this.dashboardBarController1.BarItems.Add(this.ignoreMasterFiltersBarItem1);
            this.dashboardBarController1.BarItems.Add(this.showItemCaptionBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editItemNamesBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotInitialStateBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotAutoExpandColumnBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotAutoExpandRowBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotShowTotalsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotShowColumnTotalsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotShowRowTotalsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotShowGrandTotalsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotShowColumnGrandTotalsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotShowRowGrandTotalsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotLayoutTypeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotLayoutTypeCompactBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotLayoutTypeTabularBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotRowTotalsPositionBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotRowTotalsPositionTopBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotRowTotalsPositionBottomBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotColumnTotalsPositionBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotColumnTotalsPositionNearBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotColumnTotalsPositionFarBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotValuesPositionBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotValuesPositionColumnsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotValuesPositionRowsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pivotResetLayoutOptionsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.masterFilterBarItem1);
            this.dashboardBarController1.BarItems.Add(this.multipleValuesMasterFilterBarItem1);
            this.dashboardBarController1.BarItems.Add(this.drillDownBarItem1);
            this.dashboardBarController1.BarItems.Add(this.crossDataSourceFilteringBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gridHorizontalLinesBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gridVerticalLinesBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gridBandedRowsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gridMergeCellsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gridColumnHeadersBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gridWordWrapBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gridAutoFitToContentsColumnWidthModeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gridAutoFitToGridColumnWidthModeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.manualGridColumnWidthModeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.chartTargetDimensionsArgumentsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.chartTargetDimensionsSeriesBarItem1);
            this.dashboardBarController1.BarItems.Add(this.chartTargetDimensionsPointsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.chartRotateBarItem1);
            this.dashboardBarController1.BarItems.Add(this.chartXAxisSettingsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.chartYAxisSettingsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.chartShowLegendBarItem1);
            this.dashboardBarController1.BarItems.Add(this.galleryChartLegendPositionItem1);
            this.dashboardBarController1.BarItems.Add(this.galleryChartSeriesTypeItem1);
            this.dashboardBarController1.BarItems.Add(this.useGlobalColorsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.useLocalColorsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.editActualColorsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.scatterChartRotateBarItem1);
            this.dashboardBarController1.BarItems.Add(this.scatterChartXAxisSettingsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.scatterChartYAxisSettingsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.scatterChartPointLabelOptionsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.scatterChartShowLegendBarItem1);
            this.dashboardBarController1.BarItems.Add(this.galleryScatterChartLegendPositionItem1);
            this.dashboardBarController1.BarItems.Add(this.pieTargetDimensionsArgumentsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieTargetDimensionsSeriesBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieTargetDimensionsPointsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.contentAutoArrangeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.contentArrangeInColumnsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.contentArrangeInRowsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.contentArrangementCountBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsDataLabelsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsDataLabelsNoneBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsDataLabelArgumentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsDataLabelsValueBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsDataLabelsArgumentAndValueBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsDataLabelsPercentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsDataLabelsValueAndPercentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsDataLabelsArgumentAndPercentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsDataLabelsArgumentValueAndPercentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelPositionBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelPositionOutsideBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelPositionInsideBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieTooltipsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsTooltipsNoneBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsTooltipsArgumentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsTooltipsValueBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsTooltipsArgumentAndValueBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsTooltipsPercentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsTooltipsValueAndPercentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsTooltipsArgumentAndPercentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieLabelsTooltipsArgumentValueAndPercentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieStylePieBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieStyleDonutBarItem1);
            this.dashboardBarController1.BarItems.Add(this.pieShowCaptionsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gaugeStyleFullCircularBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gaugeStyleHalfCircularBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gaugeStyleLeftQuarterCircularBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gaugeStyleRightQuarterCircularBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gaugeStyleThreeForthCircularBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gaugeStyleLinearHorizontalBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gaugeStyleLinearVerticalBarItem1);
            this.dashboardBarController1.BarItems.Add(this.gaugeShowCaptionsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.galleryRangeFilterSeriesTypeItem1);
            this.dashboardBarController1.BarItems.Add(this.rangeFilterEditDateTimePeriodsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapLoadBarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapImportBarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapDefaultShapefileBarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapWorldCountriesBarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapEuropeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapAsiaBarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapNorthAmericaBarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapSouthAmericaBarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapAfricaBarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapUSABarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapCanadaBarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapLockNavigationBarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapFullExtentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.choroplethMapShapeLabelsAttributeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapShowLegendBarItem1);
            this.dashboardBarController1.BarItems.Add(this.galleryMapLegendPositionItem1);
            this.dashboardBarController1.BarItems.Add(this.geoPointMapClusterizationBarItem1);
            this.dashboardBarController1.BarItems.Add(this.mapShapeTitleAttributeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.changeWeightedLegendTypeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.weightedLegendNoneBarItem1);
            this.dashboardBarController1.BarItems.Add(this.weightedLegendLinearBarItem1);
            this.dashboardBarController1.BarItems.Add(this.weightedLegendNestedBarItem1);
            this.dashboardBarController1.BarItems.Add(this.galleryWeightedLegendPositionItem1);
            this.dashboardBarController1.BarItems.Add(this.pieMapIsWeightedBarItem1);
            this.dashboardBarController1.BarItems.Add(this.comboBoxStandardTypeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.comboBoxCheckedTypeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.listBoxCheckedTypeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.listBoxRadioTypeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.filterElementShowAllValueBarItem1);
            this.dashboardBarController1.BarItems.Add(this.filterElementEnableSearchBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treeViewAutoExpandBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageSizeModeClipBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageSizeModeStretchBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageSizeModeSqueezeBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageSizeModeZoomBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageAlignmentTopLeftBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageAlignmentCenterLeftBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageAlignmentBottomLeftBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageAlignmentTopCenterBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageAlignmentCenterCenterBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageAlignmentBottomCenterBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageAlignmentTopRightBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageAlignmentCenterRightBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageAlignmentBottomRightBarItem1);
            this.dashboardBarController1.BarItems.Add(this.textBoxEditTextBarItem1);
            this.dashboardBarController1.BarItems.Add(this.textBoxInsertFieldBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapSliceAndDiceLayoutAlgorithmBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapSquarifiedLayoutAlgorithmBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapStripedLayoutAlgorithmBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapLayoutDirectionBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapBottomLeftToTopRightLayoutDirectionBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapBottomRightToTopLeftLayoutDirectionBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapTopLeftToBottomRightLayoutDirectionBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapTopRightToBottomLeftLayoutDirectionBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapTileLabelsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapTileLabelsNoneBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapTileLabelsArgumentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapTileLabelsValueBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapTileLabelsArgumentAndValueBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapTileTooltipsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapTileTooltipsNoneBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapTileTooltipsArgumentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapTileTooltipsValueBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapTileTooltipsArgumentAndValueBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapGroupLabelsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapGroupLabelsNoneBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapGroupLabelsArgumentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapGroupLabelsValueBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapGroupLabelsArgumentAndValueBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapGroupTooltipsBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapGroupTooltipsNoneBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapGroupTooltipsArgumentBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapGroupTooltipsValueBarItem1);
            this.dashboardBarController1.BarItems.Add(this.treemapGroupTooltipsArgumentAndValueBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageLoadBarItem1);
            this.dashboardBarController1.BarItems.Add(this.imageImportBarItem1);
            this.dashboardBarController1.BarItems.Add(this.groupMasterFilterBarItem1);
            this.dashboardBarController1.BarItems.Add(this.groupIgnoreMasterFilterBarItem1);
            this.dashboardBarController1.Control = this.dashboardDesigner1;
            // 
            // fileRibbonPageGroup1
            // 
            this.fileRibbonPageGroup1.ItemLinks.Add(this.fileNewBarItem1);
            this.fileRibbonPageGroup1.ItemLinks.Add(this.fileOpenBarItem1);
            this.fileRibbonPageGroup1.ItemLinks.Add(this.fileSaveBarItem1);
            this.fileRibbonPageGroup1.ItemLinks.Add(this.fileSaveAsBarItem1);
            this.fileRibbonPageGroup1.Name = "fileRibbonPageGroup1";
            // 
            // homeRibbonPage1
            // 
            this.homeRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.fileRibbonPageGroup1,
            this.quickAccessHistoryRibbonPageGroup1,
            this.historyRibbonPageGroup1,
            this.insertRibbonPageGroup1,
            this.itemOperationRibbonPageGroup1,
            this.groupOperationRibbonPageGroup1,
            this.dashboardDesignRibbonPageGroup1});
            this.homeRibbonPage1.Name = "homeRibbonPage1";
            // 
            // fileNewBarItem1
            // 
            this.fileNewBarItem1.Id = 1;
            this.fileNewBarItem1.Name = "fileNewBarItem1";
            // 
            // fileOpenBarItem1
            // 
            this.fileOpenBarItem1.Id = 2;
            this.fileOpenBarItem1.Name = "fileOpenBarItem1";
            // 
            // fileSaveBarItem1
            // 
            this.fileSaveBarItem1.Id = 3;
            this.fileSaveBarItem1.Name = "fileSaveBarItem1";
            // 
            // fileSaveAsBarItem1
            // 
            this.fileSaveAsBarItem1.Id = 4;
            this.fileSaveAsBarItem1.Name = "fileSaveAsBarItem1";
            // 
            // quickAccessHistoryRibbonPageGroup1
            // 
            this.quickAccessHistoryRibbonPageGroup1.ItemLinks.Add(this.quickAccessUndoBarItem1);
            this.quickAccessHistoryRibbonPageGroup1.ItemLinks.Add(this.quickAccessRedoBarItem1);
            this.quickAccessHistoryRibbonPageGroup1.Name = "quickAccessHistoryRibbonPageGroup1";
            this.quickAccessHistoryRibbonPageGroup1.Visible = false;
            // 
            // quickAccessUndoBarItem1
            // 
            this.quickAccessUndoBarItem1.Id = 5;
            this.quickAccessUndoBarItem1.Name = "quickAccessUndoBarItem1";
            // 
            // quickAccessRedoBarItem1
            // 
            this.quickAccessRedoBarItem1.Id = 6;
            this.quickAccessRedoBarItem1.Name = "quickAccessRedoBarItem1";
            // 
            // historyRibbonPageGroup1
            // 
            this.historyRibbonPageGroup1.ItemLinks.Add(this.undoBarItem1);
            this.historyRibbonPageGroup1.ItemLinks.Add(this.redoBarItem1);
            this.historyRibbonPageGroup1.Name = "historyRibbonPageGroup1";
            // 
            // undoBarItem1
            // 
            this.undoBarItem1.Id = 7;
            this.undoBarItem1.Name = "undoBarItem1";
            // 
            // redoBarItem1
            // 
            this.redoBarItem1.Id = 8;
            this.redoBarItem1.Name = "redoBarItem1";
            // 
            // insertRibbonPageGroup1
            // 
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertPivotBarItem1);
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertGridBarItem1);
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertChartBarItem1);
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertScatterChartBarItem1);
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertPiesBarItem1);
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertGaugesBarItem1);
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertCardsBarItem1);
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertTreemapBarItem1);
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertChoroplethMapBarItem1);
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertGeoPointMapBarSubItem1);
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertRangeFilterBarItem1);
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertFilterElementSubItem1);
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertImagesBarSubItem1);
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertTextBoxBarItem1);
            this.insertRibbonPageGroup1.ItemLinks.Add(this.insertGroupBarItem1);
            this.insertRibbonPageGroup1.Name = "insertRibbonPageGroup1";
            // 
            // insertPivotBarItem1
            // 
            this.insertPivotBarItem1.Id = 9;
            this.insertPivotBarItem1.Name = "insertPivotBarItem1";
            // 
            // insertGridBarItem1
            // 
            this.insertGridBarItem1.Id = 10;
            this.insertGridBarItem1.Name = "insertGridBarItem1";
            // 
            // insertChartBarItem1
            // 
            this.insertChartBarItem1.Id = 11;
            this.insertChartBarItem1.Name = "insertChartBarItem1";
            // 
            // insertScatterChartBarItem1
            // 
            this.insertScatterChartBarItem1.Id = 12;
            this.insertScatterChartBarItem1.Name = "insertScatterChartBarItem1";
            // 
            // insertPiesBarItem1
            // 
            this.insertPiesBarItem1.Id = 13;
            this.insertPiesBarItem1.Name = "insertPiesBarItem1";
            // 
            // insertGaugesBarItem1
            // 
            this.insertGaugesBarItem1.Id = 14;
            this.insertGaugesBarItem1.Name = "insertGaugesBarItem1";
            // 
            // insertCardsBarItem1
            // 
            this.insertCardsBarItem1.Id = 15;
            this.insertCardsBarItem1.Name = "insertCardsBarItem1";
            // 
            // insertTreemapBarItem1
            // 
            this.insertTreemapBarItem1.Id = 16;
            this.insertTreemapBarItem1.Name = "insertTreemapBarItem1";
            // 
            // insertChoroplethMapBarItem1
            // 
            this.insertChoroplethMapBarItem1.Id = 17;
            this.insertChoroplethMapBarItem1.Name = "insertChoroplethMapBarItem1";
            // 
            // insertGeoPointMapBarSubItem1
            // 
            this.insertGeoPointMapBarSubItem1.Id = 18;
            this.insertGeoPointMapBarSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.insertGeoPointMapBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertBubbleMapBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertPieMapBarItem1)});
            this.insertGeoPointMapBarSubItem1.Name = "insertGeoPointMapBarSubItem1";
            this.insertGeoPointMapBarSubItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // insertGeoPointMapBarItem1
            // 
            this.insertGeoPointMapBarItem1.Id = 19;
            this.insertGeoPointMapBarItem1.Name = "insertGeoPointMapBarItem1";
            // 
            // insertBubbleMapBarItem1
            // 
            this.insertBubbleMapBarItem1.Id = 20;
            this.insertBubbleMapBarItem1.Name = "insertBubbleMapBarItem1";
            // 
            // insertPieMapBarItem1
            // 
            this.insertPieMapBarItem1.Id = 21;
            this.insertPieMapBarItem1.Name = "insertPieMapBarItem1";
            // 
            // insertRangeFilterBarItem1
            // 
            this.insertRangeFilterBarItem1.Id = 22;
            this.insertRangeFilterBarItem1.Name = "insertRangeFilterBarItem1";
            // 
            // insertFilterElementSubItem1
            // 
            this.insertFilterElementSubItem1.Id = 23;
            this.insertFilterElementSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.insertComboBoxBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertListBoxBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertTreeViewBarItem1)});
            this.insertFilterElementSubItem1.Name = "insertFilterElementSubItem1";
            this.insertFilterElementSubItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // insertComboBoxBarItem1
            // 
            this.insertComboBoxBarItem1.Id = 24;
            this.insertComboBoxBarItem1.Name = "insertComboBoxBarItem1";
            // 
            // insertListBoxBarItem1
            // 
            this.insertListBoxBarItem1.Id = 25;
            this.insertListBoxBarItem1.Name = "insertListBoxBarItem1";
            // 
            // insertTreeViewBarItem1
            // 
            this.insertTreeViewBarItem1.Id = 26;
            this.insertTreeViewBarItem1.Name = "insertTreeViewBarItem1";
            // 
            // insertImagesBarSubItem1
            // 
            this.insertImagesBarSubItem1.Id = 27;
            this.insertImagesBarSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.insertImageBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertBoundImageBarItem1)});
            this.insertImagesBarSubItem1.Name = "insertImagesBarSubItem1";
            this.insertImagesBarSubItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // insertImageBarItem1
            // 
            this.insertImageBarItem1.Id = 28;
            this.insertImageBarItem1.Name = "insertImageBarItem1";
            // 
            // insertBoundImageBarItem1
            // 
            this.insertBoundImageBarItem1.Id = 29;
            this.insertBoundImageBarItem1.Name = "insertBoundImageBarItem1";
            // 
            // insertTextBoxBarItem1
            // 
            this.insertTextBoxBarItem1.Id = 30;
            this.insertTextBoxBarItem1.Name = "insertTextBoxBarItem1";
            // 
            // insertGroupBarItem1
            // 
            this.insertGroupBarItem1.Id = 31;
            this.insertGroupBarItem1.Name = "insertGroupBarItem1";
            // 
            // itemOperationRibbonPageGroup1
            // 
            this.itemOperationRibbonPageGroup1.ItemLinks.Add(this.duplicateItemBarItem1);
            this.itemOperationRibbonPageGroup1.ItemLinks.Add(this.deleteItemBarItem1);
            this.itemOperationRibbonPageGroup1.ItemLinks.Add(this.convertDashboardItemTypeBarItem1);
            this.itemOperationRibbonPageGroup1.ItemLinks.Add(this.removeDataItemsBarItem1);
            this.itemOperationRibbonPageGroup1.ItemLinks.Add(this.transposeItemBarItem1);
            this.itemOperationRibbonPageGroup1.ItemLinks.Add(this.editRulesBarItem1);
            this.itemOperationRibbonPageGroup1.Name = "itemOperationRibbonPageGroup1";
            this.itemOperationRibbonPageGroup1.Visible = false;
            // 
            // duplicateItemBarItem1
            // 
            this.duplicateItemBarItem1.Id = 32;
            this.duplicateItemBarItem1.Name = "duplicateItemBarItem1";
            // 
            // deleteItemBarItem1
            // 
            this.deleteItemBarItem1.Id = 33;
            this.deleteItemBarItem1.Name = "deleteItemBarItem1";
            // 
            // convertDashboardItemTypeBarItem1
            // 
            this.convertDashboardItemTypeBarItem1.Id = 34;
            this.convertDashboardItemTypeBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToPivotBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToGridBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToChartBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToScatterChartBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToPieBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToGaugeBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToCardBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToTreemapBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToChoroplethMapBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertGeoPointMapBaseBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToRangeFilterBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToFilterElementsBaseBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToBoundImageBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToTextBoxBarItem1)});
            this.convertDashboardItemTypeBarItem1.Name = "convertDashboardItemTypeBarItem1";
            // 
            // convertToPivotBarItem1
            // 
            this.convertToPivotBarItem1.Id = 35;
            this.convertToPivotBarItem1.Name = "convertToPivotBarItem1";
            // 
            // convertToGridBarItem1
            // 
            this.convertToGridBarItem1.Id = 36;
            this.convertToGridBarItem1.Name = "convertToGridBarItem1";
            // 
            // convertToChartBarItem1
            // 
            this.convertToChartBarItem1.Id = 37;
            this.convertToChartBarItem1.Name = "convertToChartBarItem1";
            // 
            // convertToScatterChartBarItem1
            // 
            this.convertToScatterChartBarItem1.Id = 38;
            this.convertToScatterChartBarItem1.Name = "convertToScatterChartBarItem1";
            // 
            // convertToPieBarItem1
            // 
            this.convertToPieBarItem1.Id = 39;
            this.convertToPieBarItem1.Name = "convertToPieBarItem1";
            // 
            // convertToGaugeBarItem1
            // 
            this.convertToGaugeBarItem1.Id = 40;
            this.convertToGaugeBarItem1.Name = "convertToGaugeBarItem1";
            // 
            // convertToCardBarItem1
            // 
            this.convertToCardBarItem1.Id = 41;
            this.convertToCardBarItem1.Name = "convertToCardBarItem1";
            // 
            // convertToTreemapBarItem1
            // 
            this.convertToTreemapBarItem1.Id = 42;
            this.convertToTreemapBarItem1.Name = "convertToTreemapBarItem1";
            // 
            // convertToChoroplethMapBarItem1
            // 
            this.convertToChoroplethMapBarItem1.Id = 43;
            this.convertToChoroplethMapBarItem1.Name = "convertToChoroplethMapBarItem1";
            // 
            // convertGeoPointMapBaseBarItem1
            // 
            this.convertGeoPointMapBaseBarItem1.Id = 44;
            this.convertGeoPointMapBaseBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToGeoPointMapBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToBubbleMapBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToPieMapBarItem1)});
            this.convertGeoPointMapBaseBarItem1.Name = "convertGeoPointMapBaseBarItem1";
            // 
            // convertToGeoPointMapBarItem1
            // 
            this.convertToGeoPointMapBarItem1.Id = 45;
            this.convertToGeoPointMapBarItem1.Name = "convertToGeoPointMapBarItem1";
            // 
            // convertToBubbleMapBarItem1
            // 
            this.convertToBubbleMapBarItem1.Id = 46;
            this.convertToBubbleMapBarItem1.Name = "convertToBubbleMapBarItem1";
            // 
            // convertToPieMapBarItem1
            // 
            this.convertToPieMapBarItem1.Id = 47;
            this.convertToPieMapBarItem1.Name = "convertToPieMapBarItem1";
            // 
            // convertToRangeFilterBarItem1
            // 
            this.convertToRangeFilterBarItem1.Id = 48;
            this.convertToRangeFilterBarItem1.Name = "convertToRangeFilterBarItem1";
            // 
            // convertToFilterElementsBaseBarItem1
            // 
            this.convertToFilterElementsBaseBarItem1.Id = 49;
            this.convertToFilterElementsBaseBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToComboBoxBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToListBoxBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.convertToTreeViewBarItem1)});
            this.convertToFilterElementsBaseBarItem1.Name = "convertToFilterElementsBaseBarItem1";
            // 
            // convertToComboBoxBarItem1
            // 
            this.convertToComboBoxBarItem1.Id = 50;
            this.convertToComboBoxBarItem1.Name = "convertToComboBoxBarItem1";
            // 
            // convertToListBoxBarItem1
            // 
            this.convertToListBoxBarItem1.Id = 51;
            this.convertToListBoxBarItem1.Name = "convertToListBoxBarItem1";
            // 
            // convertToTreeViewBarItem1
            // 
            this.convertToTreeViewBarItem1.Id = 52;
            this.convertToTreeViewBarItem1.Name = "convertToTreeViewBarItem1";
            // 
            // convertToBoundImageBarItem1
            // 
            this.convertToBoundImageBarItem1.Id = 53;
            this.convertToBoundImageBarItem1.Name = "convertToBoundImageBarItem1";
            // 
            // convertToTextBoxBarItem1
            // 
            this.convertToTextBoxBarItem1.Id = 54;
            this.convertToTextBoxBarItem1.Name = "convertToTextBoxBarItem1";
            // 
            // removeDataItemsBarItem1
            // 
            this.removeDataItemsBarItem1.Id = 55;
            this.removeDataItemsBarItem1.Name = "removeDataItemsBarItem1";
            // 
            // transposeItemBarItem1
            // 
            this.transposeItemBarItem1.Id = 56;
            this.transposeItemBarItem1.Name = "transposeItemBarItem1";
            // 
            // editRulesBarItem1
            // 
            this.editRulesBarItem1.Id = 57;
            this.editRulesBarItem1.Name = "editRulesBarItem1";
            // 
            // groupOperationRibbonPageGroup1
            // 
            this.groupOperationRibbonPageGroup1.ItemLinks.Add(this.deleteGroupBarItem1);
            this.groupOperationRibbonPageGroup1.Name = "groupOperationRibbonPageGroup1";
            this.groupOperationRibbonPageGroup1.Visible = false;
            // 
            // deleteGroupBarItem1
            // 
            this.deleteGroupBarItem1.Id = 58;
            this.deleteGroupBarItem1.Name = "deleteGroupBarItem1";
            // 
            // dashboardDesignRibbonPageGroup1
            // 
            this.dashboardDesignRibbonPageGroup1.ItemLinks.Add(this.dashboardTitleBarItem1);
            this.dashboardDesignRibbonPageGroup1.ItemLinks.Add(this.setCurrencyCultureBarItem1);
            this.dashboardDesignRibbonPageGroup1.ItemLinks.Add(this.dashboardColorSchemeBarItem1);
            this.dashboardDesignRibbonPageGroup1.ItemLinks.Add(this.dashboardParametersBarItem1);
            this.dashboardDesignRibbonPageGroup1.ItemLinks.Add(this.dashboardAutomaticUpdatesBarItem1);
            this.dashboardDesignRibbonPageGroup1.ItemLinks.Add(this.updateDataBarItem1);
            this.dashboardDesignRibbonPageGroup1.Name = "dashboardDesignRibbonPageGroup1";
            // 
            // dashboardTitleBarItem1
            // 
            this.dashboardTitleBarItem1.Id = 59;
            this.dashboardTitleBarItem1.Name = "dashboardTitleBarItem1";
            // 
            // setCurrencyCultureBarItem1
            // 
            this.setCurrencyCultureBarItem1.Id = 60;
            this.setCurrencyCultureBarItem1.Name = "setCurrencyCultureBarItem1";
            // 
            // dashboardColorSchemeBarItem1
            // 
            this.dashboardColorSchemeBarItem1.Id = 61;
            this.dashboardColorSchemeBarItem1.Name = "dashboardColorSchemeBarItem1";
            // 
            // dashboardParametersBarItem1
            // 
            this.dashboardParametersBarItem1.Id = 62;
            this.dashboardParametersBarItem1.Name = "dashboardParametersBarItem1";
            // 
            // dashboardAutomaticUpdatesBarItem1
            // 
            this.dashboardAutomaticUpdatesBarItem1.Id = 63;
            this.dashboardAutomaticUpdatesBarItem1.Name = "dashboardAutomaticUpdatesBarItem1";
            // 
            // updateDataBarItem1
            // 
            this.updateDataBarItem1.Id = 64;
            this.updateDataBarItem1.Name = "updateDataBarItem1";
            // 
            // dataSourceRibbonPageGroup1
            // 
            this.dataSourceRibbonPageGroup1.ItemLinks.Add(this.newDataSourceBarItem1);
            this.dataSourceRibbonPageGroup1.ItemLinks.Add(this.editSqlConnectionBarItem1);
            this.dataSourceRibbonPageGroup1.ItemLinks.Add(this.editOlapConnectionBarItem1);
            this.dataSourceRibbonPageGroup1.ItemLinks.Add(this.editObjectDataSourceBarItem1);
            this.dataSourceRibbonPageGroup1.ItemLinks.Add(this.editExcelDataSourceBarItem1);
            this.dataSourceRibbonPageGroup1.ItemLinks.Add(this.editEFDataSourceBarItem1);
            this.dataSourceRibbonPageGroup1.ItemLinks.Add(this.editExtractOptionsBarItem1);
            this.dataSourceRibbonPageGroup1.ItemLinks.Add(this.renameDataSourceBarItem1);
            this.dataSourceRibbonPageGroup1.ItemLinks.Add(this.deleteDataSourceBarItem1);
            this.dataSourceRibbonPageGroup1.ItemLinks.Add(this.serverModeBarItem1);
            this.dataSourceRibbonPageGroup1.ItemLinks.Add(this.upateDataExtractBarItem1);
            this.dataSourceRibbonPageGroup1.ItemLinks.Add(this.addCalculatedFieldBarItem1);
            this.dataSourceRibbonPageGroup1.Name = "dataSourceRibbonPageGroup1";
            // 
            // dataSourceRibbonPage1
            // 
            this.dataSourceRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.dataSourceRibbonPageGroup1,
            this.sqlDataSourceQueryRibbonPageGroup1,
            this.extractSourceRibbonPageGroup1,
            this.dataSourceFilteringRibbonPageGroup1});
            this.dataSourceRibbonPage1.Name = "dataSourceRibbonPage1";
            // 
            // newDataSourceBarItem1
            // 
            this.newDataSourceBarItem1.Id = 65;
            this.newDataSourceBarItem1.Name = "newDataSourceBarItem1";
            // 
            // editSqlConnectionBarItem1
            // 
            this.editSqlConnectionBarItem1.Id = 66;
            this.editSqlConnectionBarItem1.Name = "editSqlConnectionBarItem1";
            // 
            // editOlapConnectionBarItem1
            // 
            this.editOlapConnectionBarItem1.Id = 67;
            this.editOlapConnectionBarItem1.Name = "editOlapConnectionBarItem1";
            // 
            // editObjectDataSourceBarItem1
            // 
            this.editObjectDataSourceBarItem1.Id = 68;
            this.editObjectDataSourceBarItem1.Name = "editObjectDataSourceBarItem1";
            // 
            // editExcelDataSourceBarItem1
            // 
            this.editExcelDataSourceBarItem1.Id = 69;
            this.editExcelDataSourceBarItem1.Name = "editExcelDataSourceBarItem1";
            // 
            // editEFDataSourceBarItem1
            // 
            this.editEFDataSourceBarItem1.Id = 70;
            this.editEFDataSourceBarItem1.Name = "editEFDataSourceBarItem1";
            // 
            // editExtractOptionsBarItem1
            // 
            this.editExtractOptionsBarItem1.Id = 71;
            this.editExtractOptionsBarItem1.Name = "editExtractOptionsBarItem1";
            // 
            // renameDataSourceBarItem1
            // 
            this.renameDataSourceBarItem1.Id = 72;
            this.renameDataSourceBarItem1.Name = "renameDataSourceBarItem1";
            // 
            // deleteDataSourceBarItem1
            // 
            this.deleteDataSourceBarItem1.Id = 73;
            this.deleteDataSourceBarItem1.Name = "deleteDataSourceBarItem1";
            // 
            // serverModeBarItem1
            // 
            this.serverModeBarItem1.Id = 74;
            this.serverModeBarItem1.Name = "serverModeBarItem1";
            // 
            // upateDataExtractBarItem1
            // 
            this.upateDataExtractBarItem1.Id = 75;
            this.upateDataExtractBarItem1.Name = "upateDataExtractBarItem1";
            // 
            // addCalculatedFieldBarItem1
            // 
            this.addCalculatedFieldBarItem1.Id = 76;
            this.addCalculatedFieldBarItem1.Name = "addCalculatedFieldBarItem1";
            // 
            // sqlDataSourceQueryRibbonPageGroup1
            // 
            this.sqlDataSourceQueryRibbonPageGroup1.ItemLinks.Add(this.addQueryBarItem1);
            this.sqlDataSourceQueryRibbonPageGroup1.ItemLinks.Add(this.editQueryBarItem1);
            this.sqlDataSourceQueryRibbonPageGroup1.ItemLinks.Add(this.renameQueryBarItem1);
            this.sqlDataSourceQueryRibbonPageGroup1.ItemLinks.Add(this.editQueryFilterBarItem1);
            this.sqlDataSourceQueryRibbonPageGroup1.ItemLinks.Add(this.deleteQueryBarItem1);
            this.sqlDataSourceQueryRibbonPageGroup1.Name = "sqlDataSourceQueryRibbonPageGroup1";
            this.sqlDataSourceQueryRibbonPageGroup1.Visible = false;
            // 
            // addQueryBarItem1
            // 
            this.addQueryBarItem1.Id = 77;
            this.addQueryBarItem1.Name = "addQueryBarItem1";
            // 
            // editQueryBarItem1
            // 
            this.editQueryBarItem1.Id = 78;
            this.editQueryBarItem1.Name = "editQueryBarItem1";
            // 
            // renameQueryBarItem1
            // 
            this.renameQueryBarItem1.Id = 79;
            this.renameQueryBarItem1.Name = "renameQueryBarItem1";
            // 
            // editQueryFilterBarItem1
            // 
            this.editQueryFilterBarItem1.Id = 80;
            this.editQueryFilterBarItem1.Name = "editQueryFilterBarItem1";
            // 
            // deleteQueryBarItem1
            // 
            this.deleteQueryBarItem1.Id = 81;
            this.deleteQueryBarItem1.Name = "deleteQueryBarItem1";
            // 
            // extractSourceRibbonPageGroup1
            // 
            this.extractSourceRibbonPageGroup1.ItemLinks.Add(this.editExtractSourceConnectionBarItem1);
            this.extractSourceRibbonPageGroup1.ItemLinks.Add(this.editExtractSourceBarItem1);
            this.extractSourceRibbonPageGroup1.ItemLinks.Add(this.editExtractSourceQueryBarItem1);
            this.extractSourceRibbonPageGroup1.Name = "extractSourceRibbonPageGroup1";
            this.extractSourceRibbonPageGroup1.Visible = false;
            // 
            // editExtractSourceConnectionBarItem1
            // 
            this.editExtractSourceConnectionBarItem1.Id = 82;
            this.editExtractSourceConnectionBarItem1.Name = "editExtractSourceConnectionBarItem1";
            // 
            // editExtractSourceBarItem1
            // 
            this.editExtractSourceBarItem1.Id = 83;
            this.editExtractSourceBarItem1.Name = "editExtractSourceBarItem1";
            // 
            // editExtractSourceQueryBarItem1
            // 
            this.editExtractSourceQueryBarItem1.Id = 84;
            this.editExtractSourceQueryBarItem1.Name = "editExtractSourceQueryBarItem1";
            // 
            // dataSourceFilteringRibbonPageGroup1
            // 
            this.dataSourceFilteringRibbonPageGroup1.ItemLinks.Add(this.editDataSourceFilterBarItem1);
            this.dataSourceFilteringRibbonPageGroup1.ItemLinks.Add(this.clearDataSourceFilterBarItem1);
            this.dataSourceFilteringRibbonPageGroup1.Name = "dataSourceFilteringRibbonPageGroup1";
            this.dataSourceFilteringRibbonPageGroup1.Visible = false;
            // 
            // editDataSourceFilterBarItem1
            // 
            this.editDataSourceFilterBarItem1.Id = 85;
            this.editDataSourceFilterBarItem1.Name = "editDataSourceFilterBarItem1";
            // 
            // clearDataSourceFilterBarItem1
            // 
            this.clearDataSourceFilterBarItem1.Id = 86;
            this.clearDataSourceFilterBarItem1.Name = "clearDataSourceFilterBarItem1";
            // 
            // skinsRibbonPageGroup1
            // 
            this.skinsRibbonPageGroup1.ItemLinks.Add(this.dashboardSkinsBarItem1);
            this.skinsRibbonPageGroup1.Name = "skinsRibbonPageGroup1";
            // 
            // viewRibbonPage1
            // 
            this.viewRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.skinsRibbonPageGroup1});
            this.viewRibbonPage1.Name = "viewRibbonPage1";
            // 
            // dashboardSkinsBarItem1
            // 
            // 
            // 
            // 
            this.dashboardSkinsBarItem1.Gallery.AllowHoverImages = true;
            this.dashboardSkinsBarItem1.Gallery.ColumnCount = 4;
            this.dashboardSkinsBarItem1.Gallery.FixedHoverImageSize = false;
            galleryItemGroup1.Caption = "Standard Skins";
            galleryItem1.Caption = "DevExpress Style";
            galleryItem1.Checked = true;
            galleryItem1.Hint = "DevExpress Style";
            galleryItem1.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage")));
            galleryItem1.Tag = "DevExpress Style";
            galleryItem2.Caption = "DevExpress Dark Style";
            galleryItem2.Hint = "DevExpress Dark Style";
            galleryItem2.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage1")));
            galleryItem2.Tag = "DevExpress Dark Style";
            galleryItem3.Caption = "Office 2016 Colorful";
            galleryItem3.Hint = "Office 2016 Colorful";
            galleryItem3.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage2")));
            galleryItem3.Tag = "Office 2016 Colorful";
            galleryItem4.Caption = "Office 2016 Dark";
            galleryItem4.Hint = "Office 2016 Dark";
            galleryItem4.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage3")));
            galleryItem4.Tag = "Office 2016 Dark";
            galleryItem5.Caption = "The Bezier";
            galleryItem5.Hint = "The Bezier";
            galleryItem5.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage4")));
            galleryItem5.Tag = "The Bezier";
            galleryItem6.Caption = "Office 2016 Black";
            galleryItem6.Hint = "Office 2016 Black";
            galleryItem6.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage5")));
            galleryItem6.Tag = "Office 2016 Black";
            galleryItem7.Caption = "Office 2013 White";
            galleryItem7.Hint = "Office 2013 White";
            galleryItem7.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage6")));
            galleryItem7.Tag = "Office 2013";
            galleryItem8.Caption = "Office 2013 Dark Gray";
            galleryItem8.Hint = "Office 2013 Dark Gray";
            galleryItem8.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage7")));
            galleryItem8.Tag = "Office 2013 Dark Gray";
            galleryItem9.Caption = "Office 2013 Light Gray";
            galleryItem9.Hint = "Office 2013 Light Gray";
            galleryItem9.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage8")));
            galleryItem9.Tag = "Office 2013 Light Gray";
            galleryItem10.Caption = "Office 2010 Blue";
            galleryItem10.Hint = "Office 2010 Blue";
            galleryItem10.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage9")));
            galleryItem10.Tag = "Office 2010 Blue";
            galleryItem11.Caption = "Office 2010 Black";
            galleryItem11.Hint = "Office 2010 Black";
            galleryItem11.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage10")));
            galleryItem11.Tag = "Office 2010 Black";
            galleryItem12.Caption = "Office 2010 Silver";
            galleryItem12.Hint = "Office 2010 Silver";
            galleryItem12.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage11")));
            galleryItem12.Tag = "Office 2010 Silver";
            galleryItem13.Caption = "Visual Studio 2013 Blue";
            galleryItem13.Hint = "Visual Studio 2013 Blue";
            galleryItem13.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage12")));
            galleryItem13.Tag = "Visual Studio 2013 Blue";
            galleryItem14.Caption = "Visual Studio 2013 Dark";
            galleryItem14.Hint = "Visual Studio 2013 Dark";
            galleryItem14.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage13")));
            galleryItem14.Tag = "Visual Studio 2013 Dark";
            galleryItem15.Caption = "Seven Classic";
            galleryItem15.Hint = "Seven Classic";
            galleryItem15.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage14")));
            galleryItem15.Tag = "Seven Classic";
            galleryItem16.Caption = "Visual Studio 2013 Light";
            galleryItem16.Hint = "Visual Studio 2013 Light";
            galleryItem16.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage15")));
            galleryItem16.Tag = "Visual Studio 2013 Light";
            galleryItem17.Caption = "Visual Studio 2010";
            galleryItem17.Hint = "Visual Studio 2010";
            galleryItem17.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("resource.SvgImage16")));
            galleryItem17.Tag = "VS2010";
            galleryItemGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            galleryItem1,
            galleryItem2,
            galleryItem3,
            galleryItem4,
            galleryItem5,
            galleryItem6,
            galleryItem7,
            galleryItem8,
            galleryItem9,
            galleryItem10,
            galleryItem11,
            galleryItem12,
            galleryItem13,
            galleryItem14,
            galleryItem15,
            galleryItem16,
            galleryItem17});
            galleryItemGroup2.Caption = "Bonus Skins";
            galleryItemGroup2.Visible = false;
            galleryItemGroup3.Caption = "Theme Skins";
            galleryItemGroup3.Visible = false;
            galleryItemGroup4.Caption = "Custom Skins";
            galleryItem18.Caption = "DevExpress Design";
            galleryItem18.Hint = "DevExpress Design";
            galleryItem18.ImageOptions.HoverImage = ((System.Drawing.Image)(resources.GetObject("resource.HoverImage")));
            galleryItem18.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            galleryItem18.Tag = "DevExpress Design";
            galleryItemGroup4.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            galleryItem18});
            this.dashboardSkinsBarItem1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup1,
            galleryItemGroup2,
            galleryItemGroup3,
            galleryItemGroup4});
            this.dashboardSkinsBarItem1.Gallery.ImageSize = new System.Drawing.Size(16, 16);
            this.dashboardSkinsBarItem1.Gallery.ItemCheckMode = DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleRadio;
            this.dashboardSkinsBarItem1.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.Squeeze;
            this.dashboardSkinsBarItem1.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Top;
            skinPaddingEdges1.Left = 8;
            skinPaddingEdges1.Right = 8;
            this.dashboardSkinsBarItem1.Gallery.ItemImagePadding = skinPaddingEdges1;
            this.dashboardSkinsBarItem1.Id = 87;
            this.dashboardSkinsBarItem1.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("dashboardSkinsBarItem1.ImageOptions.SvgImage")));
            this.dashboardSkinsBarItem1.Name = "dashboardSkinsBarItem1";
            // 
            // filteringRibbonPageGroup1
            // 
            this.filteringRibbonPageGroup1.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup1.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup1.Name = "filteringRibbonPageGroup1";
            // 
            // dataRibbonPage1
            // 
            this.dataRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup1,
            this.interactivitySettingsRibbonPageGroup1});
            this.dataRibbonPage1.Name = "dataRibbonPage1";
            this.dataRibbonPage1.Visible = false;
            // 
            // pivotToolsRibbonPageCategory1
            // 
            this.pivotToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.pivotToolsRibbonPageCategory1.Name = "pivotToolsRibbonPageCategory1";
            this.pivotToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage1,
            this.dashboardItemDesignRibbonPage1});
            this.pivotToolsRibbonPageCategory1.Visible = false;
            // 
            // editFilterBarItem1
            // 
            this.editFilterBarItem1.Id = 88;
            this.editFilterBarItem1.Name = "editFilterBarItem1";
            // 
            // clearFilterBarItem1
            // 
            this.clearFilterBarItem1.Id = 89;
            this.clearFilterBarItem1.Name = "clearFilterBarItem1";
            // 
            // interactivitySettingsRibbonPageGroup1
            // 
            this.interactivitySettingsRibbonPageGroup1.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup1.Name = "interactivitySettingsRibbonPageGroup1";
            // 
            // ignoreMasterFiltersBarItem1
            // 
            this.ignoreMasterFiltersBarItem1.Id = 90;
            this.ignoreMasterFiltersBarItem1.Name = "ignoreMasterFiltersBarItem1";
            // 
            // commonItemDesignRibbonPageGroup1
            // 
            this.commonItemDesignRibbonPageGroup1.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup1.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup1.Name = "commonItemDesignRibbonPageGroup1";
            // 
            // dashboardItemDesignRibbonPage1
            // 
            this.dashboardItemDesignRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup1,
            this.pivotInitialStateRibbonPageGroup1,
            this.pivotLayoutRibbonPageGroup1});
            this.dashboardItemDesignRibbonPage1.Name = "dashboardItemDesignRibbonPage1";
            this.dashboardItemDesignRibbonPage1.Visible = false;
            // 
            // showItemCaptionBarItem1
            // 
            this.showItemCaptionBarItem1.Id = 91;
            this.showItemCaptionBarItem1.Name = "showItemCaptionBarItem1";
            // 
            // editItemNamesBarItem1
            // 
            this.editItemNamesBarItem1.Id = 92;
            this.editItemNamesBarItem1.Name = "editItemNamesBarItem1";
            // 
            // pivotInitialStateRibbonPageGroup1
            // 
            this.pivotInitialStateRibbonPageGroup1.ItemLinks.Add(this.pivotInitialStateBarItem1);
            this.pivotInitialStateRibbonPageGroup1.Name = "pivotInitialStateRibbonPageGroup1";
            // 
            // pivotInitialStateBarItem1
            // 
            this.pivotInitialStateBarItem1.Id = 93;
            this.pivotInitialStateBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.pivotAutoExpandColumnBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pivotAutoExpandRowBarItem1)});
            this.pivotInitialStateBarItem1.Name = "pivotInitialStateBarItem1";
            this.pivotInitialStateBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // pivotAutoExpandColumnBarItem1
            // 
            this.pivotAutoExpandColumnBarItem1.Id = 94;
            this.pivotAutoExpandColumnBarItem1.Name = "pivotAutoExpandColumnBarItem1";
            // 
            // pivotAutoExpandRowBarItem1
            // 
            this.pivotAutoExpandRowBarItem1.Id = 95;
            this.pivotAutoExpandRowBarItem1.Name = "pivotAutoExpandRowBarItem1";
            // 
            // pivotLayoutRibbonPageGroup1
            // 
            this.pivotLayoutRibbonPageGroup1.ItemLinks.Add(this.pivotShowTotalsBarItem1);
            this.pivotLayoutRibbonPageGroup1.ItemLinks.Add(this.pivotShowGrandTotalsBarItem1);
            this.pivotLayoutRibbonPageGroup1.ItemLinks.Add(this.pivotLayoutTypeBarItem1);
            this.pivotLayoutRibbonPageGroup1.ItemLinks.Add(this.pivotRowTotalsPositionBarItem1);
            this.pivotLayoutRibbonPageGroup1.ItemLinks.Add(this.pivotColumnTotalsPositionBarItem1);
            this.pivotLayoutRibbonPageGroup1.ItemLinks.Add(this.pivotValuesPositionBarItem1);
            this.pivotLayoutRibbonPageGroup1.ItemLinks.Add(this.pivotResetLayoutOptionsBarItem1);
            this.pivotLayoutRibbonPageGroup1.Name = "pivotLayoutRibbonPageGroup1";
            // 
            // pivotShowTotalsBarItem1
            // 
            this.pivotShowTotalsBarItem1.Id = 96;
            this.pivotShowTotalsBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.pivotShowColumnTotalsBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pivotShowRowTotalsBarItem1)});
            this.pivotShowTotalsBarItem1.Name = "pivotShowTotalsBarItem1";
            this.pivotShowTotalsBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // pivotShowColumnTotalsBarItem1
            // 
            this.pivotShowColumnTotalsBarItem1.Id = 97;
            this.pivotShowColumnTotalsBarItem1.Name = "pivotShowColumnTotalsBarItem1";
            // 
            // pivotShowRowTotalsBarItem1
            // 
            this.pivotShowRowTotalsBarItem1.Id = 98;
            this.pivotShowRowTotalsBarItem1.Name = "pivotShowRowTotalsBarItem1";
            // 
            // pivotShowGrandTotalsBarItem1
            // 
            this.pivotShowGrandTotalsBarItem1.Id = 99;
            this.pivotShowGrandTotalsBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.pivotShowColumnGrandTotalsBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pivotShowRowGrandTotalsBarItem1)});
            this.pivotShowGrandTotalsBarItem1.Name = "pivotShowGrandTotalsBarItem1";
            this.pivotShowGrandTotalsBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // pivotShowColumnGrandTotalsBarItem1
            // 
            this.pivotShowColumnGrandTotalsBarItem1.Id = 100;
            this.pivotShowColumnGrandTotalsBarItem1.Name = "pivotShowColumnGrandTotalsBarItem1";
            // 
            // pivotShowRowGrandTotalsBarItem1
            // 
            this.pivotShowRowGrandTotalsBarItem1.Id = 101;
            this.pivotShowRowGrandTotalsBarItem1.Name = "pivotShowRowGrandTotalsBarItem1";
            // 
            // pivotLayoutTypeBarItem1
            // 
            this.pivotLayoutTypeBarItem1.Id = 102;
            this.pivotLayoutTypeBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.pivotLayoutTypeCompactBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pivotLayoutTypeTabularBarItem1)});
            this.pivotLayoutTypeBarItem1.Name = "pivotLayoutTypeBarItem1";
            this.pivotLayoutTypeBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // pivotLayoutTypeCompactBarItem1
            // 
            this.pivotLayoutTypeCompactBarItem1.Id = 103;
            this.pivotLayoutTypeCompactBarItem1.Name = "pivotLayoutTypeCompactBarItem1";
            // 
            // pivotLayoutTypeTabularBarItem1
            // 
            this.pivotLayoutTypeTabularBarItem1.Id = 104;
            this.pivotLayoutTypeTabularBarItem1.Name = "pivotLayoutTypeTabularBarItem1";
            // 
            // pivotRowTotalsPositionBarItem1
            // 
            this.pivotRowTotalsPositionBarItem1.Id = 105;
            this.pivotRowTotalsPositionBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.pivotRowTotalsPositionTopBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pivotRowTotalsPositionBottomBarItem1)});
            this.pivotRowTotalsPositionBarItem1.Name = "pivotRowTotalsPositionBarItem1";
            this.pivotRowTotalsPositionBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // pivotRowTotalsPositionTopBarItem1
            // 
            this.pivotRowTotalsPositionTopBarItem1.Id = 106;
            this.pivotRowTotalsPositionTopBarItem1.Name = "pivotRowTotalsPositionTopBarItem1";
            // 
            // pivotRowTotalsPositionBottomBarItem1
            // 
            this.pivotRowTotalsPositionBottomBarItem1.Id = 107;
            this.pivotRowTotalsPositionBottomBarItem1.Name = "pivotRowTotalsPositionBottomBarItem1";
            // 
            // pivotColumnTotalsPositionBarItem1
            // 
            this.pivotColumnTotalsPositionBarItem1.Id = 108;
            this.pivotColumnTotalsPositionBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.pivotColumnTotalsPositionNearBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pivotColumnTotalsPositionFarBarItem1)});
            this.pivotColumnTotalsPositionBarItem1.Name = "pivotColumnTotalsPositionBarItem1";
            this.pivotColumnTotalsPositionBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // pivotColumnTotalsPositionNearBarItem1
            // 
            this.pivotColumnTotalsPositionNearBarItem1.Id = 109;
            this.pivotColumnTotalsPositionNearBarItem1.Name = "pivotColumnTotalsPositionNearBarItem1";
            // 
            // pivotColumnTotalsPositionFarBarItem1
            // 
            this.pivotColumnTotalsPositionFarBarItem1.Id = 110;
            this.pivotColumnTotalsPositionFarBarItem1.Name = "pivotColumnTotalsPositionFarBarItem1";
            // 
            // pivotValuesPositionBarItem1
            // 
            this.pivotValuesPositionBarItem1.Id = 111;
            this.pivotValuesPositionBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.pivotValuesPositionColumnsBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pivotValuesPositionRowsBarItem1)});
            this.pivotValuesPositionBarItem1.Name = "pivotValuesPositionBarItem1";
            this.pivotValuesPositionBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // pivotValuesPositionColumnsBarItem1
            // 
            this.pivotValuesPositionColumnsBarItem1.Id = 112;
            this.pivotValuesPositionColumnsBarItem1.Name = "pivotValuesPositionColumnsBarItem1";
            // 
            // pivotValuesPositionRowsBarItem1
            // 
            this.pivotValuesPositionRowsBarItem1.Id = 113;
            this.pivotValuesPositionRowsBarItem1.Name = "pivotValuesPositionRowsBarItem1";
            // 
            // pivotResetLayoutOptionsBarItem1
            // 
            this.pivotResetLayoutOptionsBarItem1.Id = 114;
            this.pivotResetLayoutOptionsBarItem1.Name = "pivotResetLayoutOptionsBarItem1";
            // 
            // filteringRibbonPageGroup2
            // 
            this.filteringRibbonPageGroup2.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup2.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup2.Name = "filteringRibbonPageGroup2";
            // 
            // dataRibbonPage2
            // 
            this.dataRibbonPage2.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup2,
            this.masterFilterRibbonPageGroup1,
            this.interactivitySettingsRibbonPageGroup2});
            this.dataRibbonPage2.Name = "dataRibbonPage2";
            this.dataRibbonPage2.Visible = false;
            // 
            // gridToolsRibbonPageCategory1
            // 
            this.gridToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.gridToolsRibbonPageCategory1.Name = "gridToolsRibbonPageCategory1";
            this.gridToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage2,
            this.dashboardItemDesignRibbonPage2});
            this.gridToolsRibbonPageCategory1.Visible = false;
            // 
            // masterFilterRibbonPageGroup1
            // 
            this.masterFilterRibbonPageGroup1.ItemLinks.Add(this.masterFilterBarItem1);
            this.masterFilterRibbonPageGroup1.ItemLinks.Add(this.multipleValuesMasterFilterBarItem1);
            this.masterFilterRibbonPageGroup1.ItemLinks.Add(this.drillDownBarItem1);
            this.masterFilterRibbonPageGroup1.Name = "masterFilterRibbonPageGroup1";
            // 
            // masterFilterBarItem1
            // 
            this.masterFilterBarItem1.Id = 115;
            this.masterFilterBarItem1.Name = "masterFilterBarItem1";
            // 
            // multipleValuesMasterFilterBarItem1
            // 
            this.multipleValuesMasterFilterBarItem1.Id = 116;
            this.multipleValuesMasterFilterBarItem1.Name = "multipleValuesMasterFilterBarItem1";
            // 
            // drillDownBarItem1
            // 
            this.drillDownBarItem1.Id = 117;
            this.drillDownBarItem1.Name = "drillDownBarItem1";
            // 
            // interactivitySettingsRibbonPageGroup2
            // 
            this.interactivitySettingsRibbonPageGroup2.ItemLinks.Add(this.crossDataSourceFilteringBarItem1);
            this.interactivitySettingsRibbonPageGroup2.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup2.Name = "interactivitySettingsRibbonPageGroup2";
            // 
            // crossDataSourceFilteringBarItem1
            // 
            this.crossDataSourceFilteringBarItem1.Id = 118;
            this.crossDataSourceFilteringBarItem1.Name = "crossDataSourceFilteringBarItem1";
            // 
            // commonItemDesignRibbonPageGroup2
            // 
            this.commonItemDesignRibbonPageGroup2.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup2.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup2.Name = "commonItemDesignRibbonPageGroup2";
            // 
            // dashboardItemDesignRibbonPage2
            // 
            this.dashboardItemDesignRibbonPage2.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup2,
            this.gridStyleRibbonPageGroup1,
            this.gridLayoutRibbonPageGroup1,
            this.gridColumnWidthModeRibbonPageGroup1});
            this.dashboardItemDesignRibbonPage2.Name = "dashboardItemDesignRibbonPage2";
            this.dashboardItemDesignRibbonPage2.Visible = false;
            // 
            // gridStyleRibbonPageGroup1
            // 
            this.gridStyleRibbonPageGroup1.ItemLinks.Add(this.gridHorizontalLinesBarItem1);
            this.gridStyleRibbonPageGroup1.ItemLinks.Add(this.gridVerticalLinesBarItem1);
            this.gridStyleRibbonPageGroup1.ItemLinks.Add(this.gridBandedRowsBarItem1);
            this.gridStyleRibbonPageGroup1.Name = "gridStyleRibbonPageGroup1";
            // 
            // gridHorizontalLinesBarItem1
            // 
            this.gridHorizontalLinesBarItem1.Id = 119;
            this.gridHorizontalLinesBarItem1.Name = "gridHorizontalLinesBarItem1";
            // 
            // gridVerticalLinesBarItem1
            // 
            this.gridVerticalLinesBarItem1.Id = 120;
            this.gridVerticalLinesBarItem1.Name = "gridVerticalLinesBarItem1";
            // 
            // gridBandedRowsBarItem1
            // 
            this.gridBandedRowsBarItem1.Id = 121;
            this.gridBandedRowsBarItem1.Name = "gridBandedRowsBarItem1";
            // 
            // gridLayoutRibbonPageGroup1
            // 
            this.gridLayoutRibbonPageGroup1.ItemLinks.Add(this.gridMergeCellsBarItem1);
            this.gridLayoutRibbonPageGroup1.ItemLinks.Add(this.gridColumnHeadersBarItem1);
            this.gridLayoutRibbonPageGroup1.ItemLinks.Add(this.gridWordWrapBarItem1);
            this.gridLayoutRibbonPageGroup1.Name = "gridLayoutRibbonPageGroup1";
            // 
            // gridMergeCellsBarItem1
            // 
            this.gridMergeCellsBarItem1.Id = 122;
            this.gridMergeCellsBarItem1.Name = "gridMergeCellsBarItem1";
            // 
            // gridColumnHeadersBarItem1
            // 
            this.gridColumnHeadersBarItem1.Id = 123;
            this.gridColumnHeadersBarItem1.Name = "gridColumnHeadersBarItem1";
            // 
            // gridWordWrapBarItem1
            // 
            this.gridWordWrapBarItem1.Id = 124;
            this.gridWordWrapBarItem1.Name = "gridWordWrapBarItem1";
            // 
            // gridColumnWidthModeRibbonPageGroup1
            // 
            this.gridColumnWidthModeRibbonPageGroup1.ItemLinks.Add(this.gridAutoFitToContentsColumnWidthModeBarItem1);
            this.gridColumnWidthModeRibbonPageGroup1.ItemLinks.Add(this.gridAutoFitToGridColumnWidthModeBarItem1);
            this.gridColumnWidthModeRibbonPageGroup1.ItemLinks.Add(this.manualGridColumnWidthModeBarItem1);
            this.gridColumnWidthModeRibbonPageGroup1.Name = "gridColumnWidthModeRibbonPageGroup1";
            // 
            // gridAutoFitToContentsColumnWidthModeBarItem1
            // 
            this.gridAutoFitToContentsColumnWidthModeBarItem1.Id = 125;
            this.gridAutoFitToContentsColumnWidthModeBarItem1.Name = "gridAutoFitToContentsColumnWidthModeBarItem1";
            // 
            // gridAutoFitToGridColumnWidthModeBarItem1
            // 
            this.gridAutoFitToGridColumnWidthModeBarItem1.Id = 126;
            this.gridAutoFitToGridColumnWidthModeBarItem1.Name = "gridAutoFitToGridColumnWidthModeBarItem1";
            // 
            // manualGridColumnWidthModeBarItem1
            // 
            this.manualGridColumnWidthModeBarItem1.Id = 127;
            this.manualGridColumnWidthModeBarItem1.Name = "manualGridColumnWidthModeBarItem1";
            // 
            // filteringRibbonPageGroup3
            // 
            this.filteringRibbonPageGroup3.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup3.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup3.Name = "filteringRibbonPageGroup3";
            // 
            // dataRibbonPage3
            // 
            this.dataRibbonPage3.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup3,
            this.masterFilterRibbonPageGroup2,
            this.interactivitySettingsRibbonPageGroup3,
            this.targetDimensionsRibbonPageGroup1});
            this.dataRibbonPage3.Name = "dataRibbonPage3";
            this.dataRibbonPage3.Visible = false;
            // 
            // chartToolsRibbonPageCategory1
            // 
            this.chartToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.chartToolsRibbonPageCategory1.Name = "chartToolsRibbonPageCategory1";
            this.chartToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage3,
            this.dashboardItemDesignRibbonPage3});
            this.chartToolsRibbonPageCategory1.Visible = false;
            // 
            // masterFilterRibbonPageGroup2
            // 
            this.masterFilterRibbonPageGroup2.ItemLinks.Add(this.masterFilterBarItem1);
            this.masterFilterRibbonPageGroup2.ItemLinks.Add(this.multipleValuesMasterFilterBarItem1);
            this.masterFilterRibbonPageGroup2.ItemLinks.Add(this.drillDownBarItem1);
            this.masterFilterRibbonPageGroup2.Name = "masterFilterRibbonPageGroup2";
            // 
            // interactivitySettingsRibbonPageGroup3
            // 
            this.interactivitySettingsRibbonPageGroup3.ItemLinks.Add(this.crossDataSourceFilteringBarItem1);
            this.interactivitySettingsRibbonPageGroup3.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup3.Name = "interactivitySettingsRibbonPageGroup3";
            // 
            // targetDimensionsRibbonPageGroup1
            // 
            this.targetDimensionsRibbonPageGroup1.ItemLinks.Add(this.chartTargetDimensionsArgumentsBarItem1);
            this.targetDimensionsRibbonPageGroup1.ItemLinks.Add(this.chartTargetDimensionsSeriesBarItem1);
            this.targetDimensionsRibbonPageGroup1.ItemLinks.Add(this.chartTargetDimensionsPointsBarItem1);
            this.targetDimensionsRibbonPageGroup1.Name = "targetDimensionsRibbonPageGroup1";
            // 
            // chartTargetDimensionsArgumentsBarItem1
            // 
            this.chartTargetDimensionsArgumentsBarItem1.Id = 128;
            this.chartTargetDimensionsArgumentsBarItem1.Name = "chartTargetDimensionsArgumentsBarItem1";
            // 
            // chartTargetDimensionsSeriesBarItem1
            // 
            this.chartTargetDimensionsSeriesBarItem1.Id = 129;
            this.chartTargetDimensionsSeriesBarItem1.Name = "chartTargetDimensionsSeriesBarItem1";
            // 
            // chartTargetDimensionsPointsBarItem1
            // 
            this.chartTargetDimensionsPointsBarItem1.Id = 130;
            this.chartTargetDimensionsPointsBarItem1.Name = "chartTargetDimensionsPointsBarItem1";
            // 
            // commonItemDesignRibbonPageGroup3
            // 
            this.commonItemDesignRibbonPageGroup3.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup3.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup3.Name = "commonItemDesignRibbonPageGroup3";
            // 
            // dashboardItemDesignRibbonPage3
            // 
            this.dashboardItemDesignRibbonPage3.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup3,
            this.chartLayoutPageGroup1,
            this.chartLegendPositionPageGroup1,
            this.chartStylePageGroup1,
            this.coloringOptionsRibbonPageGroup1});
            this.dashboardItemDesignRibbonPage3.Name = "dashboardItemDesignRibbonPage3";
            this.dashboardItemDesignRibbonPage3.Visible = false;
            // 
            // chartLayoutPageGroup1
            // 
            this.chartLayoutPageGroup1.ItemLinks.Add(this.chartRotateBarItem1);
            this.chartLayoutPageGroup1.ItemLinks.Add(this.chartXAxisSettingsBarItem1);
            this.chartLayoutPageGroup1.ItemLinks.Add(this.chartYAxisSettingsBarItem1);
            this.chartLayoutPageGroup1.Name = "chartLayoutPageGroup1";
            // 
            // chartRotateBarItem1
            // 
            this.chartRotateBarItem1.Id = 131;
            this.chartRotateBarItem1.Name = "chartRotateBarItem1";
            // 
            // chartXAxisSettingsBarItem1
            // 
            this.chartXAxisSettingsBarItem1.Id = 132;
            this.chartXAxisSettingsBarItem1.Name = "chartXAxisSettingsBarItem1";
            // 
            // chartYAxisSettingsBarItem1
            // 
            this.chartYAxisSettingsBarItem1.Id = 133;
            this.chartYAxisSettingsBarItem1.Name = "chartYAxisSettingsBarItem1";
            // 
            // chartLegendPositionPageGroup1
            // 
            this.chartLegendPositionPageGroup1.ItemLinks.Add(this.chartShowLegendBarItem1);
            this.chartLegendPositionPageGroup1.ItemLinks.Add(this.galleryChartLegendPositionItem1);
            this.chartLegendPositionPageGroup1.Name = "chartLegendPositionPageGroup1";
            // 
            // chartShowLegendBarItem1
            // 
            this.chartShowLegendBarItem1.Id = 134;
            this.chartShowLegendBarItem1.Name = "chartShowLegendBarItem1";
            // 
            // galleryChartLegendPositionItem1
            // 
            // 
            // 
            // 
            this.galleryChartLegendPositionItem1.Gallery.ColumnCount = 3;
            chartLegendInsideTopLeftHorizontalGalleryItem1.Caption = "";
            chartLegendInsideTopLeftHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            chartLegendInsideTopCenterHorizontalGalleryItem1.Caption = "";
            chartLegendInsideTopCenterHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            chartLegendInsideTopRightHorizontalGalleryItem1.Caption = "";
            chartLegendInsideTopRightHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            chartLegendInsideBottomLeftHorizontalGalleryItem1.Caption = "";
            chartLegendInsideBottomLeftHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            chartLegendInsideBottomCenterHorizontalGalleryItem1.Caption = "";
            chartLegendInsideBottomCenterHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            chartLegendInsideBottomRightHorizontalGalleryItem1.Caption = "";
            chartLegendInsideBottomRightHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image6")));
            chartInsideHorizontalLegendGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            chartLegendInsideTopLeftHorizontalGalleryItem1,
            chartLegendInsideTopCenterHorizontalGalleryItem1,
            chartLegendInsideTopRightHorizontalGalleryItem1,
            chartLegendInsideBottomLeftHorizontalGalleryItem1,
            chartLegendInsideBottomCenterHorizontalGalleryItem1,
            chartLegendInsideBottomRightHorizontalGalleryItem1});
            chartLegendInsideTopLeftVerticalGalleryItem1.Caption = "";
            chartLegendInsideTopLeftVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image7")));
            chartLegendInsideTopCenterVerticalGalleryItem1.Caption = "";
            chartLegendInsideTopCenterVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image8")));
            chartLegendInsideTopRightVerticalGalleryItem1.Caption = "";
            chartLegendInsideTopRightVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image9")));
            chartLegendInsideBottomLeftVerticalGalleryItem1.Caption = "";
            chartLegendInsideBottomLeftVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image10")));
            chartLegendInsideBottomCenterVerticalGalleryItem1.Caption = "";
            chartLegendInsideBottomCenterVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image11")));
            chartLegendInsideBottomRightVerticalGalleryItem1.Caption = "";
            chartLegendInsideBottomRightVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image12")));
            chartInsideVerticalLegendGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            chartLegendInsideTopLeftVerticalGalleryItem1,
            chartLegendInsideTopCenterVerticalGalleryItem1,
            chartLegendInsideTopRightVerticalGalleryItem1,
            chartLegendInsideBottomLeftVerticalGalleryItem1,
            chartLegendInsideBottomCenterVerticalGalleryItem1,
            chartLegendInsideBottomRightVerticalGalleryItem1});
            chartLegendOutsideTopLeftHorizontalGalleryItem1.Caption = "";
            chartLegendOutsideTopLeftHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image13")));
            chartLegendOutsideTopCenterHorizontalGalleryItem1.Caption = "";
            chartLegendOutsideTopCenterHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image14")));
            chartLegendOutsideTopRightHorizontalGalleryItem1.Caption = "";
            chartLegendOutsideTopRightHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image15")));
            chartLegendOutsideBottomLeftHorizontalGalleryItem1.Caption = "";
            chartLegendOutsideBottomLeftHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image16")));
            chartLegendOutsideBottomCenterHorizontalGalleryItem1.Caption = "";
            chartLegendOutsideBottomCenterHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image17")));
            chartLegendOutsideBottomRightHorizontalGalleryItem1.Caption = "";
            chartLegendOutsideBottomRightHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image18")));
            chartOutsideHorizontalLegendGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            chartLegendOutsideTopLeftHorizontalGalleryItem1,
            chartLegendOutsideTopCenterHorizontalGalleryItem1,
            chartLegendOutsideTopRightHorizontalGalleryItem1,
            chartLegendOutsideBottomLeftHorizontalGalleryItem1,
            chartLegendOutsideBottomCenterHorizontalGalleryItem1,
            chartLegendOutsideBottomRightHorizontalGalleryItem1});
            chartLegendOutsideTopLeftVerticalGalleryItem1.Caption = "";
            chartLegendOutsideTopLeftVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image19")));
            chartLegendOutsideTopRightVerticalGalleryItem1.Caption = "";
            chartLegendOutsideTopRightVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image20")));
            chartLegendOutsideBottomLeftVerticalGalleryItem1.Caption = "";
            chartLegendOutsideBottomLeftVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image21")));
            chartLegendOutsideBottomRightVerticalGalleryItem1.Caption = "";
            chartLegendOutsideBottomRightVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image22")));
            chartOutsideVerticalLegendGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            chartLegendOutsideTopLeftVerticalGalleryItem1,
            chartLegendOutsideTopRightVerticalGalleryItem1,
            chartLegendOutsideBottomLeftVerticalGalleryItem1,
            chartLegendOutsideBottomRightVerticalGalleryItem1});
            this.galleryChartLegendPositionItem1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            chartInsideHorizontalLegendGalleryGroup1,
            chartInsideVerticalLegendGalleryGroup1,
            chartOutsideHorizontalLegendGalleryGroup1,
            chartOutsideVerticalLegendGalleryGroup1});
            this.galleryChartLegendPositionItem1.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.galleryChartLegendPositionItem1.Gallery.RowCount = 8;
            this.galleryChartLegendPositionItem1.Id = 135;
            this.galleryChartLegendPositionItem1.Name = "galleryChartLegendPositionItem1";
            // 
            // chartStylePageGroup1
            // 
            this.chartStylePageGroup1.ItemLinks.Add(this.galleryChartSeriesTypeItem1);
            this.chartStylePageGroup1.Name = "chartStylePageGroup1";
            // 
            // galleryChartSeriesTypeItem1
            // 
            // 
            // 
            // 
            chartBarSeriesGalleryItem1.Caption = "";
            chartBarSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image23")));
            chartStackedBarSeriesGalleryItem1.Caption = "";
            chartStackedBarSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image24")));
            chartFullStackedBarSeriesGalleryItem1.Caption = "";
            chartFullStackedBarSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image25")));
            chartBarSeriesGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            chartBarSeriesGalleryItem1,
            chartStackedBarSeriesGalleryItem1,
            chartFullStackedBarSeriesGalleryItem1});
            chartPointSeriesGalleryItem1.Caption = "";
            chartPointSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image26")));
            chartLineSeriesGalleryItem1.Caption = "";
            chartLineSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image27")));
            chartStackedLineSeriesGalleryItem1.Caption = "";
            chartStackedLineSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image28")));
            chartFullStackedLineSeriesGalleryItem1.Caption = "";
            chartFullStackedLineSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image29")));
            chartStepLineSeriesGalleryItem1.Caption = "";
            chartStepLineSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image30")));
            chartSplineSeriesGalleryItem1.Caption = "";
            chartSplineSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image31")));
            chartPointLineSeriesGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            chartPointSeriesGalleryItem1,
            chartLineSeriesGalleryItem1,
            chartStackedLineSeriesGalleryItem1,
            chartFullStackedLineSeriesGalleryItem1,
            chartStepLineSeriesGalleryItem1,
            chartSplineSeriesGalleryItem1});
            chartAreaSeriesGalleryItem1.Caption = "";
            chartAreaSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image32")));
            chartStackedAreaSeriesGalleryItem1.Caption = "";
            chartStackedAreaSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image33")));
            chartFullStackedAreaSeriesGalleryItem1.Caption = "";
            chartFullStackedAreaSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image34")));
            chartStepAreaSeriesGalleryItem1.Caption = "";
            chartStepAreaSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image35")));
            chartSplineAreaSeriesGalleryItem1.Caption = "";
            chartSplineAreaSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image36")));
            chartStackedSplineAreaSeriesGalleryItem1.Caption = "";
            chartStackedSplineAreaSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image37")));
            chartFullStackedSplineAreaSeriesGalleryItem1.Caption = "";
            chartFullStackedSplineAreaSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image38")));
            chartAreaSeriesGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            chartAreaSeriesGalleryItem1,
            chartStackedAreaSeriesGalleryItem1,
            chartFullStackedAreaSeriesGalleryItem1,
            chartStepAreaSeriesGalleryItem1,
            chartSplineAreaSeriesGalleryItem1,
            chartStackedSplineAreaSeriesGalleryItem1,
            chartFullStackedSplineAreaSeriesGalleryItem1});
            chartSideBySideRangeBarSeriesGalleryItem1.Caption = "";
            chartSideBySideRangeBarSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image39")));
            chartRangeAreaSeriesGalleryItem1.Caption = "";
            chartRangeAreaSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image40")));
            chartRangeSeriesGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            chartSideBySideRangeBarSeriesGalleryItem1,
            chartRangeAreaSeriesGalleryItem1});
            chartWeightedSeriesGalleryItem1.Caption = "";
            chartWeightedSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image41")));
            chartBubbleSeriesGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            chartWeightedSeriesGalleryItem1});
            chartHighLowCloseSeriesGalleryItem1.Caption = "";
            chartHighLowCloseSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image42")));
            chartCandleStickSeriesGalleryItem1.Caption = "";
            chartCandleStickSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image43")));
            chartStockSeriesGalleryItem1.Caption = "";
            chartStockSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image44")));
            chartFinancialSeriesGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            chartHighLowCloseSeriesGalleryItem1,
            chartCandleStickSeriesGalleryItem1,
            chartStockSeriesGalleryItem1});
            this.galleryChartSeriesTypeItem1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            chartBarSeriesGalleryGroup1,
            chartPointLineSeriesGalleryGroup1,
            chartAreaSeriesGalleryGroup1,
            chartRangeSeriesGalleryGroup1,
            chartBubbleSeriesGalleryGroup1,
            chartFinancialSeriesGalleryGroup1});
            this.galleryChartSeriesTypeItem1.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.galleryChartSeriesTypeItem1.Gallery.RowCount = 8;
            this.galleryChartSeriesTypeItem1.Id = 136;
            this.galleryChartSeriesTypeItem1.Name = "galleryChartSeriesTypeItem1";
            // 
            // coloringOptionsRibbonPageGroup1
            // 
            this.coloringOptionsRibbonPageGroup1.ItemLinks.Add(this.useGlobalColorsBarItem1);
            this.coloringOptionsRibbonPageGroup1.ItemLinks.Add(this.useLocalColorsBarItem1);
            this.coloringOptionsRibbonPageGroup1.ItemLinks.Add(this.editActualColorsBarItem1);
            this.coloringOptionsRibbonPageGroup1.Name = "coloringOptionsRibbonPageGroup1";
            // 
            // useGlobalColorsBarItem1
            // 
            this.useGlobalColorsBarItem1.Id = 137;
            this.useGlobalColorsBarItem1.Name = "useGlobalColorsBarItem1";
            // 
            // useLocalColorsBarItem1
            // 
            this.useLocalColorsBarItem1.Id = 138;
            this.useLocalColorsBarItem1.Name = "useLocalColorsBarItem1";
            // 
            // editActualColorsBarItem1
            // 
            this.editActualColorsBarItem1.Id = 139;
            this.editActualColorsBarItem1.Name = "editActualColorsBarItem1";
            // 
            // filteringRibbonPageGroup4
            // 
            this.filteringRibbonPageGroup4.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup4.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup4.Name = "filteringRibbonPageGroup4";
            // 
            // dataRibbonPage4
            // 
            this.dataRibbonPage4.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup4,
            this.masterFilterRibbonPageGroup3,
            this.interactivitySettingsRibbonPageGroup4});
            this.dataRibbonPage4.Name = "dataRibbonPage4";
            this.dataRibbonPage4.Visible = false;
            // 
            // scatterChartToolsRibbonPageCategory1
            // 
            this.scatterChartToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.scatterChartToolsRibbonPageCategory1.Name = "scatterChartToolsRibbonPageCategory1";
            this.scatterChartToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage4,
            this.dashboardItemDesignRibbonPage4});
            this.scatterChartToolsRibbonPageCategory1.Visible = false;
            // 
            // masterFilterRibbonPageGroup3
            // 
            this.masterFilterRibbonPageGroup3.ItemLinks.Add(this.masterFilterBarItem1);
            this.masterFilterRibbonPageGroup3.ItemLinks.Add(this.multipleValuesMasterFilterBarItem1);
            this.masterFilterRibbonPageGroup3.ItemLinks.Add(this.drillDownBarItem1);
            this.masterFilterRibbonPageGroup3.Name = "masterFilterRibbonPageGroup3";
            // 
            // interactivitySettingsRibbonPageGroup4
            // 
            this.interactivitySettingsRibbonPageGroup4.ItemLinks.Add(this.crossDataSourceFilteringBarItem1);
            this.interactivitySettingsRibbonPageGroup4.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup4.Name = "interactivitySettingsRibbonPageGroup4";
            // 
            // commonItemDesignRibbonPageGroup4
            // 
            this.commonItemDesignRibbonPageGroup4.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup4.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup4.Name = "commonItemDesignRibbonPageGroup4";
            // 
            // dashboardItemDesignRibbonPage4
            // 
            this.dashboardItemDesignRibbonPage4.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup4,
            this.scatterChartLayoutPageGroup1,
            this.scatterChartPointLabelPageGroup1,
            this.scatterChartLegendPositionPageGroup1,
            this.coloringOptionsRibbonPageGroup2});
            this.dashboardItemDesignRibbonPage4.Name = "dashboardItemDesignRibbonPage4";
            this.dashboardItemDesignRibbonPage4.Visible = false;
            // 
            // scatterChartLayoutPageGroup1
            // 
            this.scatterChartLayoutPageGroup1.ItemLinks.Add(this.scatterChartRotateBarItem1);
            this.scatterChartLayoutPageGroup1.ItemLinks.Add(this.scatterChartXAxisSettingsBarItem1);
            this.scatterChartLayoutPageGroup1.ItemLinks.Add(this.scatterChartYAxisSettingsBarItem1);
            this.scatterChartLayoutPageGroup1.Name = "scatterChartLayoutPageGroup1";
            // 
            // scatterChartRotateBarItem1
            // 
            this.scatterChartRotateBarItem1.Id = 140;
            this.scatterChartRotateBarItem1.Name = "scatterChartRotateBarItem1";
            // 
            // scatterChartXAxisSettingsBarItem1
            // 
            this.scatterChartXAxisSettingsBarItem1.Id = 141;
            this.scatterChartXAxisSettingsBarItem1.Name = "scatterChartXAxisSettingsBarItem1";
            // 
            // scatterChartYAxisSettingsBarItem1
            // 
            this.scatterChartYAxisSettingsBarItem1.Id = 142;
            this.scatterChartYAxisSettingsBarItem1.Name = "scatterChartYAxisSettingsBarItem1";
            // 
            // scatterChartPointLabelPageGroup1
            // 
            this.scatterChartPointLabelPageGroup1.ItemLinks.Add(this.scatterChartPointLabelOptionsBarItem1);
            this.scatterChartPointLabelPageGroup1.Name = "scatterChartPointLabelPageGroup1";
            // 
            // scatterChartPointLabelOptionsBarItem1
            // 
            this.scatterChartPointLabelOptionsBarItem1.Id = 143;
            this.scatterChartPointLabelOptionsBarItem1.Name = "scatterChartPointLabelOptionsBarItem1";
            // 
            // scatterChartLegendPositionPageGroup1
            // 
            this.scatterChartLegendPositionPageGroup1.ItemLinks.Add(this.scatterChartShowLegendBarItem1);
            this.scatterChartLegendPositionPageGroup1.ItemLinks.Add(this.galleryScatterChartLegendPositionItem1);
            this.scatterChartLegendPositionPageGroup1.Name = "scatterChartLegendPositionPageGroup1";
            // 
            // scatterChartShowLegendBarItem1
            // 
            this.scatterChartShowLegendBarItem1.Id = 144;
            this.scatterChartShowLegendBarItem1.Name = "scatterChartShowLegendBarItem1";
            // 
            // galleryScatterChartLegendPositionItem1
            // 
            // 
            // 
            // 
            this.galleryScatterChartLegendPositionItem1.Gallery.ColumnCount = 3;
            chartLegendInsideTopLeftHorizontalGalleryItem2.Caption = "";
            chartLegendInsideTopLeftHorizontalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image45")));
            chartLegendInsideTopCenterHorizontalGalleryItem2.Caption = "";
            chartLegendInsideTopCenterHorizontalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image46")));
            chartLegendInsideTopRightHorizontalGalleryItem2.Caption = "";
            chartLegendInsideTopRightHorizontalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image47")));
            chartLegendInsideBottomLeftHorizontalGalleryItem2.Caption = "";
            chartLegendInsideBottomLeftHorizontalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image48")));
            chartLegendInsideBottomCenterHorizontalGalleryItem2.Caption = "";
            chartLegendInsideBottomCenterHorizontalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image49")));
            chartLegendInsideBottomRightHorizontalGalleryItem2.Caption = "";
            chartLegendInsideBottomRightHorizontalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image50")));
            chartInsideHorizontalLegendGalleryGroup2.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            chartLegendInsideTopLeftHorizontalGalleryItem2,
            chartLegendInsideTopCenterHorizontalGalleryItem2,
            chartLegendInsideTopRightHorizontalGalleryItem2,
            chartLegendInsideBottomLeftHorizontalGalleryItem2,
            chartLegendInsideBottomCenterHorizontalGalleryItem2,
            chartLegendInsideBottomRightHorizontalGalleryItem2});
            chartLegendInsideTopLeftVerticalGalleryItem2.Caption = "";
            chartLegendInsideTopLeftVerticalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image51")));
            chartLegendInsideTopCenterVerticalGalleryItem2.Caption = "";
            chartLegendInsideTopCenterVerticalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image52")));
            chartLegendInsideTopRightVerticalGalleryItem2.Caption = "";
            chartLegendInsideTopRightVerticalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image53")));
            chartLegendInsideBottomLeftVerticalGalleryItem2.Caption = "";
            chartLegendInsideBottomLeftVerticalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image54")));
            chartLegendInsideBottomCenterVerticalGalleryItem2.Caption = "";
            chartLegendInsideBottomCenterVerticalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image55")));
            chartLegendInsideBottomRightVerticalGalleryItem2.Caption = "";
            chartLegendInsideBottomRightVerticalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image56")));
            chartInsideVerticalLegendGalleryGroup2.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            chartLegendInsideTopLeftVerticalGalleryItem2,
            chartLegendInsideTopCenterVerticalGalleryItem2,
            chartLegendInsideTopRightVerticalGalleryItem2,
            chartLegendInsideBottomLeftVerticalGalleryItem2,
            chartLegendInsideBottomCenterVerticalGalleryItem2,
            chartLegendInsideBottomRightVerticalGalleryItem2});
            chartLegendOutsideTopLeftHorizontalGalleryItem2.Caption = "";
            chartLegendOutsideTopLeftHorizontalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image57")));
            chartLegendOutsideTopCenterHorizontalGalleryItem2.Caption = "";
            chartLegendOutsideTopCenterHorizontalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image58")));
            chartLegendOutsideTopRightHorizontalGalleryItem2.Caption = "";
            chartLegendOutsideTopRightHorizontalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image59")));
            chartLegendOutsideBottomLeftHorizontalGalleryItem2.Caption = "";
            chartLegendOutsideBottomLeftHorizontalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image60")));
            chartLegendOutsideBottomCenterHorizontalGalleryItem2.Caption = "";
            chartLegendOutsideBottomCenterHorizontalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image61")));
            chartLegendOutsideBottomRightHorizontalGalleryItem2.Caption = "";
            chartLegendOutsideBottomRightHorizontalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image62")));
            chartOutsideHorizontalLegendGalleryGroup2.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            chartLegendOutsideTopLeftHorizontalGalleryItem2,
            chartLegendOutsideTopCenterHorizontalGalleryItem2,
            chartLegendOutsideTopRightHorizontalGalleryItem2,
            chartLegendOutsideBottomLeftHorizontalGalleryItem2,
            chartLegendOutsideBottomCenterHorizontalGalleryItem2,
            chartLegendOutsideBottomRightHorizontalGalleryItem2});
            chartLegendOutsideTopLeftVerticalGalleryItem2.Caption = "";
            chartLegendOutsideTopLeftVerticalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image63")));
            chartLegendOutsideTopRightVerticalGalleryItem2.Caption = "";
            chartLegendOutsideTopRightVerticalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image64")));
            chartLegendOutsideBottomLeftVerticalGalleryItem2.Caption = "";
            chartLegendOutsideBottomLeftVerticalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image65")));
            chartLegendOutsideBottomRightVerticalGalleryItem2.Caption = "";
            chartLegendOutsideBottomRightVerticalGalleryItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image66")));
            chartOutsideVerticalLegendGalleryGroup2.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            chartLegendOutsideTopLeftVerticalGalleryItem2,
            chartLegendOutsideTopRightVerticalGalleryItem2,
            chartLegendOutsideBottomLeftVerticalGalleryItem2,
            chartLegendOutsideBottomRightVerticalGalleryItem2});
            this.galleryScatterChartLegendPositionItem1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            chartInsideHorizontalLegendGalleryGroup2,
            chartInsideVerticalLegendGalleryGroup2,
            chartOutsideHorizontalLegendGalleryGroup2,
            chartOutsideVerticalLegendGalleryGroup2});
            this.galleryScatterChartLegendPositionItem1.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.galleryScatterChartLegendPositionItem1.Gallery.RowCount = 8;
            this.galleryScatterChartLegendPositionItem1.Id = 145;
            this.galleryScatterChartLegendPositionItem1.Name = "galleryScatterChartLegendPositionItem1";
            // 
            // coloringOptionsRibbonPageGroup2
            // 
            this.coloringOptionsRibbonPageGroup2.ItemLinks.Add(this.useGlobalColorsBarItem1);
            this.coloringOptionsRibbonPageGroup2.ItemLinks.Add(this.useLocalColorsBarItem1);
            this.coloringOptionsRibbonPageGroup2.ItemLinks.Add(this.editActualColorsBarItem1);
            this.coloringOptionsRibbonPageGroup2.Name = "coloringOptionsRibbonPageGroup2";
            // 
            // filteringRibbonPageGroup5
            // 
            this.filteringRibbonPageGroup5.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup5.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup5.Name = "filteringRibbonPageGroup5";
            // 
            // dataRibbonPage5
            // 
            this.dataRibbonPage5.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup5,
            this.masterFilterRibbonPageGroup4,
            this.interactivitySettingsRibbonPageGroup5,
            this.targetDimensionsRibbonPageGroup2});
            this.dataRibbonPage5.Name = "dataRibbonPage5";
            this.dataRibbonPage5.Visible = false;
            // 
            // piesToolsRibbonPageCategory1
            // 
            this.piesToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.piesToolsRibbonPageCategory1.Name = "piesToolsRibbonPageCategory1";
            this.piesToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage5,
            this.dashboardItemDesignRibbonPage5});
            this.piesToolsRibbonPageCategory1.Visible = false;
            // 
            // masterFilterRibbonPageGroup4
            // 
            this.masterFilterRibbonPageGroup4.ItemLinks.Add(this.masterFilterBarItem1);
            this.masterFilterRibbonPageGroup4.ItemLinks.Add(this.multipleValuesMasterFilterBarItem1);
            this.masterFilterRibbonPageGroup4.ItemLinks.Add(this.drillDownBarItem1);
            this.masterFilterRibbonPageGroup4.Name = "masterFilterRibbonPageGroup4";
            // 
            // interactivitySettingsRibbonPageGroup5
            // 
            this.interactivitySettingsRibbonPageGroup5.ItemLinks.Add(this.crossDataSourceFilteringBarItem1);
            this.interactivitySettingsRibbonPageGroup5.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup5.Name = "interactivitySettingsRibbonPageGroup5";
            // 
            // targetDimensionsRibbonPageGroup2
            // 
            this.targetDimensionsRibbonPageGroup2.ItemLinks.Add(this.pieTargetDimensionsArgumentsBarItem1);
            this.targetDimensionsRibbonPageGroup2.ItemLinks.Add(this.pieTargetDimensionsSeriesBarItem1);
            this.targetDimensionsRibbonPageGroup2.ItemLinks.Add(this.pieTargetDimensionsPointsBarItem1);
            this.targetDimensionsRibbonPageGroup2.Name = "targetDimensionsRibbonPageGroup2";
            // 
            // pieTargetDimensionsArgumentsBarItem1
            // 
            this.pieTargetDimensionsArgumentsBarItem1.Id = 146;
            this.pieTargetDimensionsArgumentsBarItem1.Name = "pieTargetDimensionsArgumentsBarItem1";
            // 
            // pieTargetDimensionsSeriesBarItem1
            // 
            this.pieTargetDimensionsSeriesBarItem1.Id = 147;
            this.pieTargetDimensionsSeriesBarItem1.Name = "pieTargetDimensionsSeriesBarItem1";
            // 
            // pieTargetDimensionsPointsBarItem1
            // 
            this.pieTargetDimensionsPointsBarItem1.Id = 148;
            this.pieTargetDimensionsPointsBarItem1.Name = "pieTargetDimensionsPointsBarItem1";
            // 
            // commonItemDesignRibbonPageGroup5
            // 
            this.commonItemDesignRibbonPageGroup5.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup5.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup5.Name = "commonItemDesignRibbonPageGroup5";
            // 
            // dashboardItemDesignRibbonPage5
            // 
            this.dashboardItemDesignRibbonPage5.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup5,
            this.contentArrangementRibbonPageGroup1,
            this.pieLabelsRibbonPageGroup1,
            this.pieStyleRibbonPageGroup1,
            this.coloringOptionsRibbonPageGroup3});
            this.dashboardItemDesignRibbonPage5.Name = "dashboardItemDesignRibbonPage5";
            this.dashboardItemDesignRibbonPage5.Visible = false;
            // 
            // contentArrangementRibbonPageGroup1
            // 
            this.contentArrangementRibbonPageGroup1.ItemLinks.Add(this.contentAutoArrangeBarItem1);
            this.contentArrangementRibbonPageGroup1.ItemLinks.Add(this.contentArrangeInColumnsBarItem1);
            this.contentArrangementRibbonPageGroup1.ItemLinks.Add(this.contentArrangeInRowsBarItem1);
            this.contentArrangementRibbonPageGroup1.ItemLinks.Add(this.contentArrangementCountBarItem1);
            this.contentArrangementRibbonPageGroup1.Name = "contentArrangementRibbonPageGroup1";
            // 
            // contentAutoArrangeBarItem1
            // 
            this.contentAutoArrangeBarItem1.Id = 149;
            this.contentAutoArrangeBarItem1.Name = "contentAutoArrangeBarItem1";
            // 
            // contentArrangeInColumnsBarItem1
            // 
            this.contentArrangeInColumnsBarItem1.Id = 150;
            this.contentArrangeInColumnsBarItem1.Name = "contentArrangeInColumnsBarItem1";
            // 
            // contentArrangeInRowsBarItem1
            // 
            this.contentArrangeInRowsBarItem1.Id = 151;
            this.contentArrangeInRowsBarItem1.Name = "contentArrangeInRowsBarItem1";
            // 
            // contentArrangementCountBarItem1
            // 
            this.contentArrangementCountBarItem1.Edit = this.repositoryItemSpinEdit1;
            this.contentArrangementCountBarItem1.Id = 152;
            this.contentArrangementCountBarItem1.Name = "contentArrangementCountBarItem1";
            // 
            // repositoryItemSpinEdit1
            // 
            this.repositoryItemSpinEdit1.AutoHeight = false;
            this.repositoryItemSpinEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit1.IsFloatValue = false;
            this.repositoryItemSpinEdit1.Mask.EditMask = "N00";
            this.repositoryItemSpinEdit1.MaxValue = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.repositoryItemSpinEdit1.MinValue = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.repositoryItemSpinEdit1.Name = "repositoryItemSpinEdit1";
            // 
            // pieLabelsRibbonPageGroup1
            // 
            this.pieLabelsRibbonPageGroup1.ItemLinks.Add(this.pieLabelsDataLabelsBarItem1);
            this.pieLabelsRibbonPageGroup1.ItemLinks.Add(this.pieLabelPositionBarItem1);
            this.pieLabelsRibbonPageGroup1.ItemLinks.Add(this.pieTooltipsBarItem1);
            this.pieLabelsRibbonPageGroup1.ItemLinks.Add(this.pieShowCaptionsBarItem1);
            this.pieLabelsRibbonPageGroup1.Name = "pieLabelsRibbonPageGroup1";
            // 
            // pieLabelsDataLabelsBarItem1
            // 
            this.pieLabelsDataLabelsBarItem1.Id = 153;
            this.pieLabelsDataLabelsBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsDataLabelsNoneBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsDataLabelArgumentBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsDataLabelsValueBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsDataLabelsArgumentAndValueBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsDataLabelsPercentBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsDataLabelsValueAndPercentBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsDataLabelsArgumentAndPercentBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsDataLabelsArgumentValueAndPercentBarItem1)});
            this.pieLabelsDataLabelsBarItem1.Name = "pieLabelsDataLabelsBarItem1";
            this.pieLabelsDataLabelsBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // pieLabelsDataLabelsNoneBarItem1
            // 
            this.pieLabelsDataLabelsNoneBarItem1.Id = 154;
            this.pieLabelsDataLabelsNoneBarItem1.Name = "pieLabelsDataLabelsNoneBarItem1";
            // 
            // pieLabelsDataLabelArgumentBarItem1
            // 
            this.pieLabelsDataLabelArgumentBarItem1.Id = 155;
            this.pieLabelsDataLabelArgumentBarItem1.Name = "pieLabelsDataLabelArgumentBarItem1";
            // 
            // pieLabelsDataLabelsValueBarItem1
            // 
            this.pieLabelsDataLabelsValueBarItem1.Id = 156;
            this.pieLabelsDataLabelsValueBarItem1.Name = "pieLabelsDataLabelsValueBarItem1";
            // 
            // pieLabelsDataLabelsArgumentAndValueBarItem1
            // 
            this.pieLabelsDataLabelsArgumentAndValueBarItem1.Id = 157;
            this.pieLabelsDataLabelsArgumentAndValueBarItem1.Name = "pieLabelsDataLabelsArgumentAndValueBarItem1";
            // 
            // pieLabelsDataLabelsPercentBarItem1
            // 
            this.pieLabelsDataLabelsPercentBarItem1.Id = 158;
            this.pieLabelsDataLabelsPercentBarItem1.Name = "pieLabelsDataLabelsPercentBarItem1";
            // 
            // pieLabelsDataLabelsValueAndPercentBarItem1
            // 
            this.pieLabelsDataLabelsValueAndPercentBarItem1.Id = 159;
            this.pieLabelsDataLabelsValueAndPercentBarItem1.Name = "pieLabelsDataLabelsValueAndPercentBarItem1";
            // 
            // pieLabelsDataLabelsArgumentAndPercentBarItem1
            // 
            this.pieLabelsDataLabelsArgumentAndPercentBarItem1.Id = 160;
            this.pieLabelsDataLabelsArgumentAndPercentBarItem1.Name = "pieLabelsDataLabelsArgumentAndPercentBarItem1";
            // 
            // pieLabelsDataLabelsArgumentValueAndPercentBarItem1
            // 
            this.pieLabelsDataLabelsArgumentValueAndPercentBarItem1.Id = 161;
            this.pieLabelsDataLabelsArgumentValueAndPercentBarItem1.Name = "pieLabelsDataLabelsArgumentValueAndPercentBarItem1";
            // 
            // pieLabelPositionBarItem1
            // 
            this.pieLabelPositionBarItem1.Id = 162;
            this.pieLabelPositionBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelPositionOutsideBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelPositionInsideBarItem1)});
            this.pieLabelPositionBarItem1.Name = "pieLabelPositionBarItem1";
            this.pieLabelPositionBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // pieLabelPositionOutsideBarItem1
            // 
            this.pieLabelPositionOutsideBarItem1.Id = 163;
            this.pieLabelPositionOutsideBarItem1.Name = "pieLabelPositionOutsideBarItem1";
            // 
            // pieLabelPositionInsideBarItem1
            // 
            this.pieLabelPositionInsideBarItem1.Id = 164;
            this.pieLabelPositionInsideBarItem1.Name = "pieLabelPositionInsideBarItem1";
            // 
            // pieTooltipsBarItem1
            // 
            this.pieTooltipsBarItem1.Id = 165;
            this.pieTooltipsBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsTooltipsNoneBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsTooltipsArgumentBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsTooltipsValueBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsTooltipsArgumentAndValueBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsTooltipsPercentBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsTooltipsValueAndPercentBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsTooltipsArgumentAndPercentBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.pieLabelsTooltipsArgumentValueAndPercentBarItem1)});
            this.pieTooltipsBarItem1.Name = "pieTooltipsBarItem1";
            this.pieTooltipsBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // pieLabelsTooltipsNoneBarItem1
            // 
            this.pieLabelsTooltipsNoneBarItem1.Id = 166;
            this.pieLabelsTooltipsNoneBarItem1.Name = "pieLabelsTooltipsNoneBarItem1";
            // 
            // pieLabelsTooltipsArgumentBarItem1
            // 
            this.pieLabelsTooltipsArgumentBarItem1.Id = 167;
            this.pieLabelsTooltipsArgumentBarItem1.Name = "pieLabelsTooltipsArgumentBarItem1";
            // 
            // pieLabelsTooltipsValueBarItem1
            // 
            this.pieLabelsTooltipsValueBarItem1.Id = 168;
            this.pieLabelsTooltipsValueBarItem1.Name = "pieLabelsTooltipsValueBarItem1";
            // 
            // pieLabelsTooltipsArgumentAndValueBarItem1
            // 
            this.pieLabelsTooltipsArgumentAndValueBarItem1.Id = 169;
            this.pieLabelsTooltipsArgumentAndValueBarItem1.Name = "pieLabelsTooltipsArgumentAndValueBarItem1";
            // 
            // pieLabelsTooltipsPercentBarItem1
            // 
            this.pieLabelsTooltipsPercentBarItem1.Id = 170;
            this.pieLabelsTooltipsPercentBarItem1.Name = "pieLabelsTooltipsPercentBarItem1";
            // 
            // pieLabelsTooltipsValueAndPercentBarItem1
            // 
            this.pieLabelsTooltipsValueAndPercentBarItem1.Id = 171;
            this.pieLabelsTooltipsValueAndPercentBarItem1.Name = "pieLabelsTooltipsValueAndPercentBarItem1";
            // 
            // pieLabelsTooltipsArgumentAndPercentBarItem1
            // 
            this.pieLabelsTooltipsArgumentAndPercentBarItem1.Id = 172;
            this.pieLabelsTooltipsArgumentAndPercentBarItem1.Name = "pieLabelsTooltipsArgumentAndPercentBarItem1";
            // 
            // pieLabelsTooltipsArgumentValueAndPercentBarItem1
            // 
            this.pieLabelsTooltipsArgumentValueAndPercentBarItem1.Id = 173;
            this.pieLabelsTooltipsArgumentValueAndPercentBarItem1.Name = "pieLabelsTooltipsArgumentValueAndPercentBarItem1";
            // 
            // pieStyleRibbonPageGroup1
            // 
            this.pieStyleRibbonPageGroup1.ItemLinks.Add(this.pieStylePieBarItem1);
            this.pieStyleRibbonPageGroup1.ItemLinks.Add(this.pieStyleDonutBarItem1);
            this.pieStyleRibbonPageGroup1.Name = "pieStyleRibbonPageGroup1";
            // 
            // pieStylePieBarItem1
            // 
            this.pieStylePieBarItem1.Id = 174;
            this.pieStylePieBarItem1.Name = "pieStylePieBarItem1";
            // 
            // pieStyleDonutBarItem1
            // 
            this.pieStyleDonutBarItem1.Id = 175;
            this.pieStyleDonutBarItem1.Name = "pieStyleDonutBarItem1";
            // 
            // pieShowCaptionsBarItem1
            // 
            this.pieShowCaptionsBarItem1.Id = 176;
            this.pieShowCaptionsBarItem1.Name = "pieShowCaptionsBarItem1";
            // 
            // coloringOptionsRibbonPageGroup3
            // 
            this.coloringOptionsRibbonPageGroup3.ItemLinks.Add(this.useGlobalColorsBarItem1);
            this.coloringOptionsRibbonPageGroup3.ItemLinks.Add(this.useLocalColorsBarItem1);
            this.coloringOptionsRibbonPageGroup3.ItemLinks.Add(this.editActualColorsBarItem1);
            this.coloringOptionsRibbonPageGroup3.Name = "coloringOptionsRibbonPageGroup3";
            // 
            // filteringRibbonPageGroup6
            // 
            this.filteringRibbonPageGroup6.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup6.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup6.Name = "filteringRibbonPageGroup6";
            // 
            // dataRibbonPage6
            // 
            this.dataRibbonPage6.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup6,
            this.masterFilterRibbonPageGroup5,
            this.interactivitySettingsRibbonPageGroup6});
            this.dataRibbonPage6.Name = "dataRibbonPage6";
            this.dataRibbonPage6.Visible = false;
            // 
            // gaugesToolsRibbonPageCategory1
            // 
            this.gaugesToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.gaugesToolsRibbonPageCategory1.Name = "gaugesToolsRibbonPageCategory1";
            this.gaugesToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage6,
            this.dashboardItemDesignRibbonPage6});
            this.gaugesToolsRibbonPageCategory1.Visible = false;
            // 
            // masterFilterRibbonPageGroup5
            // 
            this.masterFilterRibbonPageGroup5.ItemLinks.Add(this.masterFilterBarItem1);
            this.masterFilterRibbonPageGroup5.ItemLinks.Add(this.multipleValuesMasterFilterBarItem1);
            this.masterFilterRibbonPageGroup5.ItemLinks.Add(this.drillDownBarItem1);
            this.masterFilterRibbonPageGroup5.Name = "masterFilterRibbonPageGroup5";
            // 
            // interactivitySettingsRibbonPageGroup6
            // 
            this.interactivitySettingsRibbonPageGroup6.ItemLinks.Add(this.crossDataSourceFilteringBarItem1);
            this.interactivitySettingsRibbonPageGroup6.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup6.Name = "interactivitySettingsRibbonPageGroup6";
            // 
            // commonItemDesignRibbonPageGroup6
            // 
            this.commonItemDesignRibbonPageGroup6.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup6.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup6.Name = "commonItemDesignRibbonPageGroup6";
            // 
            // dashboardItemDesignRibbonPage6
            // 
            this.dashboardItemDesignRibbonPage6.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup6,
            this.contentArrangementRibbonPageGroup2,
            this.gaugeStyleRibbonPageGroup1,
            this.gaugesLabelsRibbonPageGroup1});
            this.dashboardItemDesignRibbonPage6.Name = "dashboardItemDesignRibbonPage6";
            this.dashboardItemDesignRibbonPage6.Visible = false;
            // 
            // contentArrangementRibbonPageGroup2
            // 
            this.contentArrangementRibbonPageGroup2.ItemLinks.Add(this.contentAutoArrangeBarItem1);
            this.contentArrangementRibbonPageGroup2.ItemLinks.Add(this.contentArrangeInColumnsBarItem1);
            this.contentArrangementRibbonPageGroup2.ItemLinks.Add(this.contentArrangeInRowsBarItem1);
            this.contentArrangementRibbonPageGroup2.ItemLinks.Add(this.contentArrangementCountBarItem1);
            this.contentArrangementRibbonPageGroup2.Name = "contentArrangementRibbonPageGroup2";
            // 
            // gaugeStyleRibbonPageGroup1
            // 
            this.gaugeStyleRibbonPageGroup1.ItemLinks.Add(this.gaugeStyleFullCircularBarItem1);
            this.gaugeStyleRibbonPageGroup1.ItemLinks.Add(this.gaugeStyleHalfCircularBarItem1);
            this.gaugeStyleRibbonPageGroup1.ItemLinks.Add(this.gaugeStyleLeftQuarterCircularBarItem1);
            this.gaugeStyleRibbonPageGroup1.ItemLinks.Add(this.gaugeStyleRightQuarterCircularBarItem1);
            this.gaugeStyleRibbonPageGroup1.ItemLinks.Add(this.gaugeStyleThreeForthCircularBarItem1);
            this.gaugeStyleRibbonPageGroup1.ItemLinks.Add(this.gaugeStyleLinearHorizontalBarItem1);
            this.gaugeStyleRibbonPageGroup1.ItemLinks.Add(this.gaugeStyleLinearVerticalBarItem1);
            this.gaugeStyleRibbonPageGroup1.Name = "gaugeStyleRibbonPageGroup1";
            // 
            // gaugeStyleFullCircularBarItem1
            // 
            this.gaugeStyleFullCircularBarItem1.Id = 177;
            this.gaugeStyleFullCircularBarItem1.Name = "gaugeStyleFullCircularBarItem1";
            // 
            // gaugeStyleHalfCircularBarItem1
            // 
            this.gaugeStyleHalfCircularBarItem1.Id = 178;
            this.gaugeStyleHalfCircularBarItem1.Name = "gaugeStyleHalfCircularBarItem1";
            // 
            // gaugeStyleLeftQuarterCircularBarItem1
            // 
            this.gaugeStyleLeftQuarterCircularBarItem1.Id = 179;
            this.gaugeStyleLeftQuarterCircularBarItem1.Name = "gaugeStyleLeftQuarterCircularBarItem1";
            // 
            // gaugeStyleRightQuarterCircularBarItem1
            // 
            this.gaugeStyleRightQuarterCircularBarItem1.Id = 180;
            this.gaugeStyleRightQuarterCircularBarItem1.Name = "gaugeStyleRightQuarterCircularBarItem1";
            // 
            // gaugeStyleThreeForthCircularBarItem1
            // 
            this.gaugeStyleThreeForthCircularBarItem1.Id = 181;
            this.gaugeStyleThreeForthCircularBarItem1.Name = "gaugeStyleThreeForthCircularBarItem1";
            // 
            // gaugeStyleLinearHorizontalBarItem1
            // 
            this.gaugeStyleLinearHorizontalBarItem1.Id = 182;
            this.gaugeStyleLinearHorizontalBarItem1.Name = "gaugeStyleLinearHorizontalBarItem1";
            // 
            // gaugeStyleLinearVerticalBarItem1
            // 
            this.gaugeStyleLinearVerticalBarItem1.Id = 183;
            this.gaugeStyleLinearVerticalBarItem1.Name = "gaugeStyleLinearVerticalBarItem1";
            // 
            // gaugesLabelsRibbonPageGroup1
            // 
            this.gaugesLabelsRibbonPageGroup1.ItemLinks.Add(this.gaugeShowCaptionsBarItem1);
            this.gaugesLabelsRibbonPageGroup1.Name = "gaugesLabelsRibbonPageGroup1";
            // 
            // gaugeShowCaptionsBarItem1
            // 
            this.gaugeShowCaptionsBarItem1.Id = 184;
            this.gaugeShowCaptionsBarItem1.Name = "gaugeShowCaptionsBarItem1";
            // 
            // filteringRibbonPageGroup7
            // 
            this.filteringRibbonPageGroup7.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup7.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup7.Name = "filteringRibbonPageGroup7";
            // 
            // dataRibbonPage7
            // 
            this.dataRibbonPage7.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup7,
            this.masterFilterRibbonPageGroup6,
            this.interactivitySettingsRibbonPageGroup7});
            this.dataRibbonPage7.Name = "dataRibbonPage7";
            this.dataRibbonPage7.Visible = false;
            // 
            // cardsToolsRibbonPageCategory1
            // 
            this.cardsToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.cardsToolsRibbonPageCategory1.Name = "cardsToolsRibbonPageCategory1";
            this.cardsToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage7,
            this.dashboardItemDesignRibbonPage7});
            this.cardsToolsRibbonPageCategory1.Visible = false;
            // 
            // masterFilterRibbonPageGroup6
            // 
            this.masterFilterRibbonPageGroup6.ItemLinks.Add(this.masterFilterBarItem1);
            this.masterFilterRibbonPageGroup6.ItemLinks.Add(this.multipleValuesMasterFilterBarItem1);
            this.masterFilterRibbonPageGroup6.ItemLinks.Add(this.drillDownBarItem1);
            this.masterFilterRibbonPageGroup6.Name = "masterFilterRibbonPageGroup6";
            // 
            // interactivitySettingsRibbonPageGroup7
            // 
            this.interactivitySettingsRibbonPageGroup7.ItemLinks.Add(this.crossDataSourceFilteringBarItem1);
            this.interactivitySettingsRibbonPageGroup7.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup7.Name = "interactivitySettingsRibbonPageGroup7";
            // 
            // commonItemDesignRibbonPageGroup7
            // 
            this.commonItemDesignRibbonPageGroup7.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup7.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup7.Name = "commonItemDesignRibbonPageGroup7";
            // 
            // dashboardItemDesignRibbonPage7
            // 
            this.dashboardItemDesignRibbonPage7.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup7,
            this.contentArrangementRibbonPageGroup3});
            this.dashboardItemDesignRibbonPage7.Name = "dashboardItemDesignRibbonPage7";
            this.dashboardItemDesignRibbonPage7.Visible = false;
            // 
            // contentArrangementRibbonPageGroup3
            // 
            this.contentArrangementRibbonPageGroup3.ItemLinks.Add(this.contentAutoArrangeBarItem1);
            this.contentArrangementRibbonPageGroup3.ItemLinks.Add(this.contentArrangeInColumnsBarItem1);
            this.contentArrangementRibbonPageGroup3.ItemLinks.Add(this.contentArrangeInRowsBarItem1);
            this.contentArrangementRibbonPageGroup3.ItemLinks.Add(this.contentArrangementCountBarItem1);
            this.contentArrangementRibbonPageGroup3.Name = "contentArrangementRibbonPageGroup3";
            // 
            // filteringRibbonPageGroup8
            // 
            this.filteringRibbonPageGroup8.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup8.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup8.Name = "filteringRibbonPageGroup8";
            // 
            // dataRibbonPage8
            // 
            this.dataRibbonPage8.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup8,
            this.interactivitySettingsRibbonPageGroup8});
            this.dataRibbonPage8.Name = "dataRibbonPage8";
            this.dataRibbonPage8.Visible = false;
            // 
            // rangeFilterToolsRibbonPageCategory1
            // 
            this.rangeFilterToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.rangeFilterToolsRibbonPageCategory1.Name = "rangeFilterToolsRibbonPageCategory1";
            this.rangeFilterToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage8,
            this.dashboardItemDesignRibbonPage8});
            this.rangeFilterToolsRibbonPageCategory1.Visible = false;
            // 
            // interactivitySettingsRibbonPageGroup8
            // 
            this.interactivitySettingsRibbonPageGroup8.ItemLinks.Add(this.crossDataSourceFilteringBarItem1);
            this.interactivitySettingsRibbonPageGroup8.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup8.Name = "interactivitySettingsRibbonPageGroup8";
            // 
            // commonItemDesignRibbonPageGroup8
            // 
            this.commonItemDesignRibbonPageGroup8.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup8.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup8.Name = "commonItemDesignRibbonPageGroup8";
            // 
            // dashboardItemDesignRibbonPage8
            // 
            this.dashboardItemDesignRibbonPage8.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup8,
            this.rangeFilterSeriesTypeRibbonPageGroup1,
            this.rangeFilterInteractivityRibbonPageGroup1,
            this.coloringOptionsRibbonPageGroup4});
            this.dashboardItemDesignRibbonPage8.Name = "dashboardItemDesignRibbonPage8";
            this.dashboardItemDesignRibbonPage8.Visible = false;
            // 
            // rangeFilterSeriesTypeRibbonPageGroup1
            // 
            this.rangeFilterSeriesTypeRibbonPageGroup1.ItemLinks.Add(this.galleryRangeFilterSeriesTypeItem1);
            this.rangeFilterSeriesTypeRibbonPageGroup1.Name = "rangeFilterSeriesTypeRibbonPageGroup1";
            // 
            // galleryRangeFilterSeriesTypeItem1
            // 
            // 
            // 
            // 
            this.galleryRangeFilterSeriesTypeItem1.Gallery.ColumnCount = 3;
            rangeLineSeriesGalleryItem1.Caption = "";
            rangeLineSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image67")));
            rangeStackedLineSeriesGalleryItem1.Caption = "";
            rangeStackedLineSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image68")));
            rangeFullStackedLineSeriesGalleryItem1.Caption = "";
            rangeFullStackedLineSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image69")));
            rangePointLineSeriesGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            rangeLineSeriesGalleryItem1,
            rangeStackedLineSeriesGalleryItem1,
            rangeFullStackedLineSeriesGalleryItem1});
            rangeAreaSeriesGalleryItem1.Caption = "";
            rangeAreaSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image70")));
            rangeStackedAreaSeriesGalleryItem1.Caption = "";
            rangeStackedAreaSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image71")));
            rangeFullStackedAreaSeriesGalleryItem1.Caption = "";
            rangeFullStackedAreaSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image72")));
            rangeAreaSeriesGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            rangeAreaSeriesGalleryItem1,
            rangeStackedAreaSeriesGalleryItem1,
            rangeFullStackedAreaSeriesGalleryItem1});
            rangeBarSeriesGalleryItem1.Caption = "";
            rangeBarSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image73")));
            rangeStackedBarSeriesGalleryItem1.Caption = "";
            rangeStackedBarSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image74")));
            rangeFullStackedBarSeriesGalleryItem1.Caption = "";
            rangeFullStackedBarSeriesGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image75")));
            rangeBarSeriesGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            rangeBarSeriesGalleryItem1,
            rangeStackedBarSeriesGalleryItem1,
            rangeFullStackedBarSeriesGalleryItem1});
            this.galleryRangeFilterSeriesTypeItem1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            rangePointLineSeriesGalleryGroup1,
            rangeAreaSeriesGalleryGroup1,
            rangeBarSeriesGalleryGroup1});
            this.galleryRangeFilterSeriesTypeItem1.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.galleryRangeFilterSeriesTypeItem1.Id = 185;
            this.galleryRangeFilterSeriesTypeItem1.Name = "galleryRangeFilterSeriesTypeItem1";
            // 
            // rangeFilterInteractivityRibbonPageGroup1
            // 
            this.rangeFilterInteractivityRibbonPageGroup1.ItemLinks.Add(this.rangeFilterEditDateTimePeriodsBarItem1);
            this.rangeFilterInteractivityRibbonPageGroup1.Name = "rangeFilterInteractivityRibbonPageGroup1";
            // 
            // rangeFilterEditDateTimePeriodsBarItem1
            // 
            this.rangeFilterEditDateTimePeriodsBarItem1.Id = 186;
            this.rangeFilterEditDateTimePeriodsBarItem1.Name = "rangeFilterEditDateTimePeriodsBarItem1";
            // 
            // coloringOptionsRibbonPageGroup4
            // 
            this.coloringOptionsRibbonPageGroup4.ItemLinks.Add(this.useGlobalColorsBarItem1);
            this.coloringOptionsRibbonPageGroup4.ItemLinks.Add(this.useLocalColorsBarItem1);
            this.coloringOptionsRibbonPageGroup4.ItemLinks.Add(this.editActualColorsBarItem1);
            this.coloringOptionsRibbonPageGroup4.Name = "coloringOptionsRibbonPageGroup4";
            // 
            // filteringRibbonPageGroup9
            // 
            this.filteringRibbonPageGroup9.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup9.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup9.Name = "filteringRibbonPageGroup9";
            // 
            // dataRibbonPage9
            // 
            this.dataRibbonPage9.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup9,
            this.masterFilterRibbonPageGroup7,
            this.interactivitySettingsRibbonPageGroup9});
            this.dataRibbonPage9.Name = "dataRibbonPage9";
            this.dataRibbonPage9.Visible = false;
            // 
            // choroplethMapToolsRibbonPageCategory1
            // 
            this.choroplethMapToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.choroplethMapToolsRibbonPageCategory1.Name = "choroplethMapToolsRibbonPageCategory1";
            this.choroplethMapToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage9,
            this.dashboardItemDesignRibbonPage9});
            this.choroplethMapToolsRibbonPageCategory1.Visible = false;
            // 
            // masterFilterRibbonPageGroup7
            // 
            this.masterFilterRibbonPageGroup7.ItemLinks.Add(this.masterFilterBarItem1);
            this.masterFilterRibbonPageGroup7.ItemLinks.Add(this.multipleValuesMasterFilterBarItem1);
            this.masterFilterRibbonPageGroup7.Name = "masterFilterRibbonPageGroup7";
            // 
            // interactivitySettingsRibbonPageGroup9
            // 
            this.interactivitySettingsRibbonPageGroup9.ItemLinks.Add(this.crossDataSourceFilteringBarItem1);
            this.interactivitySettingsRibbonPageGroup9.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup9.Name = "interactivitySettingsRibbonPageGroup9";
            // 
            // commonItemDesignRibbonPageGroup9
            // 
            this.commonItemDesignRibbonPageGroup9.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup9.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup9.Name = "commonItemDesignRibbonPageGroup9";
            // 
            // dashboardItemDesignRibbonPage9
            // 
            this.dashboardItemDesignRibbonPage9.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup9,
            this.mapShapefileRibbonPageGroup1,
            this.mapNavigationPageGroup1,
            this.mapShapeLabelsAttributePageGroup1,
            this.mapLegendPositionPageGroup1});
            this.dashboardItemDesignRibbonPage9.Name = "dashboardItemDesignRibbonPage9";
            this.dashboardItemDesignRibbonPage9.Visible = false;
            // 
            // mapShapefileRibbonPageGroup1
            // 
            this.mapShapefileRibbonPageGroup1.ItemLinks.Add(this.mapLoadBarItem1);
            this.mapShapefileRibbonPageGroup1.ItemLinks.Add(this.mapImportBarItem1);
            this.mapShapefileRibbonPageGroup1.ItemLinks.Add(this.mapDefaultShapefileBarItem1);
            this.mapShapefileRibbonPageGroup1.Name = "mapShapefileRibbonPageGroup1";
            // 
            // mapLoadBarItem1
            // 
            this.mapLoadBarItem1.Id = 187;
            this.mapLoadBarItem1.Name = "mapLoadBarItem1";
            // 
            // mapImportBarItem1
            // 
            this.mapImportBarItem1.Id = 188;
            this.mapImportBarItem1.Name = "mapImportBarItem1";
            // 
            // mapDefaultShapefileBarItem1
            // 
            this.mapDefaultShapefileBarItem1.Id = 189;
            this.mapDefaultShapefileBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.mapWorldCountriesBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.mapEuropeBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.mapAsiaBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.mapNorthAmericaBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.mapSouthAmericaBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.mapAfricaBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.mapUSABarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.mapCanadaBarItem1)});
            this.mapDefaultShapefileBarItem1.Name = "mapDefaultShapefileBarItem1";
            this.mapDefaultShapefileBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // mapWorldCountriesBarItem1
            // 
            this.mapWorldCountriesBarItem1.Id = 190;
            this.mapWorldCountriesBarItem1.Name = "mapWorldCountriesBarItem1";
            // 
            // mapEuropeBarItem1
            // 
            this.mapEuropeBarItem1.Id = 191;
            this.mapEuropeBarItem1.Name = "mapEuropeBarItem1";
            // 
            // mapAsiaBarItem1
            // 
            this.mapAsiaBarItem1.Id = 192;
            this.mapAsiaBarItem1.Name = "mapAsiaBarItem1";
            // 
            // mapNorthAmericaBarItem1
            // 
            this.mapNorthAmericaBarItem1.Id = 193;
            this.mapNorthAmericaBarItem1.Name = "mapNorthAmericaBarItem1";
            // 
            // mapSouthAmericaBarItem1
            // 
            this.mapSouthAmericaBarItem1.Id = 194;
            this.mapSouthAmericaBarItem1.Name = "mapSouthAmericaBarItem1";
            // 
            // mapAfricaBarItem1
            // 
            this.mapAfricaBarItem1.Id = 195;
            this.mapAfricaBarItem1.Name = "mapAfricaBarItem1";
            // 
            // mapUSABarItem1
            // 
            this.mapUSABarItem1.Id = 196;
            this.mapUSABarItem1.Name = "mapUSABarItem1";
            // 
            // mapCanadaBarItem1
            // 
            this.mapCanadaBarItem1.Id = 197;
            this.mapCanadaBarItem1.Name = "mapCanadaBarItem1";
            // 
            // mapNavigationPageGroup1
            // 
            this.mapNavigationPageGroup1.ItemLinks.Add(this.mapLockNavigationBarItem1);
            this.mapNavigationPageGroup1.ItemLinks.Add(this.mapFullExtentBarItem1);
            this.mapNavigationPageGroup1.Name = "mapNavigationPageGroup1";
            // 
            // mapLockNavigationBarItem1
            // 
            this.mapLockNavigationBarItem1.Id = 198;
            this.mapLockNavigationBarItem1.Name = "mapLockNavigationBarItem1";
            // 
            // mapFullExtentBarItem1
            // 
            this.mapFullExtentBarItem1.Id = 199;
            this.mapFullExtentBarItem1.Name = "mapFullExtentBarItem1";
            // 
            // mapShapeLabelsAttributePageGroup1
            // 
            this.mapShapeLabelsAttributePageGroup1.ItemLinks.Add(this.choroplethMapShapeLabelsAttributeBarItem1);
            this.mapShapeLabelsAttributePageGroup1.Name = "mapShapeLabelsAttributePageGroup1";
            // 
            // choroplethMapShapeLabelsAttributeBarItem1
            // 
            this.choroplethMapShapeLabelsAttributeBarItem1.Id = 200;
            this.choroplethMapShapeLabelsAttributeBarItem1.Name = "choroplethMapShapeLabelsAttributeBarItem1";
            // 
            // mapLegendPositionPageGroup1
            // 
            this.mapLegendPositionPageGroup1.ItemLinks.Add(this.mapShowLegendBarItem1);
            this.mapLegendPositionPageGroup1.ItemLinks.Add(this.galleryMapLegendPositionItem1);
            this.mapLegendPositionPageGroup1.Name = "mapLegendPositionPageGroup1";
            // 
            // mapShowLegendBarItem1
            // 
            this.mapShowLegendBarItem1.Id = 201;
            this.mapShowLegendBarItem1.Name = "mapShowLegendBarItem1";
            // 
            // galleryMapLegendPositionItem1
            // 
            // 
            // 
            // 
            this.galleryMapLegendPositionItem1.Gallery.ColumnCount = 3;
            mapLegendTopLeftVerticalGalleryItem1.Caption = "";
            mapLegendTopLeftVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image76")));
            mapLegendTopCenterVerticalGalleryItem1.Caption = "";
            mapLegendTopCenterVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image77")));
            mapLegendTopRightVerticalGalleryItem1.Caption = "";
            mapLegendTopRightVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image78")));
            mapLegendBottomLeftVerticalGalleryItem1.Caption = "";
            mapLegendBottomLeftVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image79")));
            mapLegendBottomCenterVerticalGalleryItem1.Caption = "";
            mapLegendBottomCenterVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image80")));
            mapLegendBottomRightVerticalGalleryItem1.Caption = "";
            mapLegendBottomRightVerticalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image81")));
            mapVerticalLegendGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            mapLegendTopLeftVerticalGalleryItem1,
            mapLegendTopCenterVerticalGalleryItem1,
            mapLegendTopRightVerticalGalleryItem1,
            mapLegendBottomLeftVerticalGalleryItem1,
            mapLegendBottomCenterVerticalGalleryItem1,
            mapLegendBottomRightVerticalGalleryItem1});
            mapLegendTopLeftHorizontalGalleryItem1.Caption = "";
            mapLegendTopLeftHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image82")));
            mapLegendTopCenterHorizontalGalleryItem1.Caption = "";
            mapLegendTopCenterHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image83")));
            mapLegendTopRightHorizontalGalleryItem1.Caption = "";
            mapLegendTopRightHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image84")));
            mapLegendBottomLeftHorizontalGalleryItem1.Caption = "";
            mapLegendBottomLeftHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image85")));
            mapLegendBottomCenterHorizontalGalleryItem1.Caption = "";
            mapLegendBottomCenterHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image86")));
            mapLegendBottomRightHorizontalGalleryItem1.Caption = "";
            mapLegendBottomRightHorizontalGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image87")));
            mapHorizontalLegendGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            mapLegendTopLeftHorizontalGalleryItem1,
            mapLegendTopCenterHorizontalGalleryItem1,
            mapLegendTopRightHorizontalGalleryItem1,
            mapLegendBottomLeftHorizontalGalleryItem1,
            mapLegendBottomCenterHorizontalGalleryItem1,
            mapLegendBottomRightHorizontalGalleryItem1});
            this.galleryMapLegendPositionItem1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            mapVerticalLegendGalleryGroup1,
            mapHorizontalLegendGalleryGroup1});
            this.galleryMapLegendPositionItem1.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.galleryMapLegendPositionItem1.Gallery.RowCount = 4;
            this.galleryMapLegendPositionItem1.Id = 202;
            this.galleryMapLegendPositionItem1.Name = "galleryMapLegendPositionItem1";
            // 
            // filteringRibbonPageGroup10
            // 
            this.filteringRibbonPageGroup10.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup10.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup10.Name = "filteringRibbonPageGroup10";
            // 
            // dataRibbonPage10
            // 
            this.dataRibbonPage10.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup10,
            this.masterFilterRibbonPageGroup8,
            this.interactivitySettingsRibbonPageGroup10,
            this.geoPointMapClusterizationRibbonPageGroup1});
            this.dataRibbonPage10.Name = "dataRibbonPage10";
            this.dataRibbonPage10.Visible = false;
            // 
            // geoPointMapToolsRibbonPageCategory1
            // 
            this.geoPointMapToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.geoPointMapToolsRibbonPageCategory1.Name = "geoPointMapToolsRibbonPageCategory1";
            this.geoPointMapToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage10,
            this.dashboardItemDesignRibbonPage10});
            this.geoPointMapToolsRibbonPageCategory1.Visible = false;
            // 
            // masterFilterRibbonPageGroup8
            // 
            this.masterFilterRibbonPageGroup8.ItemLinks.Add(this.masterFilterBarItem1);
            this.masterFilterRibbonPageGroup8.ItemLinks.Add(this.multipleValuesMasterFilterBarItem1);
            this.masterFilterRibbonPageGroup8.Name = "masterFilterRibbonPageGroup8";
            // 
            // interactivitySettingsRibbonPageGroup10
            // 
            this.interactivitySettingsRibbonPageGroup10.ItemLinks.Add(this.crossDataSourceFilteringBarItem1);
            this.interactivitySettingsRibbonPageGroup10.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup10.Name = "interactivitySettingsRibbonPageGroup10";
            // 
            // geoPointMapClusterizationRibbonPageGroup1
            // 
            this.geoPointMapClusterizationRibbonPageGroup1.ItemLinks.Add(this.geoPointMapClusterizationBarItem1);
            this.geoPointMapClusterizationRibbonPageGroup1.Name = "geoPointMapClusterizationRibbonPageGroup1";
            // 
            // geoPointMapClusterizationBarItem1
            // 
            this.geoPointMapClusterizationBarItem1.Id = 203;
            this.geoPointMapClusterizationBarItem1.Name = "geoPointMapClusterizationBarItem1";
            // 
            // commonItemDesignRibbonPageGroup10
            // 
            this.commonItemDesignRibbonPageGroup10.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup10.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup10.Name = "commonItemDesignRibbonPageGroup10";
            // 
            // dashboardItemDesignRibbonPage10
            // 
            this.dashboardItemDesignRibbonPage10.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup10,
            this.mapShapefileRibbonPageGroup2,
            this.mapNavigationPageGroup2,
            this.mapShapeLabelsAttributePageGroup2});
            this.dashboardItemDesignRibbonPage10.Name = "dashboardItemDesignRibbonPage10";
            this.dashboardItemDesignRibbonPage10.Visible = false;
            // 
            // mapShapefileRibbonPageGroup2
            // 
            this.mapShapefileRibbonPageGroup2.ItemLinks.Add(this.mapLoadBarItem1);
            this.mapShapefileRibbonPageGroup2.ItemLinks.Add(this.mapImportBarItem1);
            this.mapShapefileRibbonPageGroup2.ItemLinks.Add(this.mapDefaultShapefileBarItem1);
            this.mapShapefileRibbonPageGroup2.Name = "mapShapefileRibbonPageGroup2";
            // 
            // mapNavigationPageGroup2
            // 
            this.mapNavigationPageGroup2.ItemLinks.Add(this.mapLockNavigationBarItem1);
            this.mapNavigationPageGroup2.ItemLinks.Add(this.mapFullExtentBarItem1);
            this.mapNavigationPageGroup2.Name = "mapNavigationPageGroup2";
            // 
            // mapShapeLabelsAttributePageGroup2
            // 
            this.mapShapeLabelsAttributePageGroup2.ItemLinks.Add(this.mapShapeTitleAttributeBarItem1);
            this.mapShapeLabelsAttributePageGroup2.Name = "mapShapeLabelsAttributePageGroup2";
            // 
            // mapShapeTitleAttributeBarItem1
            // 
            this.mapShapeTitleAttributeBarItem1.Id = 204;
            this.mapShapeTitleAttributeBarItem1.Name = "mapShapeTitleAttributeBarItem1";
            // 
            // filteringRibbonPageGroup11
            // 
            this.filteringRibbonPageGroup11.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup11.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup11.Name = "filteringRibbonPageGroup11";
            // 
            // dataRibbonPage11
            // 
            this.dataRibbonPage11.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup11,
            this.masterFilterRibbonPageGroup9,
            this.interactivitySettingsRibbonPageGroup11,
            this.geoPointMapClusterizationRibbonPageGroup2});
            this.dataRibbonPage11.Name = "dataRibbonPage11";
            this.dataRibbonPage11.Visible = false;
            // 
            // bubbleMapToolsRibbonPageCategory1
            // 
            this.bubbleMapToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.bubbleMapToolsRibbonPageCategory1.Name = "bubbleMapToolsRibbonPageCategory1";
            this.bubbleMapToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage11,
            this.dashboardItemDesignRibbonPage11});
            this.bubbleMapToolsRibbonPageCategory1.Visible = false;
            // 
            // masterFilterRibbonPageGroup9
            // 
            this.masterFilterRibbonPageGroup9.ItemLinks.Add(this.masterFilterBarItem1);
            this.masterFilterRibbonPageGroup9.ItemLinks.Add(this.multipleValuesMasterFilterBarItem1);
            this.masterFilterRibbonPageGroup9.Name = "masterFilterRibbonPageGroup9";
            // 
            // interactivitySettingsRibbonPageGroup11
            // 
            this.interactivitySettingsRibbonPageGroup11.ItemLinks.Add(this.crossDataSourceFilteringBarItem1);
            this.interactivitySettingsRibbonPageGroup11.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup11.Name = "interactivitySettingsRibbonPageGroup11";
            // 
            // geoPointMapClusterizationRibbonPageGroup2
            // 
            this.geoPointMapClusterizationRibbonPageGroup2.ItemLinks.Add(this.geoPointMapClusterizationBarItem1);
            this.geoPointMapClusterizationRibbonPageGroup2.Name = "geoPointMapClusterizationRibbonPageGroup2";
            // 
            // commonItemDesignRibbonPageGroup11
            // 
            this.commonItemDesignRibbonPageGroup11.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup11.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup11.Name = "commonItemDesignRibbonPageGroup11";
            // 
            // dashboardItemDesignRibbonPage11
            // 
            this.dashboardItemDesignRibbonPage11.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup11,
            this.mapShapefileRibbonPageGroup3,
            this.mapNavigationPageGroup3,
            this.mapShapeLabelsAttributePageGroup3,
            this.mapLegendPositionPageGroup2,
            this.weightedLegendPageGroup1});
            this.dashboardItemDesignRibbonPage11.Name = "dashboardItemDesignRibbonPage11";
            this.dashboardItemDesignRibbonPage11.Visible = false;
            // 
            // mapShapefileRibbonPageGroup3
            // 
            this.mapShapefileRibbonPageGroup3.ItemLinks.Add(this.mapLoadBarItem1);
            this.mapShapefileRibbonPageGroup3.ItemLinks.Add(this.mapImportBarItem1);
            this.mapShapefileRibbonPageGroup3.ItemLinks.Add(this.mapDefaultShapefileBarItem1);
            this.mapShapefileRibbonPageGroup3.Name = "mapShapefileRibbonPageGroup3";
            // 
            // mapNavigationPageGroup3
            // 
            this.mapNavigationPageGroup3.ItemLinks.Add(this.mapLockNavigationBarItem1);
            this.mapNavigationPageGroup3.ItemLinks.Add(this.mapFullExtentBarItem1);
            this.mapNavigationPageGroup3.Name = "mapNavigationPageGroup3";
            // 
            // mapShapeLabelsAttributePageGroup3
            // 
            this.mapShapeLabelsAttributePageGroup3.ItemLinks.Add(this.mapShapeTitleAttributeBarItem1);
            this.mapShapeLabelsAttributePageGroup3.Name = "mapShapeLabelsAttributePageGroup3";
            // 
            // mapLegendPositionPageGroup2
            // 
            this.mapLegendPositionPageGroup2.ItemLinks.Add(this.mapShowLegendBarItem1);
            this.mapLegendPositionPageGroup2.ItemLinks.Add(this.galleryMapLegendPositionItem1);
            this.mapLegendPositionPageGroup2.Name = "mapLegendPositionPageGroup2";
            // 
            // weightedLegendPageGroup1
            // 
            this.weightedLegendPageGroup1.ItemLinks.Add(this.changeWeightedLegendTypeBarItem1);
            this.weightedLegendPageGroup1.ItemLinks.Add(this.galleryWeightedLegendPositionItem1);
            this.weightedLegendPageGroup1.Name = "weightedLegendPageGroup1";
            // 
            // changeWeightedLegendTypeBarItem1
            // 
            this.changeWeightedLegendTypeBarItem1.Id = 205;
            this.changeWeightedLegendTypeBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.weightedLegendNoneBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.weightedLegendLinearBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.weightedLegendNestedBarItem1)});
            this.changeWeightedLegendTypeBarItem1.Name = "changeWeightedLegendTypeBarItem1";
            this.changeWeightedLegendTypeBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // weightedLegendNoneBarItem1
            // 
            this.weightedLegendNoneBarItem1.Id = 206;
            this.weightedLegendNoneBarItem1.Name = "weightedLegendNoneBarItem1";
            // 
            // weightedLegendLinearBarItem1
            // 
            this.weightedLegendLinearBarItem1.Id = 207;
            this.weightedLegendLinearBarItem1.Name = "weightedLegendLinearBarItem1";
            // 
            // weightedLegendNestedBarItem1
            // 
            this.weightedLegendNestedBarItem1.Id = 208;
            this.weightedLegendNestedBarItem1.Name = "weightedLegendNestedBarItem1";
            // 
            // galleryWeightedLegendPositionItem1
            // 
            // 
            // 
            // 
            this.galleryWeightedLegendPositionItem1.Gallery.ColumnCount = 3;
            mapWeightedLegendTopLeftGalleryItem1.Caption = "";
            mapWeightedLegendTopLeftGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image88")));
            mapWeightedLegendTopCenterGalleryItem1.Caption = "";
            mapWeightedLegendTopCenterGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image89")));
            mapWeightedLegendTopRightGalleryItem1.Caption = "";
            mapWeightedLegendTopRightGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image90")));
            mapWeightedLegendBottomLeftGalleryItem1.Caption = "";
            mapWeightedLegendBottomLeftGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image91")));
            mapWeightedLegendBottomCenterGalleryItem1.Caption = "";
            mapWeightedLegendBottomCenterGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image92")));
            mapWeightedLegendBottomRightGalleryItem1.Caption = "";
            mapWeightedLegendBottomRightGalleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image93")));
            mapWeightedLegendGalleryGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            mapWeightedLegendTopLeftGalleryItem1,
            mapWeightedLegendTopCenterGalleryItem1,
            mapWeightedLegendTopRightGalleryItem1,
            mapWeightedLegendBottomLeftGalleryItem1,
            mapWeightedLegendBottomCenterGalleryItem1,
            mapWeightedLegendBottomRightGalleryItem1});
            this.galleryWeightedLegendPositionItem1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            mapWeightedLegendGalleryGroup1});
            this.galleryWeightedLegendPositionItem1.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.galleryWeightedLegendPositionItem1.Gallery.RowCount = 2;
            this.galleryWeightedLegendPositionItem1.Id = 209;
            this.galleryWeightedLegendPositionItem1.Name = "galleryWeightedLegendPositionItem1";
            // 
            // filteringRibbonPageGroup12
            // 
            this.filteringRibbonPageGroup12.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup12.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup12.Name = "filteringRibbonPageGroup12";
            // 
            // dataRibbonPage12
            // 
            this.dataRibbonPage12.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup12,
            this.masterFilterRibbonPageGroup10,
            this.interactivitySettingsRibbonPageGroup12,
            this.geoPointMapClusterizationRibbonPageGroup3});
            this.dataRibbonPage12.Name = "dataRibbonPage12";
            this.dataRibbonPage12.Visible = false;
            // 
            // pieMapToolsRibbonPageCategory1
            // 
            this.pieMapToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.pieMapToolsRibbonPageCategory1.Name = "pieMapToolsRibbonPageCategory1";
            this.pieMapToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage12,
            this.dashboardItemDesignRibbonPage12});
            this.pieMapToolsRibbonPageCategory1.Visible = false;
            // 
            // masterFilterRibbonPageGroup10
            // 
            this.masterFilterRibbonPageGroup10.ItemLinks.Add(this.masterFilterBarItem1);
            this.masterFilterRibbonPageGroup10.ItemLinks.Add(this.multipleValuesMasterFilterBarItem1);
            this.masterFilterRibbonPageGroup10.Name = "masterFilterRibbonPageGroup10";
            // 
            // interactivitySettingsRibbonPageGroup12
            // 
            this.interactivitySettingsRibbonPageGroup12.ItemLinks.Add(this.crossDataSourceFilteringBarItem1);
            this.interactivitySettingsRibbonPageGroup12.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup12.Name = "interactivitySettingsRibbonPageGroup12";
            // 
            // geoPointMapClusterizationRibbonPageGroup3
            // 
            this.geoPointMapClusterizationRibbonPageGroup3.ItemLinks.Add(this.geoPointMapClusterizationBarItem1);
            this.geoPointMapClusterizationRibbonPageGroup3.Name = "geoPointMapClusterizationRibbonPageGroup3";
            // 
            // commonItemDesignRibbonPageGroup12
            // 
            this.commonItemDesignRibbonPageGroup12.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup12.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup12.Name = "commonItemDesignRibbonPageGroup12";
            // 
            // dashboardItemDesignRibbonPage12
            // 
            this.dashboardItemDesignRibbonPage12.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup12,
            this.mapShapefileRibbonPageGroup4,
            this.mapNavigationPageGroup4,
            this.mapShapeLabelsAttributePageGroup4,
            this.mapLegendPositionPageGroup3,
            this.weightedLegendPageGroup2,
            this.pieMapOptionsPageGroup1,
            this.coloringOptionsRibbonPageGroup5});
            this.dashboardItemDesignRibbonPage12.Name = "dashboardItemDesignRibbonPage12";
            this.dashboardItemDesignRibbonPage12.Visible = false;
            // 
            // mapShapefileRibbonPageGroup4
            // 
            this.mapShapefileRibbonPageGroup4.ItemLinks.Add(this.mapLoadBarItem1);
            this.mapShapefileRibbonPageGroup4.ItemLinks.Add(this.mapImportBarItem1);
            this.mapShapefileRibbonPageGroup4.ItemLinks.Add(this.mapDefaultShapefileBarItem1);
            this.mapShapefileRibbonPageGroup4.Name = "mapShapefileRibbonPageGroup4";
            // 
            // mapNavigationPageGroup4
            // 
            this.mapNavigationPageGroup4.ItemLinks.Add(this.mapLockNavigationBarItem1);
            this.mapNavigationPageGroup4.ItemLinks.Add(this.mapFullExtentBarItem1);
            this.mapNavigationPageGroup4.Name = "mapNavigationPageGroup4";
            // 
            // mapShapeLabelsAttributePageGroup4
            // 
            this.mapShapeLabelsAttributePageGroup4.ItemLinks.Add(this.mapShapeTitleAttributeBarItem1);
            this.mapShapeLabelsAttributePageGroup4.Name = "mapShapeLabelsAttributePageGroup4";
            // 
            // mapLegendPositionPageGroup3
            // 
            this.mapLegendPositionPageGroup3.ItemLinks.Add(this.mapShowLegendBarItem1);
            this.mapLegendPositionPageGroup3.ItemLinks.Add(this.galleryMapLegendPositionItem1);
            this.mapLegendPositionPageGroup3.Name = "mapLegendPositionPageGroup3";
            // 
            // weightedLegendPageGroup2
            // 
            this.weightedLegendPageGroup2.ItemLinks.Add(this.changeWeightedLegendTypeBarItem1);
            this.weightedLegendPageGroup2.ItemLinks.Add(this.galleryWeightedLegendPositionItem1);
            this.weightedLegendPageGroup2.Name = "weightedLegendPageGroup2";
            // 
            // pieMapOptionsPageGroup1
            // 
            this.pieMapOptionsPageGroup1.ItemLinks.Add(this.pieMapIsWeightedBarItem1);
            this.pieMapOptionsPageGroup1.Name = "pieMapOptionsPageGroup1";
            // 
            // pieMapIsWeightedBarItem1
            // 
            this.pieMapIsWeightedBarItem1.Id = 210;
            this.pieMapIsWeightedBarItem1.Name = "pieMapIsWeightedBarItem1";
            // 
            // coloringOptionsRibbonPageGroup5
            // 
            this.coloringOptionsRibbonPageGroup5.ItemLinks.Add(this.useGlobalColorsBarItem1);
            this.coloringOptionsRibbonPageGroup5.ItemLinks.Add(this.useLocalColorsBarItem1);
            this.coloringOptionsRibbonPageGroup5.ItemLinks.Add(this.editActualColorsBarItem1);
            this.coloringOptionsRibbonPageGroup5.Name = "coloringOptionsRibbonPageGroup5";
            // 
            // filteringRibbonPageGroup13
            // 
            this.filteringRibbonPageGroup13.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup13.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup13.Name = "filteringRibbonPageGroup13";
            // 
            // dataRibbonPage13
            // 
            this.dataRibbonPage13.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup13,
            this.interactivitySettingsRibbonPageGroup13});
            this.dataRibbonPage13.Name = "dataRibbonPage13";
            this.dataRibbonPage13.Visible = false;
            // 
            // filterElementToolsRibbonPageCategory1
            // 
            this.filterElementToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.filterElementToolsRibbonPageCategory1.Name = "filterElementToolsRibbonPageCategory1";
            this.filterElementToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage13,
            this.dashboardItemDesignRibbonPage13});
            this.filterElementToolsRibbonPageCategory1.Visible = false;
            // 
            // interactivitySettingsRibbonPageGroup13
            // 
            this.interactivitySettingsRibbonPageGroup13.ItemLinks.Add(this.crossDataSourceFilteringBarItem1);
            this.interactivitySettingsRibbonPageGroup13.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup13.Name = "interactivitySettingsRibbonPageGroup13";
            // 
            // commonItemDesignRibbonPageGroup13
            // 
            this.commonItemDesignRibbonPageGroup13.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup13.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup13.Name = "commonItemDesignRibbonPageGroup13";
            // 
            // dashboardItemDesignRibbonPage13
            // 
            this.dashboardItemDesignRibbonPage13.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup13,
            this.filterElementTypeRibbonPageGroup1,
            this.filterElementItemOptionsRibbonPageGroup1,
            this.treeViewOptionsRibbonPageGroup1,
            this.treeViewLayoutRibbonPageGroup1});
            this.dashboardItemDesignRibbonPage13.Name = "dashboardItemDesignRibbonPage13";
            this.dashboardItemDesignRibbonPage13.Visible = false;
            // 
            // filterElementTypeRibbonPageGroup1
            // 
            this.filterElementTypeRibbonPageGroup1.ItemLinks.Add(this.comboBoxStandardTypeBarItem1);
            this.filterElementTypeRibbonPageGroup1.ItemLinks.Add(this.comboBoxCheckedTypeBarItem1);
            this.filterElementTypeRibbonPageGroup1.ItemLinks.Add(this.listBoxCheckedTypeBarItem1);
            this.filterElementTypeRibbonPageGroup1.ItemLinks.Add(this.listBoxRadioTypeBarItem1);
            this.filterElementTypeRibbonPageGroup1.Name = "filterElementTypeRibbonPageGroup1";
            this.filterElementTypeRibbonPageGroup1.Visible = false;
            // 
            // comboBoxStandardTypeBarItem1
            // 
            this.comboBoxStandardTypeBarItem1.Id = 211;
            this.comboBoxStandardTypeBarItem1.Name = "comboBoxStandardTypeBarItem1";
            // 
            // comboBoxCheckedTypeBarItem1
            // 
            this.comboBoxCheckedTypeBarItem1.Id = 212;
            this.comboBoxCheckedTypeBarItem1.Name = "comboBoxCheckedTypeBarItem1";
            // 
            // listBoxCheckedTypeBarItem1
            // 
            this.listBoxCheckedTypeBarItem1.Id = 213;
            this.listBoxCheckedTypeBarItem1.Name = "listBoxCheckedTypeBarItem1";
            // 
            // listBoxRadioTypeBarItem1
            // 
            this.listBoxRadioTypeBarItem1.Id = 214;
            this.listBoxRadioTypeBarItem1.Name = "listBoxRadioTypeBarItem1";
            // 
            // filterElementItemOptionsRibbonPageGroup1
            // 
            this.filterElementItemOptionsRibbonPageGroup1.ItemLinks.Add(this.filterElementShowAllValueBarItem1);
            this.filterElementItemOptionsRibbonPageGroup1.ItemLinks.Add(this.filterElementEnableSearchBarItem1);
            this.filterElementItemOptionsRibbonPageGroup1.Name = "filterElementItemOptionsRibbonPageGroup1";
            this.filterElementItemOptionsRibbonPageGroup1.Visible = false;
            // 
            // filterElementShowAllValueBarItem1
            // 
            this.filterElementShowAllValueBarItem1.Id = 215;
            this.filterElementShowAllValueBarItem1.Name = "filterElementShowAllValueBarItem1";
            // 
            // filterElementEnableSearchBarItem1
            // 
            this.filterElementEnableSearchBarItem1.Id = 216;
            this.filterElementEnableSearchBarItem1.Name = "filterElementEnableSearchBarItem1";
            // 
            // treeViewOptionsRibbonPageGroup1
            // 
            this.treeViewOptionsRibbonPageGroup1.ItemLinks.Add(this.filterElementEnableSearchBarItem1);
            this.treeViewOptionsRibbonPageGroup1.Name = "treeViewOptionsRibbonPageGroup1";
            this.treeViewOptionsRibbonPageGroup1.Visible = false;
            // 
            // treeViewLayoutRibbonPageGroup1
            // 
            this.treeViewLayoutRibbonPageGroup1.ItemLinks.Add(this.treeViewAutoExpandBarItem1);
            this.treeViewLayoutRibbonPageGroup1.Name = "treeViewLayoutRibbonPageGroup1";
            this.treeViewLayoutRibbonPageGroup1.Visible = false;
            // 
            // treeViewAutoExpandBarItem1
            // 
            this.treeViewAutoExpandBarItem1.Id = 217;
            this.treeViewAutoExpandBarItem1.Name = "treeViewAutoExpandBarItem1";
            // 
            // filteringRibbonPageGroup14
            // 
            this.filteringRibbonPageGroup14.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup14.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup14.Name = "filteringRibbonPageGroup14";
            // 
            // dataRibbonPage14
            // 
            this.dataRibbonPage14.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup14,
            this.interactivitySettingsRibbonPageGroup14});
            this.dataRibbonPage14.Name = "dataRibbonPage14";
            this.dataRibbonPage14.Visible = false;
            // 
            // boundImageToolsRibbonPageCategory1
            // 
            this.boundImageToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.boundImageToolsRibbonPageCategory1.Name = "boundImageToolsRibbonPageCategory1";
            this.boundImageToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage14,
            this.dashboardItemDesignRibbonPage14});
            this.boundImageToolsRibbonPageCategory1.Visible = false;
            // 
            // interactivitySettingsRibbonPageGroup14
            // 
            this.interactivitySettingsRibbonPageGroup14.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup14.Name = "interactivitySettingsRibbonPageGroup14";
            // 
            // commonItemDesignRibbonPageGroup14
            // 
            this.commonItemDesignRibbonPageGroup14.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup14.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup14.Name = "commonItemDesignRibbonPageGroup14";
            // 
            // dashboardItemDesignRibbonPage14
            // 
            this.dashboardItemDesignRibbonPage14.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup14,
            this.imageSizeModeRibbonPageGroup1,
            this.imageAlignmentRibbonPageGroup1});
            this.dashboardItemDesignRibbonPage14.Name = "dashboardItemDesignRibbonPage14";
            this.dashboardItemDesignRibbonPage14.Visible = false;
            // 
            // imageSizeModeRibbonPageGroup1
            // 
            this.imageSizeModeRibbonPageGroup1.ItemLinks.Add(this.imageSizeModeClipBarItem1);
            this.imageSizeModeRibbonPageGroup1.ItemLinks.Add(this.imageSizeModeStretchBarItem1);
            this.imageSizeModeRibbonPageGroup1.ItemLinks.Add(this.imageSizeModeSqueezeBarItem1);
            this.imageSizeModeRibbonPageGroup1.ItemLinks.Add(this.imageSizeModeZoomBarItem1);
            this.imageSizeModeRibbonPageGroup1.Name = "imageSizeModeRibbonPageGroup1";
            // 
            // imageSizeModeClipBarItem1
            // 
            this.imageSizeModeClipBarItem1.Id = 218;
            this.imageSizeModeClipBarItem1.Name = "imageSizeModeClipBarItem1";
            // 
            // imageSizeModeStretchBarItem1
            // 
            this.imageSizeModeStretchBarItem1.Id = 219;
            this.imageSizeModeStretchBarItem1.Name = "imageSizeModeStretchBarItem1";
            // 
            // imageSizeModeSqueezeBarItem1
            // 
            this.imageSizeModeSqueezeBarItem1.Id = 220;
            this.imageSizeModeSqueezeBarItem1.Name = "imageSizeModeSqueezeBarItem1";
            // 
            // imageSizeModeZoomBarItem1
            // 
            this.imageSizeModeZoomBarItem1.Id = 221;
            this.imageSizeModeZoomBarItem1.Name = "imageSizeModeZoomBarItem1";
            // 
            // imageAlignmentRibbonPageGroup1
            // 
            this.imageAlignmentRibbonPageGroup1.ItemLinks.Add(this.imageAlignmentTopLeftBarItem1);
            this.imageAlignmentRibbonPageGroup1.ItemLinks.Add(this.imageAlignmentCenterLeftBarItem1);
            this.imageAlignmentRibbonPageGroup1.ItemLinks.Add(this.imageAlignmentBottomLeftBarItem1);
            this.imageAlignmentRibbonPageGroup1.ItemLinks.Add(this.imageAlignmentTopCenterBarItem1);
            this.imageAlignmentRibbonPageGroup1.ItemLinks.Add(this.imageAlignmentCenterCenterBarItem1);
            this.imageAlignmentRibbonPageGroup1.ItemLinks.Add(this.imageAlignmentBottomCenterBarItem1);
            this.imageAlignmentRibbonPageGroup1.ItemLinks.Add(this.imageAlignmentTopRightBarItem1);
            this.imageAlignmentRibbonPageGroup1.ItemLinks.Add(this.imageAlignmentCenterRightBarItem1);
            this.imageAlignmentRibbonPageGroup1.ItemLinks.Add(this.imageAlignmentBottomRightBarItem1);
            this.imageAlignmentRibbonPageGroup1.Name = "imageAlignmentRibbonPageGroup1";
            // 
            // imageAlignmentTopLeftBarItem1
            // 
            this.imageAlignmentTopLeftBarItem1.Id = 222;
            this.imageAlignmentTopLeftBarItem1.Name = "imageAlignmentTopLeftBarItem1";
            this.imageAlignmentTopLeftBarItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // imageAlignmentCenterLeftBarItem1
            // 
            this.imageAlignmentCenterLeftBarItem1.Id = 223;
            this.imageAlignmentCenterLeftBarItem1.Name = "imageAlignmentCenterLeftBarItem1";
            this.imageAlignmentCenterLeftBarItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // imageAlignmentBottomLeftBarItem1
            // 
            this.imageAlignmentBottomLeftBarItem1.Id = 224;
            this.imageAlignmentBottomLeftBarItem1.Name = "imageAlignmentBottomLeftBarItem1";
            this.imageAlignmentBottomLeftBarItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // imageAlignmentTopCenterBarItem1
            // 
            this.imageAlignmentTopCenterBarItem1.Id = 225;
            this.imageAlignmentTopCenterBarItem1.Name = "imageAlignmentTopCenterBarItem1";
            this.imageAlignmentTopCenterBarItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // imageAlignmentCenterCenterBarItem1
            // 
            this.imageAlignmentCenterCenterBarItem1.Id = 226;
            this.imageAlignmentCenterCenterBarItem1.Name = "imageAlignmentCenterCenterBarItem1";
            this.imageAlignmentCenterCenterBarItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // imageAlignmentBottomCenterBarItem1
            // 
            this.imageAlignmentBottomCenterBarItem1.Id = 227;
            this.imageAlignmentBottomCenterBarItem1.Name = "imageAlignmentBottomCenterBarItem1";
            this.imageAlignmentBottomCenterBarItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // imageAlignmentTopRightBarItem1
            // 
            this.imageAlignmentTopRightBarItem1.Id = 228;
            this.imageAlignmentTopRightBarItem1.Name = "imageAlignmentTopRightBarItem1";
            this.imageAlignmentTopRightBarItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // imageAlignmentCenterRightBarItem1
            // 
            this.imageAlignmentCenterRightBarItem1.Id = 229;
            this.imageAlignmentCenterRightBarItem1.Name = "imageAlignmentCenterRightBarItem1";
            this.imageAlignmentCenterRightBarItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // imageAlignmentBottomRightBarItem1
            // 
            this.imageAlignmentBottomRightBarItem1.Id = 230;
            this.imageAlignmentBottomRightBarItem1.Name = "imageAlignmentBottomRightBarItem1";
            this.imageAlignmentBottomRightBarItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // filteringRibbonPageGroup15
            // 
            this.filteringRibbonPageGroup15.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup15.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup15.Name = "filteringRibbonPageGroup15";
            // 
            // dataRibbonPage15
            // 
            this.dataRibbonPage15.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup15,
            this.interactivitySettingsRibbonPageGroup15});
            this.dataRibbonPage15.Name = "dataRibbonPage15";
            this.dataRibbonPage15.Visible = false;
            // 
            // textBoxToolsRibbonPageCategory1
            // 
            this.textBoxToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.textBoxToolsRibbonPageCategory1.Name = "textBoxToolsRibbonPageCategory1";
            this.textBoxToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage15,
            this.dashboardItemDesignRibbonPage15});
            this.textBoxToolsRibbonPageCategory1.Visible = false;
            // 
            // interactivitySettingsRibbonPageGroup15
            // 
            this.interactivitySettingsRibbonPageGroup15.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup15.Name = "interactivitySettingsRibbonPageGroup15";
            // 
            // commonItemDesignRibbonPageGroup15
            // 
            this.commonItemDesignRibbonPageGroup15.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup15.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup15.Name = "commonItemDesignRibbonPageGroup15";
            // 
            // dashboardItemDesignRibbonPage15
            // 
            this.dashboardItemDesignRibbonPage15.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup15,
            this.textBoxEditingRibbonPageGroup1});
            this.dashboardItemDesignRibbonPage15.Name = "dashboardItemDesignRibbonPage15";
            this.dashboardItemDesignRibbonPage15.Visible = false;
            // 
            // textBoxEditingRibbonPageGroup1
            // 
            this.textBoxEditingRibbonPageGroup1.ItemLinks.Add(this.textBoxEditTextBarItem1);
            this.textBoxEditingRibbonPageGroup1.ItemLinks.Add(this.textBoxInsertFieldBarItem1);
            this.textBoxEditingRibbonPageGroup1.Name = "textBoxEditingRibbonPageGroup1";
            // 
            // textBoxEditTextBarItem1
            // 
            this.textBoxEditTextBarItem1.Id = 231;
            this.textBoxEditTextBarItem1.Name = "textBoxEditTextBarItem1";
            // 
            // textBoxInsertFieldBarItem1
            // 
            this.textBoxInsertFieldBarItem1.Id = 232;
            this.textBoxInsertFieldBarItem1.Name = "textBoxInsertFieldBarItem1";
            // 
            // filteringRibbonPageGroup16
            // 
            this.filteringRibbonPageGroup16.ItemLinks.Add(this.editFilterBarItem1);
            this.filteringRibbonPageGroup16.ItemLinks.Add(this.clearFilterBarItem1);
            this.filteringRibbonPageGroup16.Name = "filteringRibbonPageGroup16";
            // 
            // dataRibbonPage16
            // 
            this.dataRibbonPage16.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.filteringRibbonPageGroup16,
            this.masterFilterRibbonPageGroup11,
            this.interactivitySettingsRibbonPageGroup16});
            this.dataRibbonPage16.Name = "dataRibbonPage16";
            this.dataRibbonPage16.Visible = false;
            // 
            // treemapToolsRibbonPageCategory1
            // 
            this.treemapToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.treemapToolsRibbonPageCategory1.Name = "treemapToolsRibbonPageCategory1";
            this.treemapToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage16,
            this.dashboardItemDesignRibbonPage16});
            this.treemapToolsRibbonPageCategory1.Visible = false;
            // 
            // masterFilterRibbonPageGroup11
            // 
            this.masterFilterRibbonPageGroup11.ItemLinks.Add(this.masterFilterBarItem1);
            this.masterFilterRibbonPageGroup11.ItemLinks.Add(this.multipleValuesMasterFilterBarItem1);
            this.masterFilterRibbonPageGroup11.ItemLinks.Add(this.drillDownBarItem1);
            this.masterFilterRibbonPageGroup11.Name = "masterFilterRibbonPageGroup11";
            // 
            // interactivitySettingsRibbonPageGroup16
            // 
            this.interactivitySettingsRibbonPageGroup16.ItemLinks.Add(this.crossDataSourceFilteringBarItem1);
            this.interactivitySettingsRibbonPageGroup16.ItemLinks.Add(this.ignoreMasterFiltersBarItem1);
            this.interactivitySettingsRibbonPageGroup16.Name = "interactivitySettingsRibbonPageGroup16";
            // 
            // commonItemDesignRibbonPageGroup16
            // 
            this.commonItemDesignRibbonPageGroup16.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup16.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup16.Name = "commonItemDesignRibbonPageGroup16";
            // 
            // dashboardItemDesignRibbonPage16
            // 
            this.dashboardItemDesignRibbonPage16.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup16,
            this.treemapLayoutRibbonPageGroup1,
            this.treemapTileLabelsRibbonPageGroup1,
            this.treemapGroupLabelsRibbonPageGroup1,
            this.coloringOptionsRibbonPageGroup6});
            this.dashboardItemDesignRibbonPage16.Name = "dashboardItemDesignRibbonPage16";
            this.dashboardItemDesignRibbonPage16.Visible = false;
            // 
            // treemapLayoutRibbonPageGroup1
            // 
            this.treemapLayoutRibbonPageGroup1.ItemLinks.Add(this.treemapSliceAndDiceLayoutAlgorithmBarItem1);
            this.treemapLayoutRibbonPageGroup1.ItemLinks.Add(this.treemapSquarifiedLayoutAlgorithmBarItem1);
            this.treemapLayoutRibbonPageGroup1.ItemLinks.Add(this.treemapStripedLayoutAlgorithmBarItem1);
            this.treemapLayoutRibbonPageGroup1.ItemLinks.Add(this.treemapLayoutDirectionBarItem1);
            this.treemapLayoutRibbonPageGroup1.Name = "treemapLayoutRibbonPageGroup1";
            // 
            // treemapSliceAndDiceLayoutAlgorithmBarItem1
            // 
            this.treemapSliceAndDiceLayoutAlgorithmBarItem1.Id = 233;
            this.treemapSliceAndDiceLayoutAlgorithmBarItem1.Name = "treemapSliceAndDiceLayoutAlgorithmBarItem1";
            // 
            // treemapSquarifiedLayoutAlgorithmBarItem1
            // 
            this.treemapSquarifiedLayoutAlgorithmBarItem1.Id = 234;
            this.treemapSquarifiedLayoutAlgorithmBarItem1.Name = "treemapSquarifiedLayoutAlgorithmBarItem1";
            // 
            // treemapStripedLayoutAlgorithmBarItem1
            // 
            this.treemapStripedLayoutAlgorithmBarItem1.Id = 235;
            this.treemapStripedLayoutAlgorithmBarItem1.Name = "treemapStripedLayoutAlgorithmBarItem1";
            // 
            // treemapLayoutDirectionBarItem1
            // 
            this.treemapLayoutDirectionBarItem1.Id = 236;
            this.treemapLayoutDirectionBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapBottomLeftToTopRightLayoutDirectionBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapBottomRightToTopLeftLayoutDirectionBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapTopLeftToBottomRightLayoutDirectionBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapTopRightToBottomLeftLayoutDirectionBarItem1)});
            this.treemapLayoutDirectionBarItem1.Name = "treemapLayoutDirectionBarItem1";
            this.treemapLayoutDirectionBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph;
            // 
            // treemapBottomLeftToTopRightLayoutDirectionBarItem1
            // 
            this.treemapBottomLeftToTopRightLayoutDirectionBarItem1.Id = 237;
            this.treemapBottomLeftToTopRightLayoutDirectionBarItem1.Name = "treemapBottomLeftToTopRightLayoutDirectionBarItem1";
            // 
            // treemapBottomRightToTopLeftLayoutDirectionBarItem1
            // 
            this.treemapBottomRightToTopLeftLayoutDirectionBarItem1.Id = 238;
            this.treemapBottomRightToTopLeftLayoutDirectionBarItem1.Name = "treemapBottomRightToTopLeftLayoutDirectionBarItem1";
            // 
            // treemapTopLeftToBottomRightLayoutDirectionBarItem1
            // 
            this.treemapTopLeftToBottomRightLayoutDirectionBarItem1.Id = 239;
            this.treemapTopLeftToBottomRightLayoutDirectionBarItem1.Name = "treemapTopLeftToBottomRightLayoutDirectionBarItem1";
            // 
            // treemapTopRightToBottomLeftLayoutDirectionBarItem1
            // 
            this.treemapTopRightToBottomLeftLayoutDirectionBarItem1.Id = 240;
            this.treemapTopRightToBottomLeftLayoutDirectionBarItem1.Name = "treemapTopRightToBottomLeftLayoutDirectionBarItem1";
            // 
            // treemapTileLabelsRibbonPageGroup1
            // 
            this.treemapTileLabelsRibbonPageGroup1.ItemLinks.Add(this.treemapTileLabelsBarItem1);
            this.treemapTileLabelsRibbonPageGroup1.ItemLinks.Add(this.treemapTileTooltipsBarItem1);
            this.treemapTileLabelsRibbonPageGroup1.Name = "treemapTileLabelsRibbonPageGroup1";
            // 
            // treemapTileLabelsBarItem1
            // 
            this.treemapTileLabelsBarItem1.Id = 241;
            this.treemapTileLabelsBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapTileLabelsNoneBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapTileLabelsArgumentBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapTileLabelsValueBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapTileLabelsArgumentAndValueBarItem1)});
            this.treemapTileLabelsBarItem1.Name = "treemapTileLabelsBarItem1";
            this.treemapTileLabelsBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // treemapTileLabelsNoneBarItem1
            // 
            this.treemapTileLabelsNoneBarItem1.Id = 242;
            this.treemapTileLabelsNoneBarItem1.Name = "treemapTileLabelsNoneBarItem1";
            // 
            // treemapTileLabelsArgumentBarItem1
            // 
            this.treemapTileLabelsArgumentBarItem1.Id = 243;
            this.treemapTileLabelsArgumentBarItem1.Name = "treemapTileLabelsArgumentBarItem1";
            // 
            // treemapTileLabelsValueBarItem1
            // 
            this.treemapTileLabelsValueBarItem1.Id = 244;
            this.treemapTileLabelsValueBarItem1.Name = "treemapTileLabelsValueBarItem1";
            // 
            // treemapTileLabelsArgumentAndValueBarItem1
            // 
            this.treemapTileLabelsArgumentAndValueBarItem1.Id = 245;
            this.treemapTileLabelsArgumentAndValueBarItem1.Name = "treemapTileLabelsArgumentAndValueBarItem1";
            // 
            // treemapTileTooltipsBarItem1
            // 
            this.treemapTileTooltipsBarItem1.Id = 246;
            this.treemapTileTooltipsBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapTileTooltipsNoneBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapTileTooltipsArgumentBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapTileTooltipsValueBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapTileTooltipsArgumentAndValueBarItem1)});
            this.treemapTileTooltipsBarItem1.Name = "treemapTileTooltipsBarItem1";
            this.treemapTileTooltipsBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // treemapTileTooltipsNoneBarItem1
            // 
            this.treemapTileTooltipsNoneBarItem1.Id = 247;
            this.treemapTileTooltipsNoneBarItem1.Name = "treemapTileTooltipsNoneBarItem1";
            // 
            // treemapTileTooltipsArgumentBarItem1
            // 
            this.treemapTileTooltipsArgumentBarItem1.Id = 248;
            this.treemapTileTooltipsArgumentBarItem1.Name = "treemapTileTooltipsArgumentBarItem1";
            // 
            // treemapTileTooltipsValueBarItem1
            // 
            this.treemapTileTooltipsValueBarItem1.Id = 249;
            this.treemapTileTooltipsValueBarItem1.Name = "treemapTileTooltipsValueBarItem1";
            // 
            // treemapTileTooltipsArgumentAndValueBarItem1
            // 
            this.treemapTileTooltipsArgumentAndValueBarItem1.Id = 250;
            this.treemapTileTooltipsArgumentAndValueBarItem1.Name = "treemapTileTooltipsArgumentAndValueBarItem1";
            // 
            // treemapGroupLabelsRibbonPageGroup1
            // 
            this.treemapGroupLabelsRibbonPageGroup1.ItemLinks.Add(this.treemapGroupLabelsBarItem1);
            this.treemapGroupLabelsRibbonPageGroup1.ItemLinks.Add(this.treemapGroupTooltipsBarItem1);
            this.treemapGroupLabelsRibbonPageGroup1.Name = "treemapGroupLabelsRibbonPageGroup1";
            // 
            // treemapGroupLabelsBarItem1
            // 
            this.treemapGroupLabelsBarItem1.Id = 251;
            this.treemapGroupLabelsBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapGroupLabelsNoneBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapGroupLabelsArgumentBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapGroupLabelsValueBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapGroupLabelsArgumentAndValueBarItem1)});
            this.treemapGroupLabelsBarItem1.Name = "treemapGroupLabelsBarItem1";
            this.treemapGroupLabelsBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // treemapGroupLabelsNoneBarItem1
            // 
            this.treemapGroupLabelsNoneBarItem1.Id = 252;
            this.treemapGroupLabelsNoneBarItem1.Name = "treemapGroupLabelsNoneBarItem1";
            // 
            // treemapGroupLabelsArgumentBarItem1
            // 
            this.treemapGroupLabelsArgumentBarItem1.Id = 253;
            this.treemapGroupLabelsArgumentBarItem1.Name = "treemapGroupLabelsArgumentBarItem1";
            // 
            // treemapGroupLabelsValueBarItem1
            // 
            this.treemapGroupLabelsValueBarItem1.Id = 254;
            this.treemapGroupLabelsValueBarItem1.Name = "treemapGroupLabelsValueBarItem1";
            // 
            // treemapGroupLabelsArgumentAndValueBarItem1
            // 
            this.treemapGroupLabelsArgumentAndValueBarItem1.Id = 255;
            this.treemapGroupLabelsArgumentAndValueBarItem1.Name = "treemapGroupLabelsArgumentAndValueBarItem1";
            // 
            // treemapGroupTooltipsBarItem1
            // 
            this.treemapGroupTooltipsBarItem1.Id = 256;
            this.treemapGroupTooltipsBarItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapGroupTooltipsNoneBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapGroupTooltipsArgumentBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapGroupTooltipsValueBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.treemapGroupTooltipsArgumentAndValueBarItem1)});
            this.treemapGroupTooltipsBarItem1.Name = "treemapGroupTooltipsBarItem1";
            this.treemapGroupTooltipsBarItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu;
            // 
            // treemapGroupTooltipsNoneBarItem1
            // 
            this.treemapGroupTooltipsNoneBarItem1.Id = 257;
            this.treemapGroupTooltipsNoneBarItem1.Name = "treemapGroupTooltipsNoneBarItem1";
            // 
            // treemapGroupTooltipsArgumentBarItem1
            // 
            this.treemapGroupTooltipsArgumentBarItem1.Id = 258;
            this.treemapGroupTooltipsArgumentBarItem1.Name = "treemapGroupTooltipsArgumentBarItem1";
            // 
            // treemapGroupTooltipsValueBarItem1
            // 
            this.treemapGroupTooltipsValueBarItem1.Id = 259;
            this.treemapGroupTooltipsValueBarItem1.Name = "treemapGroupTooltipsValueBarItem1";
            // 
            // treemapGroupTooltipsArgumentAndValueBarItem1
            // 
            this.treemapGroupTooltipsArgumentAndValueBarItem1.Id = 260;
            this.treemapGroupTooltipsArgumentAndValueBarItem1.Name = "treemapGroupTooltipsArgumentAndValueBarItem1";
            // 
            // coloringOptionsRibbonPageGroup6
            // 
            this.coloringOptionsRibbonPageGroup6.ItemLinks.Add(this.useGlobalColorsBarItem1);
            this.coloringOptionsRibbonPageGroup6.ItemLinks.Add(this.useLocalColorsBarItem1);
            this.coloringOptionsRibbonPageGroup6.ItemLinks.Add(this.editActualColorsBarItem1);
            this.coloringOptionsRibbonPageGroup6.Name = "coloringOptionsRibbonPageGroup6";
            // 
            // commonItemDesignRibbonPageGroup17
            // 
            this.commonItemDesignRibbonPageGroup17.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup17.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup17.Name = "commonItemDesignRibbonPageGroup17";
            // 
            // dashboardItemDesignRibbonPage17
            // 
            this.dashboardItemDesignRibbonPage17.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup17,
            this.imageOpenRibbonPageGroup1,
            this.imageSizeModeRibbonPageGroup2,
            this.imageAlignmentRibbonPageGroup2});
            this.dashboardItemDesignRibbonPage17.Name = "dashboardItemDesignRibbonPage17";
            this.dashboardItemDesignRibbonPage17.Visible = false;
            // 
            // imageToolsRibbonPageCategory1
            // 
            this.imageToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.imageToolsRibbonPageCategory1.Name = "imageToolsRibbonPageCategory1";
            this.imageToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dashboardItemDesignRibbonPage17});
            this.imageToolsRibbonPageCategory1.Visible = false;
            // 
            // imageOpenRibbonPageGroup1
            // 
            this.imageOpenRibbonPageGroup1.ItemLinks.Add(this.imageLoadBarItem1);
            this.imageOpenRibbonPageGroup1.ItemLinks.Add(this.imageImportBarItem1);
            this.imageOpenRibbonPageGroup1.Name = "imageOpenRibbonPageGroup1";
            // 
            // imageLoadBarItem1
            // 
            this.imageLoadBarItem1.Id = 261;
            this.imageLoadBarItem1.Name = "imageLoadBarItem1";
            // 
            // imageImportBarItem1
            // 
            this.imageImportBarItem1.Id = 262;
            this.imageImportBarItem1.Name = "imageImportBarItem1";
            // 
            // imageSizeModeRibbonPageGroup2
            // 
            this.imageSizeModeRibbonPageGroup2.ItemLinks.Add(this.imageSizeModeClipBarItem1);
            this.imageSizeModeRibbonPageGroup2.ItemLinks.Add(this.imageSizeModeStretchBarItem1);
            this.imageSizeModeRibbonPageGroup2.ItemLinks.Add(this.imageSizeModeSqueezeBarItem1);
            this.imageSizeModeRibbonPageGroup2.ItemLinks.Add(this.imageSizeModeZoomBarItem1);
            this.imageSizeModeRibbonPageGroup2.Name = "imageSizeModeRibbonPageGroup2";
            // 
            // imageAlignmentRibbonPageGroup2
            // 
            this.imageAlignmentRibbonPageGroup2.ItemLinks.Add(this.imageAlignmentTopLeftBarItem1);
            this.imageAlignmentRibbonPageGroup2.ItemLinks.Add(this.imageAlignmentCenterLeftBarItem1);
            this.imageAlignmentRibbonPageGroup2.ItemLinks.Add(this.imageAlignmentBottomLeftBarItem1);
            this.imageAlignmentRibbonPageGroup2.ItemLinks.Add(this.imageAlignmentTopCenterBarItem1);
            this.imageAlignmentRibbonPageGroup2.ItemLinks.Add(this.imageAlignmentCenterCenterBarItem1);
            this.imageAlignmentRibbonPageGroup2.ItemLinks.Add(this.imageAlignmentBottomCenterBarItem1);
            this.imageAlignmentRibbonPageGroup2.ItemLinks.Add(this.imageAlignmentTopRightBarItem1);
            this.imageAlignmentRibbonPageGroup2.ItemLinks.Add(this.imageAlignmentCenterRightBarItem1);
            this.imageAlignmentRibbonPageGroup2.ItemLinks.Add(this.imageAlignmentBottomRightBarItem1);
            this.imageAlignmentRibbonPageGroup2.Name = "imageAlignmentRibbonPageGroup2";
            // 
            // masterFilterRibbonPageGroup12
            // 
            this.masterFilterRibbonPageGroup12.ItemLinks.Add(this.groupMasterFilterBarItem1);
            this.masterFilterRibbonPageGroup12.ItemLinks.Add(this.groupIgnoreMasterFilterBarItem1);
            this.masterFilterRibbonPageGroup12.Name = "masterFilterRibbonPageGroup12";
            // 
            // dataRibbonPage17
            // 
            this.dataRibbonPage17.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.masterFilterRibbonPageGroup12});
            this.dataRibbonPage17.Name = "dataRibbonPage17";
            this.dataRibbonPage17.Visible = false;
            // 
            // groupToolsRibbonPageCategory1
            // 
            this.groupToolsRibbonPageCategory1.Control = this.dashboardDesigner1;
            this.groupToolsRibbonPageCategory1.Name = "groupToolsRibbonPageCategory1";
            this.groupToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.dataRibbonPage17,
            this.dashboardItemDesignRibbonPage18});
            this.groupToolsRibbonPageCategory1.Visible = false;
            // 
            // groupMasterFilterBarItem1
            // 
            this.groupMasterFilterBarItem1.Id = 263;
            this.groupMasterFilterBarItem1.Name = "groupMasterFilterBarItem1";
            // 
            // groupIgnoreMasterFilterBarItem1
            // 
            this.groupIgnoreMasterFilterBarItem1.Id = 264;
            this.groupIgnoreMasterFilterBarItem1.Name = "groupIgnoreMasterFilterBarItem1";
            // 
            // commonItemDesignRibbonPageGroup18
            // 
            this.commonItemDesignRibbonPageGroup18.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.commonItemDesignRibbonPageGroup18.ItemLinks.Add(this.editItemNamesBarItem1);
            this.commonItemDesignRibbonPageGroup18.Name = "commonItemDesignRibbonPageGroup18";
            // 
            // dashboardItemDesignRibbonPage18
            // 
            this.dashboardItemDesignRibbonPage18.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonItemDesignRibbonPageGroup18});
            this.dashboardItemDesignRibbonPage18.Name = "dashboardItemDesignRibbonPage18";
            this.dashboardItemDesignRibbonPage18.Visible = false;
            // 
            // textBoxEditorBarController1
            // 
            this.textBoxEditorBarController1.BarItems.Add(this.undoItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.redoItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.fileOpenItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.pasteItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.cutItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.copyItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.pasteSpecialItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeFontNameItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeFontSizeItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.fontSizeIncreaseItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.fontSizeDecreaseItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleFontBoldItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleFontItalicItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleFontUnderlineItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleFontDoubleUnderlineItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleFontStrikeoutItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleFontDoubleStrikeoutItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleFontSuperscriptItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleFontSubscriptItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeFontColorItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeFontHighlightColorItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeTextCaseItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.makeTextUpperCaseItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.makeTextLowerCaseItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.capitalizeEachWordCaseItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTextCaseItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.clearFormattingItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleBulletedListItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleNumberingListItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleMultiLevelListItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.decreaseIndentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.increaseIndentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleParagraphAlignmentLeftItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleParagraphAlignmentCenterItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleParagraphAlignmentRightItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleParagraphAlignmentJustifyItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleShowWhitespaceItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeParagraphLineSpacingItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setSingleParagraphSpacingItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setSesquialteralParagraphSpacingItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setDoubleParagraphSpacingItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.showLineSpacingFormItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.addSpacingBeforeParagraphItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.removeSpacingBeforeParagraphItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.addSpacingAfterParagraphItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.removeSpacingAfterParagraphItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeParagraphBackColorItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.galleryChangeStyleItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.findItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.replaceItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.insertTableItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.insertPictureItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.insertFloatingPictureItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.insertBookmarkItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.insertHyperlinkItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.insertSymbolItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changePageColorItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleFirstRowItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleLastRowItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleBandedRowsItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleFirstColumnItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleLastColumnItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleBandedColumnsItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.galleryChangeTableStyleItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeTableBorderLineStyleItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeTableBorderLineWeightItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeTableBorderColorItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeTableBordersItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsBottomBorderItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsTopBorderItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsLeftBorderItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsRightBorderItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.resetTableCellsAllBordersItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsAllBordersItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsOutsideBorderItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsInsideBorderItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsInsideHorizontalBorderItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsInsideVerticalBorderItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleShowTableGridLinesItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeTableCellsShadingItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.selectTableElementsItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.selectTableCellItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.selectTableColumnItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.selectTableRowItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.selectTableItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.showTablePropertiesFormItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.deleteTableElementsItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.showDeleteTableCellsFormItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.deleteTableColumnsItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.deleteTableRowsItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.deleteTableItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.insertTableRowAboveItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.insertTableRowBelowItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.insertTableColumnToLeftItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.insertTableColumnToRightItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.mergeTableCellsItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.showSplitTableCellsForm1);
            this.textBoxEditorBarController1.BarItems.Add(this.splitTableItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableAutoFitItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableAutoFitContentsItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableAutoFitWindowItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableFixedColumnWidthItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsTopLeftAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsMiddleLeftAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsBottomLeftAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsTopCenterAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsMiddleCenterAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsBottomCenterAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsTopRightAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsMiddleRightAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.toggleTableCellsBottomRightAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.showTableOptionsFormItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeFloatingObjectFillColorItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeFloatingObjectOutlineColorItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeFloatingObjectOutlineWeightItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeFloatingObjectTextWrapTypeItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectSquareTextWrapTypeItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectTightTextWrapTypeItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectThroughTextWrapTypeItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectTopAndBottomTextWrapTypeItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectBehindTextWrapTypeItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectInFrontOfTextWrapTypeItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.changeFloatingObjectAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectTopLeftAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectTopCenterAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectTopRightAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectMiddleLeftAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectMiddleCenterAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectMiddleRightAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectBottomLeftAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectBottomCenterAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.setFloatingObjectBottomRightAlignmentItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.floatingObjectBringForwardSubItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.floatingObjectBringForwardItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.floatingObjectBringToFrontItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.floatingObjectBringInFrontOfTextItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.floatingObjectSendBackwardSubItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.floatingObjectSendBackwardItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.floatingObjectSendToBackItem1);
            this.textBoxEditorBarController1.BarItems.Add(this.floatingObjectSendBehindTextItem1);
            this.textBoxEditorBarController1.Designer = this.dashboardDesigner1;
            // 
            // commonRibbonPageGroup1
            // 
            this.commonRibbonPageGroup1.ItemLinks.Add(this.undoItem1);
            this.commonRibbonPageGroup1.ItemLinks.Add(this.redoItem1);
            this.commonRibbonPageGroup1.ItemLinks.Add(this.fileOpenItem1);
            this.commonRibbonPageGroup1.Name = "commonRibbonPageGroup1";
            // 
            // fileRibbonPage1
            // 
            this.fileRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonRibbonPageGroup1});
            this.fileRibbonPage1.Name = "fileRibbonPage1";
            this.fileRibbonPage1.Visible = false;
            // 
            // textBoxEditorRibbonPageCategory1
            // 
            this.textBoxEditorRibbonPageCategory1.Control = null;
            this.textBoxEditorRibbonPageCategory1.Name = "textBoxEditorRibbonPageCategory1";
            this.textBoxEditorRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.fileRibbonPage1,
            this.homeRibbonPage2,
            this.insertRibbonPage1,
            this.pageLayoutRibbonPage1,
            this.tableDesignRibbonPage1,
            this.tableLayoutRibbonPage1,
            this.floatingPictureToolsFormatPage1});
            // 
            // undoItem1
            // 
            this.undoItem1.Enabled = false;
            this.undoItem1.Id = 272;
            this.undoItem1.Name = "undoItem1";
            // 
            // redoItem1
            // 
            this.redoItem1.Enabled = false;
            this.redoItem1.Id = 273;
            this.redoItem1.Name = "redoItem1";
            // 
            // fileOpenItem1
            // 
            this.fileOpenItem1.Enabled = false;
            this.fileOpenItem1.Id = 274;
            this.fileOpenItem1.Name = "fileOpenItem1";
            // 
            // clipboardRibbonPageGroup1
            // 
            this.clipboardRibbonPageGroup1.ItemLinks.Add(this.pasteItem1);
            this.clipboardRibbonPageGroup1.ItemLinks.Add(this.cutItem1);
            this.clipboardRibbonPageGroup1.ItemLinks.Add(this.copyItem1);
            this.clipboardRibbonPageGroup1.ItemLinks.Add(this.pasteSpecialItem1);
            this.clipboardRibbonPageGroup1.Name = "clipboardRibbonPageGroup1";
            // 
            // homeRibbonPage2
            // 
            this.homeRibbonPage2.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.clipboardRibbonPageGroup1,
            this.fontRibbonPageGroup1,
            this.paragraphRibbonPageGroup1,
            this.stylesRibbonPageGroup1,
            this.editingRibbonPageGroup1});
            this.homeRibbonPage2.Name = "homeRibbonPage2";
            reduceOperation1.Behavior = DevExpress.XtraBars.Ribbon.ReduceOperationBehavior.UntilAvailable;
            reduceOperation1.Group = this.stylesRibbonPageGroup1;
            reduceOperation1.ItemLinkIndex = 0;
            reduceOperation1.ItemLinksCount = 0;
            reduceOperation1.Operation = DevExpress.XtraBars.Ribbon.ReduceOperationType.Gallery;
            this.homeRibbonPage2.ReduceOperations.Add(reduceOperation1);
            this.homeRibbonPage2.Visible = false;
            // 
            // pasteItem1
            // 
            this.pasteItem1.Enabled = false;
            this.pasteItem1.Id = 275;
            this.pasteItem1.Name = "pasteItem1";
            // 
            // cutItem1
            // 
            this.cutItem1.Enabled = false;
            this.cutItem1.Id = 276;
            this.cutItem1.Name = "cutItem1";
            // 
            // copyItem1
            // 
            this.copyItem1.Enabled = false;
            this.copyItem1.Id = 277;
            this.copyItem1.Name = "copyItem1";
            // 
            // pasteSpecialItem1
            // 
            this.pasteSpecialItem1.Enabled = false;
            this.pasteSpecialItem1.Id = 278;
            this.pasteSpecialItem1.Name = "pasteSpecialItem1";
            // 
            // fontRibbonPageGroup1
            // 
            this.fontRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup1);
            this.fontRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup2);
            this.fontRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup3);
            this.fontRibbonPageGroup1.ItemLinks.Add(this.changeTextCaseItem1);
            this.fontRibbonPageGroup1.ItemLinks.Add(this.clearFormattingItem1);
            this.fontRibbonPageGroup1.Name = "fontRibbonPageGroup1";
            // 
            // changeFontNameItem1
            // 
            this.changeFontNameItem1.Edit = this.repositoryItemFontEdit1;
            this.changeFontNameItem1.Enabled = false;
            this.changeFontNameItem1.Id = 279;
            this.changeFontNameItem1.Name = "changeFontNameItem1";
            // 
            // changeFontSizeItem1
            // 
            this.changeFontSizeItem1.Edit = this.repositoryItemRichEditFontSizeEdit1;
            this.changeFontSizeItem1.Enabled = false;
            this.changeFontSizeItem1.Id = 280;
            this.changeFontSizeItem1.Name = "changeFontSizeItem1";
            // 
            // fontSizeIncreaseItem1
            // 
            this.fontSizeIncreaseItem1.Enabled = false;
            this.fontSizeIncreaseItem1.Id = 281;
            this.fontSizeIncreaseItem1.Name = "fontSizeIncreaseItem1";
            // 
            // fontSizeDecreaseItem1
            // 
            this.fontSizeDecreaseItem1.Enabled = false;
            this.fontSizeDecreaseItem1.Id = 282;
            this.fontSizeDecreaseItem1.Name = "fontSizeDecreaseItem1";
            // 
            // toggleFontBoldItem1
            // 
            this.toggleFontBoldItem1.Enabled = false;
            this.toggleFontBoldItem1.Id = 283;
            this.toggleFontBoldItem1.Name = "toggleFontBoldItem1";
            // 
            // toggleFontItalicItem1
            // 
            this.toggleFontItalicItem1.Enabled = false;
            this.toggleFontItalicItem1.Id = 284;
            this.toggleFontItalicItem1.Name = "toggleFontItalicItem1";
            // 
            // toggleFontUnderlineItem1
            // 
            this.toggleFontUnderlineItem1.Enabled = false;
            this.toggleFontUnderlineItem1.Id = 285;
            this.toggleFontUnderlineItem1.Name = "toggleFontUnderlineItem1";
            // 
            // toggleFontDoubleUnderlineItem1
            // 
            this.toggleFontDoubleUnderlineItem1.Enabled = false;
            this.toggleFontDoubleUnderlineItem1.Id = 286;
            this.toggleFontDoubleUnderlineItem1.Name = "toggleFontDoubleUnderlineItem1";
            // 
            // toggleFontStrikeoutItem1
            // 
            this.toggleFontStrikeoutItem1.Enabled = false;
            this.toggleFontStrikeoutItem1.Id = 287;
            this.toggleFontStrikeoutItem1.Name = "toggleFontStrikeoutItem1";
            // 
            // toggleFontDoubleStrikeoutItem1
            // 
            this.toggleFontDoubleStrikeoutItem1.Enabled = false;
            this.toggleFontDoubleStrikeoutItem1.Id = 288;
            this.toggleFontDoubleStrikeoutItem1.Name = "toggleFontDoubleStrikeoutItem1";
            // 
            // toggleFontSuperscriptItem1
            // 
            this.toggleFontSuperscriptItem1.Enabled = false;
            this.toggleFontSuperscriptItem1.Id = 289;
            this.toggleFontSuperscriptItem1.Name = "toggleFontSuperscriptItem1";
            // 
            // toggleFontSubscriptItem1
            // 
            this.toggleFontSubscriptItem1.Enabled = false;
            this.toggleFontSubscriptItem1.Id = 290;
            this.toggleFontSubscriptItem1.Name = "toggleFontSubscriptItem1";
            // 
            // changeFontColorItem1
            // 
            this.changeFontColorItem1.Enabled = false;
            this.changeFontColorItem1.Id = 291;
            this.changeFontColorItem1.Name = "changeFontColorItem1";
            // 
            // changeFontHighlightColorItem1
            // 
            this.changeFontHighlightColorItem1.Enabled = false;
            this.changeFontHighlightColorItem1.Id = 292;
            this.changeFontHighlightColorItem1.Name = "changeFontHighlightColorItem1";
            // 
            // changeTextCaseItem1
            // 
            this.changeTextCaseItem1.Enabled = false;
            this.changeTextCaseItem1.Id = 293;
            this.changeTextCaseItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.makeTextUpperCaseItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.makeTextLowerCaseItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.capitalizeEachWordCaseItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTextCaseItem1)});
            this.changeTextCaseItem1.Name = "changeTextCaseItem1";
            // 
            // makeTextUpperCaseItem1
            // 
            this.makeTextUpperCaseItem1.Enabled = false;
            this.makeTextUpperCaseItem1.Id = 294;
            this.makeTextUpperCaseItem1.Name = "makeTextUpperCaseItem1";
            // 
            // makeTextLowerCaseItem1
            // 
            this.makeTextLowerCaseItem1.Enabled = false;
            this.makeTextLowerCaseItem1.Id = 295;
            this.makeTextLowerCaseItem1.Name = "makeTextLowerCaseItem1";
            // 
            // capitalizeEachWordCaseItem1
            // 
            this.capitalizeEachWordCaseItem1.Enabled = false;
            this.capitalizeEachWordCaseItem1.Id = 296;
            this.capitalizeEachWordCaseItem1.Name = "capitalizeEachWordCaseItem1";
            // 
            // toggleTextCaseItem1
            // 
            this.toggleTextCaseItem1.Enabled = false;
            this.toggleTextCaseItem1.Id = 297;
            this.toggleTextCaseItem1.Name = "toggleTextCaseItem1";
            // 
            // clearFormattingItem1
            // 
            this.clearFormattingItem1.Enabled = false;
            this.clearFormattingItem1.Id = 298;
            this.clearFormattingItem1.Name = "clearFormattingItem1";
            // 
            // barButtonGroup1
            // 
            this.barButtonGroup1.Id = 265;
            this.barButtonGroup1.ItemLinks.Add(this.changeFontNameItem1);
            this.barButtonGroup1.ItemLinks.Add(this.changeFontSizeItem1);
            this.barButtonGroup1.ItemLinks.Add(this.fontSizeIncreaseItem1);
            this.barButtonGroup1.ItemLinks.Add(this.fontSizeDecreaseItem1);
            this.barButtonGroup1.Name = "barButtonGroup1";
            this.barButtonGroup1.Tag = "{97BBE334-159B-44d9-A168-0411957565E8}";
            // 
            // repositoryItemFontEdit1
            // 
            this.repositoryItemFontEdit1.AutoHeight = false;
            this.repositoryItemFontEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemFontEdit1.Name = "repositoryItemFontEdit1";
            // 
            // repositoryItemRichEditFontSizeEdit1
            // 
            this.repositoryItemRichEditFontSizeEdit1.AutoHeight = false;
            this.repositoryItemRichEditFontSizeEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemRichEditFontSizeEdit1.Control = null;
            this.repositoryItemRichEditFontSizeEdit1.Name = "repositoryItemRichEditFontSizeEdit1";
            // 
            // barButtonGroup2
            // 
            this.barButtonGroup2.Id = 266;
            this.barButtonGroup2.ItemLinks.Add(this.toggleFontBoldItem1);
            this.barButtonGroup2.ItemLinks.Add(this.toggleFontItalicItem1);
            this.barButtonGroup2.ItemLinks.Add(this.toggleFontUnderlineItem1);
            this.barButtonGroup2.ItemLinks.Add(this.toggleFontDoubleUnderlineItem1);
            this.barButtonGroup2.ItemLinks.Add(this.toggleFontStrikeoutItem1);
            this.barButtonGroup2.ItemLinks.Add(this.toggleFontDoubleStrikeoutItem1);
            this.barButtonGroup2.ItemLinks.Add(this.toggleFontSuperscriptItem1);
            this.barButtonGroup2.ItemLinks.Add(this.toggleFontSubscriptItem1);
            this.barButtonGroup2.Name = "barButtonGroup2";
            this.barButtonGroup2.Tag = "{433DA7F0-03E2-4650-9DB5-66DD92D16E39}";
            // 
            // barButtonGroup3
            // 
            this.barButtonGroup3.Id = 267;
            this.barButtonGroup3.ItemLinks.Add(this.changeFontColorItem1);
            this.barButtonGroup3.ItemLinks.Add(this.changeFontHighlightColorItem1);
            this.barButtonGroup3.Name = "barButtonGroup3";
            this.barButtonGroup3.Tag = "{DF8C5334-EDE3-47c9-A42C-FE9A9247E180}";
            // 
            // paragraphRibbonPageGroup1
            // 
            this.paragraphRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup4);
            this.paragraphRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup5);
            this.paragraphRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup6);
            this.paragraphRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup7);
            this.paragraphRibbonPageGroup1.Name = "paragraphRibbonPageGroup1";
            // 
            // toggleBulletedListItem1
            // 
            this.toggleBulletedListItem1.Enabled = false;
            this.toggleBulletedListItem1.Id = 299;
            this.toggleBulletedListItem1.Name = "toggleBulletedListItem1";
            // 
            // toggleNumberingListItem1
            // 
            this.toggleNumberingListItem1.Enabled = false;
            this.toggleNumberingListItem1.Id = 300;
            this.toggleNumberingListItem1.Name = "toggleNumberingListItem1";
            // 
            // toggleMultiLevelListItem1
            // 
            this.toggleMultiLevelListItem1.Enabled = false;
            this.toggleMultiLevelListItem1.Id = 301;
            this.toggleMultiLevelListItem1.Name = "toggleMultiLevelListItem1";
            // 
            // decreaseIndentItem1
            // 
            this.decreaseIndentItem1.Enabled = false;
            this.decreaseIndentItem1.Id = 302;
            this.decreaseIndentItem1.Name = "decreaseIndentItem1";
            // 
            // increaseIndentItem1
            // 
            this.increaseIndentItem1.Enabled = false;
            this.increaseIndentItem1.Id = 303;
            this.increaseIndentItem1.Name = "increaseIndentItem1";
            // 
            // toggleParagraphAlignmentLeftItem1
            // 
            this.toggleParagraphAlignmentLeftItem1.Enabled = false;
            this.toggleParagraphAlignmentLeftItem1.Id = 304;
            this.toggleParagraphAlignmentLeftItem1.Name = "toggleParagraphAlignmentLeftItem1";
            // 
            // toggleParagraphAlignmentCenterItem1
            // 
            this.toggleParagraphAlignmentCenterItem1.Enabled = false;
            this.toggleParagraphAlignmentCenterItem1.Id = 305;
            this.toggleParagraphAlignmentCenterItem1.Name = "toggleParagraphAlignmentCenterItem1";
            // 
            // toggleParagraphAlignmentRightItem1
            // 
            this.toggleParagraphAlignmentRightItem1.Enabled = false;
            this.toggleParagraphAlignmentRightItem1.Id = 306;
            this.toggleParagraphAlignmentRightItem1.Name = "toggleParagraphAlignmentRightItem1";
            // 
            // toggleParagraphAlignmentJustifyItem1
            // 
            this.toggleParagraphAlignmentJustifyItem1.Enabled = false;
            this.toggleParagraphAlignmentJustifyItem1.Id = 307;
            this.toggleParagraphAlignmentJustifyItem1.Name = "toggleParagraphAlignmentJustifyItem1";
            // 
            // toggleShowWhitespaceItem1
            // 
            this.toggleShowWhitespaceItem1.Enabled = false;
            this.toggleShowWhitespaceItem1.Id = 308;
            this.toggleShowWhitespaceItem1.Name = "toggleShowWhitespaceItem1";
            // 
            // changeParagraphLineSpacingItem1
            // 
            this.changeParagraphLineSpacingItem1.Enabled = false;
            this.changeParagraphLineSpacingItem1.Id = 309;
            this.changeParagraphLineSpacingItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setSingleParagraphSpacingItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setSesquialteralParagraphSpacingItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setDoubleParagraphSpacingItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.showLineSpacingFormItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.addSpacingBeforeParagraphItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.removeSpacingBeforeParagraphItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.addSpacingAfterParagraphItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.removeSpacingAfterParagraphItem1)});
            this.changeParagraphLineSpacingItem1.Name = "changeParagraphLineSpacingItem1";
            // 
            // setSingleParagraphSpacingItem1
            // 
            this.setSingleParagraphSpacingItem1.Enabled = false;
            this.setSingleParagraphSpacingItem1.Id = 310;
            this.setSingleParagraphSpacingItem1.Name = "setSingleParagraphSpacingItem1";
            // 
            // setSesquialteralParagraphSpacingItem1
            // 
            this.setSesquialteralParagraphSpacingItem1.Enabled = false;
            this.setSesquialteralParagraphSpacingItem1.Id = 311;
            this.setSesquialteralParagraphSpacingItem1.Name = "setSesquialteralParagraphSpacingItem1";
            // 
            // setDoubleParagraphSpacingItem1
            // 
            this.setDoubleParagraphSpacingItem1.Enabled = false;
            this.setDoubleParagraphSpacingItem1.Id = 312;
            this.setDoubleParagraphSpacingItem1.Name = "setDoubleParagraphSpacingItem1";
            // 
            // showLineSpacingFormItem1
            // 
            this.showLineSpacingFormItem1.Enabled = false;
            this.showLineSpacingFormItem1.Id = 313;
            this.showLineSpacingFormItem1.Name = "showLineSpacingFormItem1";
            // 
            // addSpacingBeforeParagraphItem1
            // 
            this.addSpacingBeforeParagraphItem1.Enabled = false;
            this.addSpacingBeforeParagraphItem1.Id = 314;
            this.addSpacingBeforeParagraphItem1.Name = "addSpacingBeforeParagraphItem1";
            // 
            // removeSpacingBeforeParagraphItem1
            // 
            this.removeSpacingBeforeParagraphItem1.Enabled = false;
            this.removeSpacingBeforeParagraphItem1.Id = 315;
            this.removeSpacingBeforeParagraphItem1.Name = "removeSpacingBeforeParagraphItem1";
            // 
            // addSpacingAfterParagraphItem1
            // 
            this.addSpacingAfterParagraphItem1.Enabled = false;
            this.addSpacingAfterParagraphItem1.Id = 316;
            this.addSpacingAfterParagraphItem1.Name = "addSpacingAfterParagraphItem1";
            // 
            // removeSpacingAfterParagraphItem1
            // 
            this.removeSpacingAfterParagraphItem1.Enabled = false;
            this.removeSpacingAfterParagraphItem1.Id = 317;
            this.removeSpacingAfterParagraphItem1.Name = "removeSpacingAfterParagraphItem1";
            // 
            // changeParagraphBackColorItem1
            // 
            this.changeParagraphBackColorItem1.Enabled = false;
            this.changeParagraphBackColorItem1.Id = 318;
            this.changeParagraphBackColorItem1.Name = "changeParagraphBackColorItem1";
            // 
            // barButtonGroup4
            // 
            this.barButtonGroup4.Id = 268;
            this.barButtonGroup4.ItemLinks.Add(this.toggleBulletedListItem1);
            this.barButtonGroup4.ItemLinks.Add(this.toggleNumberingListItem1);
            this.barButtonGroup4.ItemLinks.Add(this.toggleMultiLevelListItem1);
            this.barButtonGroup4.Name = "barButtonGroup4";
            this.barButtonGroup4.Tag = "{0B3A7A43-3079-4ce0-83A8-3789F5F6DC9F}";
            // 
            // barButtonGroup5
            // 
            this.barButtonGroup5.Id = 269;
            this.barButtonGroup5.ItemLinks.Add(this.decreaseIndentItem1);
            this.barButtonGroup5.ItemLinks.Add(this.increaseIndentItem1);
            this.barButtonGroup5.ItemLinks.Add(this.toggleShowWhitespaceItem1);
            this.barButtonGroup5.Name = "barButtonGroup5";
            this.barButtonGroup5.Tag = "{4747D5AB-2BEB-4ea6-9A1D-8E4FB36F1B40}";
            // 
            // barButtonGroup6
            // 
            this.barButtonGroup6.Id = 270;
            this.barButtonGroup6.ItemLinks.Add(this.toggleParagraphAlignmentLeftItem1);
            this.barButtonGroup6.ItemLinks.Add(this.toggleParagraphAlignmentCenterItem1);
            this.barButtonGroup6.ItemLinks.Add(this.toggleParagraphAlignmentRightItem1);
            this.barButtonGroup6.ItemLinks.Add(this.toggleParagraphAlignmentJustifyItem1);
            this.barButtonGroup6.Name = "barButtonGroup6";
            this.barButtonGroup6.Tag = "{8E89E775-996E-49a0-AADA-DE338E34732E}";
            // 
            // barButtonGroup7
            // 
            this.barButtonGroup7.Id = 271;
            this.barButtonGroup7.ItemLinks.Add(this.changeParagraphLineSpacingItem1);
            this.barButtonGroup7.ItemLinks.Add(this.changeParagraphBackColorItem1);
            this.barButtonGroup7.Name = "barButtonGroup7";
            this.barButtonGroup7.Tag = "{9A8DEAD8-3890-4857-A395-EC625FD02217}";
            // 
            // stylesRibbonPageGroup1
            // 
            this.stylesRibbonPageGroup1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("stylesRibbonPageGroup1.ImageOptions.Image")));
            this.stylesRibbonPageGroup1.ItemLinks.Add(this.galleryChangeStyleItem1);
            this.stylesRibbonPageGroup1.Name = "stylesRibbonPageGroup1";
            // 
            // galleryChangeStyleItem1
            // 
            this.galleryChangeStyleItem1.Enabled = false;
            // 
            // 
            // 
            this.galleryChangeStyleItem1.Gallery.ColumnCount = 10;
            this.galleryChangeStyleItem1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup5});
            this.galleryChangeStyleItem1.Gallery.ImageSize = new System.Drawing.Size(65, 46);
            this.galleryChangeStyleItem1.Id = 319;
            this.galleryChangeStyleItem1.Name = "galleryChangeStyleItem1";
            // 
            // editingRibbonPageGroup1
            // 
            this.editingRibbonPageGroup1.ItemLinks.Add(this.findItem1);
            this.editingRibbonPageGroup1.ItemLinks.Add(this.replaceItem1);
            this.editingRibbonPageGroup1.Name = "editingRibbonPageGroup1";
            // 
            // findItem1
            // 
            this.findItem1.Enabled = false;
            this.findItem1.Id = 320;
            this.findItem1.Name = "findItem1";
            // 
            // replaceItem1
            // 
            this.replaceItem1.Enabled = false;
            this.replaceItem1.Id = 321;
            this.replaceItem1.Name = "replaceItem1";
            // 
            // tablesRibbonPageGroup1
            // 
            this.tablesRibbonPageGroup1.AllowTextClipping = false;
            this.tablesRibbonPageGroup1.ItemLinks.Add(this.insertTableItem1);
            this.tablesRibbonPageGroup1.Name = "tablesRibbonPageGroup1";
            // 
            // insertRibbonPage1
            // 
            this.insertRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.tablesRibbonPageGroup1,
            this.illustrationsRibbonPageGroup1,
            this.linksRibbonPageGroup1,
            this.symbolsRibbonPageGroup1});
            this.insertRibbonPage1.Name = "insertRibbonPage1";
            this.insertRibbonPage1.Visible = false;
            // 
            // insertTableItem1
            // 
            this.insertTableItem1.Enabled = false;
            this.insertTableItem1.Id = 322;
            this.insertTableItem1.Name = "insertTableItem1";
            // 
            // illustrationsRibbonPageGroup1
            // 
            this.illustrationsRibbonPageGroup1.ItemLinks.Add(this.insertPictureItem1);
            this.illustrationsRibbonPageGroup1.ItemLinks.Add(this.insertFloatingPictureItem1);
            this.illustrationsRibbonPageGroup1.Name = "illustrationsRibbonPageGroup1";
            // 
            // insertPictureItem1
            // 
            this.insertPictureItem1.Enabled = false;
            this.insertPictureItem1.Id = 323;
            this.insertPictureItem1.Name = "insertPictureItem1";
            // 
            // insertFloatingPictureItem1
            // 
            this.insertFloatingPictureItem1.Enabled = false;
            this.insertFloatingPictureItem1.Id = 324;
            this.insertFloatingPictureItem1.Name = "insertFloatingPictureItem1";
            // 
            // linksRibbonPageGroup1
            // 
            this.linksRibbonPageGroup1.ItemLinks.Add(this.insertBookmarkItem1);
            this.linksRibbonPageGroup1.ItemLinks.Add(this.insertHyperlinkItem1);
            this.linksRibbonPageGroup1.Name = "linksRibbonPageGroup1";
            // 
            // insertBookmarkItem1
            // 
            this.insertBookmarkItem1.Enabled = false;
            this.insertBookmarkItem1.Id = 325;
            this.insertBookmarkItem1.Name = "insertBookmarkItem1";
            // 
            // insertHyperlinkItem1
            // 
            this.insertHyperlinkItem1.Enabled = false;
            this.insertHyperlinkItem1.Id = 326;
            this.insertHyperlinkItem1.Name = "insertHyperlinkItem1";
            // 
            // symbolsRibbonPageGroup1
            // 
            this.symbolsRibbonPageGroup1.AllowTextClipping = false;
            this.symbolsRibbonPageGroup1.ItemLinks.Add(this.insertSymbolItem1);
            this.symbolsRibbonPageGroup1.Name = "symbolsRibbonPageGroup1";
            // 
            // insertSymbolItem1
            // 
            this.insertSymbolItem1.Enabled = false;
            this.insertSymbolItem1.Id = 327;
            this.insertSymbolItem1.Name = "insertSymbolItem1";
            // 
            // pageBackgroundRibbonPageGroup1
            // 
            this.pageBackgroundRibbonPageGroup1.AllowTextClipping = false;
            this.pageBackgroundRibbonPageGroup1.ItemLinks.Add(this.changePageColorItem1);
            this.pageBackgroundRibbonPageGroup1.Name = "pageBackgroundRibbonPageGroup1";
            // 
            // pageLayoutRibbonPage1
            // 
            this.pageLayoutRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.pageBackgroundRibbonPageGroup1});
            this.pageLayoutRibbonPage1.Name = "pageLayoutRibbonPage1";
            this.pageLayoutRibbonPage1.Visible = false;
            // 
            // changePageColorItem1
            // 
            this.changePageColorItem1.Enabled = false;
            this.changePageColorItem1.Id = 328;
            this.changePageColorItem1.Name = "changePageColorItem1";
            // 
            // tableStyleOptionsRibbonPageGroup1
            // 
            this.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.toggleFirstRowItem1);
            this.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.toggleLastRowItem1);
            this.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.toggleBandedRowsItem1);
            this.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.toggleFirstColumnItem1);
            this.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.toggleLastColumnItem1);
            this.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.toggleBandedColumnsItem1);
            this.tableStyleOptionsRibbonPageGroup1.Name = "tableStyleOptionsRibbonPageGroup1";
            // 
            // tableDesignRibbonPage1
            // 
            this.tableDesignRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.tableStyleOptionsRibbonPageGroup1,
            this.tableStylesRibbonPageGroup1,
            this.tableDrawBordersRibbonPageGroup1});
            this.tableDesignRibbonPage1.Name = "tableDesignRibbonPage1";
            this.tableDesignRibbonPage1.Visible = false;
            // 
            // toggleFirstRowItem1
            // 
            this.toggleFirstRowItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.toggleFirstRowItem1.Enabled = false;
            this.toggleFirstRowItem1.Id = 329;
            this.toggleFirstRowItem1.Name = "toggleFirstRowItem1";
            // 
            // toggleLastRowItem1
            // 
            this.toggleLastRowItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.toggleLastRowItem1.Enabled = false;
            this.toggleLastRowItem1.Id = 330;
            this.toggleLastRowItem1.Name = "toggleLastRowItem1";
            // 
            // toggleBandedRowsItem1
            // 
            this.toggleBandedRowsItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.toggleBandedRowsItem1.Enabled = false;
            this.toggleBandedRowsItem1.Id = 331;
            this.toggleBandedRowsItem1.Name = "toggleBandedRowsItem1";
            // 
            // toggleFirstColumnItem1
            // 
            this.toggleFirstColumnItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.toggleFirstColumnItem1.Enabled = false;
            this.toggleFirstColumnItem1.Id = 332;
            this.toggleFirstColumnItem1.Name = "toggleFirstColumnItem1";
            // 
            // toggleLastColumnItem1
            // 
            this.toggleLastColumnItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.toggleLastColumnItem1.Enabled = false;
            this.toggleLastColumnItem1.Id = 333;
            this.toggleLastColumnItem1.Name = "toggleLastColumnItem1";
            // 
            // toggleBandedColumnsItem1
            // 
            this.toggleBandedColumnsItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.toggleBandedColumnsItem1.Enabled = false;
            this.toggleBandedColumnsItem1.Id = 334;
            this.toggleBandedColumnsItem1.Name = "toggleBandedColumnsItem1";
            // 
            // tableStylesRibbonPageGroup1
            // 
            this.tableStylesRibbonPageGroup1.ItemLinks.Add(this.galleryChangeTableStyleItem1);
            this.tableStylesRibbonPageGroup1.Name = "tableStylesRibbonPageGroup1";
            // 
            // galleryChangeTableStyleItem1
            // 
            this.galleryChangeTableStyleItem1.CurrentItem = null;
            this.galleryChangeTableStyleItem1.DeleteItemLink = null;
            this.galleryChangeTableStyleItem1.Enabled = false;
            // 
            // 
            // 
            this.galleryChangeTableStyleItem1.Gallery.ColumnCount = 3;
            this.galleryChangeTableStyleItem1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup6});
            this.galleryChangeTableStyleItem1.Gallery.ImageSize = new System.Drawing.Size(65, 46);
            this.galleryChangeTableStyleItem1.Id = 335;
            this.galleryChangeTableStyleItem1.ModifyItemLink = null;
            this.galleryChangeTableStyleItem1.Name = "galleryChangeTableStyleItem1";
            this.galleryChangeTableStyleItem1.NewItemLink = null;
            this.galleryChangeTableStyleItem1.PopupGallery = null;
            // 
            // tableDrawBordersRibbonPageGroup1
            // 
            this.tableDrawBordersRibbonPageGroup1.ItemLinks.Add(this.changeTableBorderLineStyleItem1);
            this.tableDrawBordersRibbonPageGroup1.ItemLinks.Add(this.changeTableBorderLineWeightItem1);
            this.tableDrawBordersRibbonPageGroup1.ItemLinks.Add(this.changeTableBorderColorItem1);
            this.tableDrawBordersRibbonPageGroup1.ItemLinks.Add(this.changeTableBordersItem1);
            this.tableDrawBordersRibbonPageGroup1.ItemLinks.Add(this.changeTableCellsShadingItem1);
            this.tableDrawBordersRibbonPageGroup1.Name = "tableDrawBordersRibbonPageGroup1";
            // 
            // changeTableBorderLineStyleItem1
            // 
            this.changeTableBorderLineStyleItem1.Edit = this.repositoryItemBorderLineStyle1;
            this.changeTableBorderLineStyleItem1.EditWidth = 130;
            this.changeTableBorderLineStyleItem1.Enabled = false;
            this.changeTableBorderLineStyleItem1.Id = 336;
            this.changeTableBorderLineStyleItem1.Name = "changeTableBorderLineStyleItem1";
            // 
            // changeTableBorderLineWeightItem1
            // 
            this.changeTableBorderLineWeightItem1.Edit = this.repositoryItemBorderLineWeight1;
            this.changeTableBorderLineWeightItem1.EditWidth = 130;
            this.changeTableBorderLineWeightItem1.Enabled = false;
            this.changeTableBorderLineWeightItem1.Id = 337;
            this.changeTableBorderLineWeightItem1.Name = "changeTableBorderLineWeightItem1";
            // 
            // changeTableBorderColorItem1
            // 
            this.changeTableBorderColorItem1.Enabled = false;
            this.changeTableBorderColorItem1.Id = 338;
            this.changeTableBorderColorItem1.Name = "changeTableBorderColorItem1";
            // 
            // changeTableBordersItem1
            // 
            this.changeTableBordersItem1.Enabled = false;
            this.changeTableBordersItem1.Id = 339;
            this.changeTableBordersItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsBottomBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsTopBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsLeftBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsRightBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.resetTableCellsAllBordersItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsAllBordersItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsOutsideBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsInsideBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsInsideHorizontalBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsInsideVerticalBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleShowTableGridLinesItem1)});
            this.changeTableBordersItem1.Name = "changeTableBordersItem1";
            // 
            // toggleTableCellsBottomBorderItem1
            // 
            this.toggleTableCellsBottomBorderItem1.Enabled = false;
            this.toggleTableCellsBottomBorderItem1.Id = 340;
            this.toggleTableCellsBottomBorderItem1.Name = "toggleTableCellsBottomBorderItem1";
            // 
            // toggleTableCellsTopBorderItem1
            // 
            this.toggleTableCellsTopBorderItem1.Enabled = false;
            this.toggleTableCellsTopBorderItem1.Id = 341;
            this.toggleTableCellsTopBorderItem1.Name = "toggleTableCellsTopBorderItem1";
            // 
            // toggleTableCellsLeftBorderItem1
            // 
            this.toggleTableCellsLeftBorderItem1.Enabled = false;
            this.toggleTableCellsLeftBorderItem1.Id = 342;
            this.toggleTableCellsLeftBorderItem1.Name = "toggleTableCellsLeftBorderItem1";
            // 
            // toggleTableCellsRightBorderItem1
            // 
            this.toggleTableCellsRightBorderItem1.Enabled = false;
            this.toggleTableCellsRightBorderItem1.Id = 343;
            this.toggleTableCellsRightBorderItem1.Name = "toggleTableCellsRightBorderItem1";
            // 
            // resetTableCellsAllBordersItem1
            // 
            this.resetTableCellsAllBordersItem1.Enabled = false;
            this.resetTableCellsAllBordersItem1.Id = 344;
            this.resetTableCellsAllBordersItem1.Name = "resetTableCellsAllBordersItem1";
            // 
            // toggleTableCellsAllBordersItem1
            // 
            this.toggleTableCellsAllBordersItem1.Enabled = false;
            this.toggleTableCellsAllBordersItem1.Id = 345;
            this.toggleTableCellsAllBordersItem1.Name = "toggleTableCellsAllBordersItem1";
            // 
            // toggleTableCellsOutsideBorderItem1
            // 
            this.toggleTableCellsOutsideBorderItem1.Enabled = false;
            this.toggleTableCellsOutsideBorderItem1.Id = 346;
            this.toggleTableCellsOutsideBorderItem1.Name = "toggleTableCellsOutsideBorderItem1";
            // 
            // toggleTableCellsInsideBorderItem1
            // 
            this.toggleTableCellsInsideBorderItem1.Enabled = false;
            this.toggleTableCellsInsideBorderItem1.Id = 347;
            this.toggleTableCellsInsideBorderItem1.Name = "toggleTableCellsInsideBorderItem1";
            // 
            // toggleTableCellsInsideHorizontalBorderItem1
            // 
            this.toggleTableCellsInsideHorizontalBorderItem1.Enabled = false;
            this.toggleTableCellsInsideHorizontalBorderItem1.Id = 348;
            this.toggleTableCellsInsideHorizontalBorderItem1.Name = "toggleTableCellsInsideHorizontalBorderItem1";
            // 
            // toggleTableCellsInsideVerticalBorderItem1
            // 
            this.toggleTableCellsInsideVerticalBorderItem1.Enabled = false;
            this.toggleTableCellsInsideVerticalBorderItem1.Id = 349;
            this.toggleTableCellsInsideVerticalBorderItem1.Name = "toggleTableCellsInsideVerticalBorderItem1";
            // 
            // toggleShowTableGridLinesItem1
            // 
            this.toggleShowTableGridLinesItem1.Enabled = false;
            this.toggleShowTableGridLinesItem1.Id = 350;
            this.toggleShowTableGridLinesItem1.Name = "toggleShowTableGridLinesItem1";
            // 
            // changeTableCellsShadingItem1
            // 
            this.changeTableCellsShadingItem1.Enabled = false;
            this.changeTableCellsShadingItem1.Id = 351;
            this.changeTableCellsShadingItem1.Name = "changeTableCellsShadingItem1";
            // 
            // repositoryItemBorderLineStyle1
            // 
            this.repositoryItemBorderLineStyle1.AutoHeight = false;
            this.repositoryItemBorderLineStyle1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemBorderLineStyle1.Control = null;
            this.repositoryItemBorderLineStyle1.Name = "repositoryItemBorderLineStyle1";
            // 
            // repositoryItemBorderLineWeight1
            // 
            this.repositoryItemBorderLineWeight1.AutoHeight = false;
            this.repositoryItemBorderLineWeight1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemBorderLineWeight1.Control = null;
            this.repositoryItemBorderLineWeight1.Name = "repositoryItemBorderLineWeight1";
            // 
            // tableTableRibbonPageGroup1
            // 
            this.tableTableRibbonPageGroup1.ItemLinks.Add(this.selectTableElementsItem1);
            this.tableTableRibbonPageGroup1.ItemLinks.Add(this.toggleShowTableGridLinesItem1);
            this.tableTableRibbonPageGroup1.ItemLinks.Add(this.showTablePropertiesFormItem1);
            this.tableTableRibbonPageGroup1.Name = "tableTableRibbonPageGroup1";
            // 
            // tableLayoutRibbonPage1
            // 
            this.tableLayoutRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.tableTableRibbonPageGroup1,
            this.tableRowsAndColumnsRibbonPageGroup1,
            this.tableMergeRibbonPageGroup1,
            this.tableCellSizeRibbonPageGroup1,
            this.tableAlignmentRibbonPageGroup1});
            this.tableLayoutRibbonPage1.Name = "tableLayoutRibbonPage1";
            this.tableLayoutRibbonPage1.Visible = false;
            // 
            // selectTableElementsItem1
            // 
            this.selectTableElementsItem1.Enabled = false;
            this.selectTableElementsItem1.Id = 352;
            this.selectTableElementsItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.selectTableCellItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.selectTableColumnItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.selectTableRowItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.selectTableItem1)});
            this.selectTableElementsItem1.Name = "selectTableElementsItem1";
            // 
            // selectTableCellItem1
            // 
            this.selectTableCellItem1.Enabled = false;
            this.selectTableCellItem1.Id = 353;
            this.selectTableCellItem1.Name = "selectTableCellItem1";
            // 
            // selectTableColumnItem1
            // 
            this.selectTableColumnItem1.Enabled = false;
            this.selectTableColumnItem1.Id = 354;
            this.selectTableColumnItem1.Name = "selectTableColumnItem1";
            // 
            // selectTableRowItem1
            // 
            this.selectTableRowItem1.Enabled = false;
            this.selectTableRowItem1.Id = 355;
            this.selectTableRowItem1.Name = "selectTableRowItem1";
            // 
            // selectTableItem1
            // 
            this.selectTableItem1.Enabled = false;
            this.selectTableItem1.Id = 356;
            this.selectTableItem1.Name = "selectTableItem1";
            // 
            // showTablePropertiesFormItem1
            // 
            this.showTablePropertiesFormItem1.Enabled = false;
            this.showTablePropertiesFormItem1.Id = 357;
            this.showTablePropertiesFormItem1.Name = "showTablePropertiesFormItem1";
            // 
            // tableRowsAndColumnsRibbonPageGroup1
            // 
            this.tableRowsAndColumnsRibbonPageGroup1.ItemLinks.Add(this.deleteTableElementsItem1);
            this.tableRowsAndColumnsRibbonPageGroup1.ItemLinks.Add(this.insertTableRowAboveItem1);
            this.tableRowsAndColumnsRibbonPageGroup1.ItemLinks.Add(this.insertTableRowBelowItem1);
            this.tableRowsAndColumnsRibbonPageGroup1.ItemLinks.Add(this.insertTableColumnToLeftItem1);
            this.tableRowsAndColumnsRibbonPageGroup1.ItemLinks.Add(this.insertTableColumnToRightItem1);
            this.tableRowsAndColumnsRibbonPageGroup1.Name = "tableRowsAndColumnsRibbonPageGroup1";
            // 
            // deleteTableElementsItem1
            // 
            this.deleteTableElementsItem1.Enabled = false;
            this.deleteTableElementsItem1.Id = 358;
            this.deleteTableElementsItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.showDeleteTableCellsFormItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.deleteTableColumnsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.deleteTableRowsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.deleteTableItem1)});
            this.deleteTableElementsItem1.Name = "deleteTableElementsItem1";
            // 
            // showDeleteTableCellsFormItem1
            // 
            this.showDeleteTableCellsFormItem1.Enabled = false;
            this.showDeleteTableCellsFormItem1.Id = 359;
            this.showDeleteTableCellsFormItem1.Name = "showDeleteTableCellsFormItem1";
            // 
            // deleteTableColumnsItem1
            // 
            this.deleteTableColumnsItem1.Enabled = false;
            this.deleteTableColumnsItem1.Id = 360;
            this.deleteTableColumnsItem1.Name = "deleteTableColumnsItem1";
            // 
            // deleteTableRowsItem1
            // 
            this.deleteTableRowsItem1.Enabled = false;
            this.deleteTableRowsItem1.Id = 361;
            this.deleteTableRowsItem1.Name = "deleteTableRowsItem1";
            // 
            // deleteTableItem1
            // 
            this.deleteTableItem1.Enabled = false;
            this.deleteTableItem1.Id = 362;
            this.deleteTableItem1.Name = "deleteTableItem1";
            // 
            // insertTableRowAboveItem1
            // 
            this.insertTableRowAboveItem1.Enabled = false;
            this.insertTableRowAboveItem1.Id = 363;
            this.insertTableRowAboveItem1.Name = "insertTableRowAboveItem1";
            // 
            // insertTableRowBelowItem1
            // 
            this.insertTableRowBelowItem1.Enabled = false;
            this.insertTableRowBelowItem1.Id = 364;
            this.insertTableRowBelowItem1.Name = "insertTableRowBelowItem1";
            // 
            // insertTableColumnToLeftItem1
            // 
            this.insertTableColumnToLeftItem1.Enabled = false;
            this.insertTableColumnToLeftItem1.Id = 365;
            this.insertTableColumnToLeftItem1.Name = "insertTableColumnToLeftItem1";
            // 
            // insertTableColumnToRightItem1
            // 
            this.insertTableColumnToRightItem1.Enabled = false;
            this.insertTableColumnToRightItem1.Id = 366;
            this.insertTableColumnToRightItem1.Name = "insertTableColumnToRightItem1";
            // 
            // tableMergeRibbonPageGroup1
            // 
            this.tableMergeRibbonPageGroup1.ItemLinks.Add(this.mergeTableCellsItem1);
            this.tableMergeRibbonPageGroup1.ItemLinks.Add(this.showSplitTableCellsForm1);
            this.tableMergeRibbonPageGroup1.ItemLinks.Add(this.splitTableItem1);
            this.tableMergeRibbonPageGroup1.Name = "tableMergeRibbonPageGroup1";
            // 
            // mergeTableCellsItem1
            // 
            this.mergeTableCellsItem1.Enabled = false;
            this.mergeTableCellsItem1.Id = 367;
            this.mergeTableCellsItem1.Name = "mergeTableCellsItem1";
            // 
            // showSplitTableCellsForm1
            // 
            this.showSplitTableCellsForm1.Enabled = false;
            this.showSplitTableCellsForm1.Id = 368;
            this.showSplitTableCellsForm1.Name = "showSplitTableCellsForm1";
            // 
            // splitTableItem1
            // 
            this.splitTableItem1.Enabled = false;
            this.splitTableItem1.Id = 369;
            this.splitTableItem1.Name = "splitTableItem1";
            // 
            // tableCellSizeRibbonPageGroup1
            // 
            this.tableCellSizeRibbonPageGroup1.AllowTextClipping = false;
            this.tableCellSizeRibbonPageGroup1.ItemLinks.Add(this.toggleTableAutoFitItem1);
            this.tableCellSizeRibbonPageGroup1.Name = "tableCellSizeRibbonPageGroup1";
            // 
            // toggleTableAutoFitItem1
            // 
            this.toggleTableAutoFitItem1.Enabled = false;
            this.toggleTableAutoFitItem1.Id = 370;
            this.toggleTableAutoFitItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableAutoFitContentsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableAutoFitWindowItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableFixedColumnWidthItem1)});
            this.toggleTableAutoFitItem1.Name = "toggleTableAutoFitItem1";
            // 
            // toggleTableAutoFitContentsItem1
            // 
            this.toggleTableAutoFitContentsItem1.Enabled = false;
            this.toggleTableAutoFitContentsItem1.Id = 371;
            this.toggleTableAutoFitContentsItem1.Name = "toggleTableAutoFitContentsItem1";
            // 
            // toggleTableAutoFitWindowItem1
            // 
            this.toggleTableAutoFitWindowItem1.Enabled = false;
            this.toggleTableAutoFitWindowItem1.Id = 372;
            this.toggleTableAutoFitWindowItem1.Name = "toggleTableAutoFitWindowItem1";
            // 
            // toggleTableFixedColumnWidthItem1
            // 
            this.toggleTableFixedColumnWidthItem1.Enabled = false;
            this.toggleTableFixedColumnWidthItem1.Id = 373;
            this.toggleTableFixedColumnWidthItem1.Name = "toggleTableFixedColumnWidthItem1";
            // 
            // tableAlignmentRibbonPageGroup1
            // 
            this.tableAlignmentRibbonPageGroup1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("tableAlignmentRibbonPageGroup1.ImageOptions.Image")));
            this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsTopLeftAlignmentItem1);
            this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsMiddleLeftAlignmentItem1);
            this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsBottomLeftAlignmentItem1);
            this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsTopCenterAlignmentItem1);
            this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsMiddleCenterAlignmentItem1);
            this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsBottomCenterAlignmentItem1);
            this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsTopRightAlignmentItem1);
            this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsMiddleRightAlignmentItem1);
            this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsBottomRightAlignmentItem1);
            this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.showTableOptionsFormItem1);
            this.tableAlignmentRibbonPageGroup1.Name = "tableAlignmentRibbonPageGroup1";
            // 
            // toggleTableCellsTopLeftAlignmentItem1
            // 
            this.toggleTableCellsTopLeftAlignmentItem1.Enabled = false;
            this.toggleTableCellsTopLeftAlignmentItem1.Id = 374;
            this.toggleTableCellsTopLeftAlignmentItem1.Name = "toggleTableCellsTopLeftAlignmentItem1";
            // 
            // toggleTableCellsMiddleLeftAlignmentItem1
            // 
            this.toggleTableCellsMiddleLeftAlignmentItem1.Enabled = false;
            this.toggleTableCellsMiddleLeftAlignmentItem1.Id = 375;
            this.toggleTableCellsMiddleLeftAlignmentItem1.Name = "toggleTableCellsMiddleLeftAlignmentItem1";
            // 
            // toggleTableCellsBottomLeftAlignmentItem1
            // 
            this.toggleTableCellsBottomLeftAlignmentItem1.Enabled = false;
            this.toggleTableCellsBottomLeftAlignmentItem1.Id = 376;
            this.toggleTableCellsBottomLeftAlignmentItem1.Name = "toggleTableCellsBottomLeftAlignmentItem1";
            // 
            // toggleTableCellsTopCenterAlignmentItem1
            // 
            this.toggleTableCellsTopCenterAlignmentItem1.Enabled = false;
            this.toggleTableCellsTopCenterAlignmentItem1.Id = 377;
            this.toggleTableCellsTopCenterAlignmentItem1.Name = "toggleTableCellsTopCenterAlignmentItem1";
            // 
            // toggleTableCellsMiddleCenterAlignmentItem1
            // 
            this.toggleTableCellsMiddleCenterAlignmentItem1.Enabled = false;
            this.toggleTableCellsMiddleCenterAlignmentItem1.Id = 378;
            this.toggleTableCellsMiddleCenterAlignmentItem1.Name = "toggleTableCellsMiddleCenterAlignmentItem1";
            // 
            // toggleTableCellsBottomCenterAlignmentItem1
            // 
            this.toggleTableCellsBottomCenterAlignmentItem1.Enabled = false;
            this.toggleTableCellsBottomCenterAlignmentItem1.Id = 379;
            this.toggleTableCellsBottomCenterAlignmentItem1.Name = "toggleTableCellsBottomCenterAlignmentItem1";
            // 
            // toggleTableCellsTopRightAlignmentItem1
            // 
            this.toggleTableCellsTopRightAlignmentItem1.Enabled = false;
            this.toggleTableCellsTopRightAlignmentItem1.Id = 380;
            this.toggleTableCellsTopRightAlignmentItem1.Name = "toggleTableCellsTopRightAlignmentItem1";
            // 
            // toggleTableCellsMiddleRightAlignmentItem1
            // 
            this.toggleTableCellsMiddleRightAlignmentItem1.Enabled = false;
            this.toggleTableCellsMiddleRightAlignmentItem1.Id = 381;
            this.toggleTableCellsMiddleRightAlignmentItem1.Name = "toggleTableCellsMiddleRightAlignmentItem1";
            // 
            // toggleTableCellsBottomRightAlignmentItem1
            // 
            this.toggleTableCellsBottomRightAlignmentItem1.Enabled = false;
            this.toggleTableCellsBottomRightAlignmentItem1.Id = 382;
            this.toggleTableCellsBottomRightAlignmentItem1.Name = "toggleTableCellsBottomRightAlignmentItem1";
            // 
            // showTableOptionsFormItem1
            // 
            this.showTableOptionsFormItem1.Enabled = false;
            this.showTableOptionsFormItem1.Id = 383;
            this.showTableOptionsFormItem1.Name = "showTableOptionsFormItem1";
            // 
            // floatingPictureToolsShapeStylesPageGroup1
            // 
            this.floatingPictureToolsShapeStylesPageGroup1.ItemLinks.Add(this.changeFloatingObjectFillColorItem1);
            this.floatingPictureToolsShapeStylesPageGroup1.ItemLinks.Add(this.changeFloatingObjectOutlineColorItem1);
            this.floatingPictureToolsShapeStylesPageGroup1.ItemLinks.Add(this.changeFloatingObjectOutlineWeightItem1);
            this.floatingPictureToolsShapeStylesPageGroup1.Name = "floatingPictureToolsShapeStylesPageGroup1";
            // 
            // floatingPictureToolsFormatPage1
            // 
            this.floatingPictureToolsFormatPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.floatingPictureToolsShapeStylesPageGroup1,
            this.floatingPictureToolsArrangePageGroup1});
            this.floatingPictureToolsFormatPage1.Name = "floatingPictureToolsFormatPage1";
            this.floatingPictureToolsFormatPage1.Visible = false;
            // 
            // changeFloatingObjectFillColorItem1
            // 
            this.changeFloatingObjectFillColorItem1.Enabled = false;
            this.changeFloatingObjectFillColorItem1.Id = 384;
            this.changeFloatingObjectFillColorItem1.Name = "changeFloatingObjectFillColorItem1";
            // 
            // changeFloatingObjectOutlineColorItem1
            // 
            this.changeFloatingObjectOutlineColorItem1.Enabled = false;
            this.changeFloatingObjectOutlineColorItem1.Id = 385;
            this.changeFloatingObjectOutlineColorItem1.Name = "changeFloatingObjectOutlineColorItem1";
            // 
            // changeFloatingObjectOutlineWeightItem1
            // 
            this.changeFloatingObjectOutlineWeightItem1.Edit = this.repositoryItemFloatingObjectOutlineWeight1;
            this.changeFloatingObjectOutlineWeightItem1.Enabled = false;
            this.changeFloatingObjectOutlineWeightItem1.Id = 386;
            this.changeFloatingObjectOutlineWeightItem1.Name = "changeFloatingObjectOutlineWeightItem1";
            // 
            // repositoryItemFloatingObjectOutlineWeight1
            // 
            this.repositoryItemFloatingObjectOutlineWeight1.AutoHeight = false;
            this.repositoryItemFloatingObjectOutlineWeight1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemFloatingObjectOutlineWeight1.Control = null;
            this.repositoryItemFloatingObjectOutlineWeight1.Name = "repositoryItemFloatingObjectOutlineWeight1";
            // 
            // floatingPictureToolsArrangePageGroup1
            // 
            this.floatingPictureToolsArrangePageGroup1.ItemLinks.Add(this.changeFloatingObjectTextWrapTypeItem1);
            this.floatingPictureToolsArrangePageGroup1.ItemLinks.Add(this.changeFloatingObjectAlignmentItem1);
            this.floatingPictureToolsArrangePageGroup1.ItemLinks.Add(this.floatingObjectBringForwardSubItem1);
            this.floatingPictureToolsArrangePageGroup1.ItemLinks.Add(this.floatingObjectSendBackwardSubItem1);
            this.floatingPictureToolsArrangePageGroup1.Name = "floatingPictureToolsArrangePageGroup1";
            // 
            // changeFloatingObjectTextWrapTypeItem1
            // 
            this.changeFloatingObjectTextWrapTypeItem1.Enabled = false;
            this.changeFloatingObjectTextWrapTypeItem1.Id = 387;
            this.changeFloatingObjectTextWrapTypeItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectSquareTextWrapTypeItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectTightTextWrapTypeItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectThroughTextWrapTypeItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectTopAndBottomTextWrapTypeItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectBehindTextWrapTypeItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectInFrontOfTextWrapTypeItem1)});
            this.changeFloatingObjectTextWrapTypeItem1.Name = "changeFloatingObjectTextWrapTypeItem1";
            // 
            // setFloatingObjectSquareTextWrapTypeItem1
            // 
            this.setFloatingObjectSquareTextWrapTypeItem1.Enabled = false;
            this.setFloatingObjectSquareTextWrapTypeItem1.Id = 388;
            this.setFloatingObjectSquareTextWrapTypeItem1.Name = "setFloatingObjectSquareTextWrapTypeItem1";
            // 
            // setFloatingObjectTightTextWrapTypeItem1
            // 
            this.setFloatingObjectTightTextWrapTypeItem1.Enabled = false;
            this.setFloatingObjectTightTextWrapTypeItem1.Id = 389;
            this.setFloatingObjectTightTextWrapTypeItem1.Name = "setFloatingObjectTightTextWrapTypeItem1";
            // 
            // setFloatingObjectThroughTextWrapTypeItem1
            // 
            this.setFloatingObjectThroughTextWrapTypeItem1.Enabled = false;
            this.setFloatingObjectThroughTextWrapTypeItem1.Id = 390;
            this.setFloatingObjectThroughTextWrapTypeItem1.Name = "setFloatingObjectThroughTextWrapTypeItem1";
            // 
            // setFloatingObjectTopAndBottomTextWrapTypeItem1
            // 
            this.setFloatingObjectTopAndBottomTextWrapTypeItem1.Enabled = false;
            this.setFloatingObjectTopAndBottomTextWrapTypeItem1.Id = 391;
            this.setFloatingObjectTopAndBottomTextWrapTypeItem1.Name = "setFloatingObjectTopAndBottomTextWrapTypeItem1";
            // 
            // setFloatingObjectBehindTextWrapTypeItem1
            // 
            this.setFloatingObjectBehindTextWrapTypeItem1.Enabled = false;
            this.setFloatingObjectBehindTextWrapTypeItem1.Id = 392;
            this.setFloatingObjectBehindTextWrapTypeItem1.Name = "setFloatingObjectBehindTextWrapTypeItem1";
            // 
            // setFloatingObjectInFrontOfTextWrapTypeItem1
            // 
            this.setFloatingObjectInFrontOfTextWrapTypeItem1.Enabled = false;
            this.setFloatingObjectInFrontOfTextWrapTypeItem1.Id = 393;
            this.setFloatingObjectInFrontOfTextWrapTypeItem1.Name = "setFloatingObjectInFrontOfTextWrapTypeItem1";
            // 
            // changeFloatingObjectAlignmentItem1
            // 
            this.changeFloatingObjectAlignmentItem1.Enabled = false;
            this.changeFloatingObjectAlignmentItem1.Id = 394;
            this.changeFloatingObjectAlignmentItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectTopLeftAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectTopCenterAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectTopRightAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectMiddleLeftAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectMiddleCenterAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectMiddleRightAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectBottomLeftAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectBottomCenterAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectBottomRightAlignmentItem1)});
            this.changeFloatingObjectAlignmentItem1.Name = "changeFloatingObjectAlignmentItem1";
            // 
            // setFloatingObjectTopLeftAlignmentItem1
            // 
            this.setFloatingObjectTopLeftAlignmentItem1.Enabled = false;
            this.setFloatingObjectTopLeftAlignmentItem1.Id = 395;
            this.setFloatingObjectTopLeftAlignmentItem1.Name = "setFloatingObjectTopLeftAlignmentItem1";
            // 
            // setFloatingObjectTopCenterAlignmentItem1
            // 
            this.setFloatingObjectTopCenterAlignmentItem1.Enabled = false;
            this.setFloatingObjectTopCenterAlignmentItem1.Id = 396;
            this.setFloatingObjectTopCenterAlignmentItem1.Name = "setFloatingObjectTopCenterAlignmentItem1";
            // 
            // setFloatingObjectTopRightAlignmentItem1
            // 
            this.setFloatingObjectTopRightAlignmentItem1.Enabled = false;
            this.setFloatingObjectTopRightAlignmentItem1.Id = 397;
            this.setFloatingObjectTopRightAlignmentItem1.Name = "setFloatingObjectTopRightAlignmentItem1";
            // 
            // setFloatingObjectMiddleLeftAlignmentItem1
            // 
            this.setFloatingObjectMiddleLeftAlignmentItem1.Enabled = false;
            this.setFloatingObjectMiddleLeftAlignmentItem1.Id = 398;
            this.setFloatingObjectMiddleLeftAlignmentItem1.Name = "setFloatingObjectMiddleLeftAlignmentItem1";
            // 
            // setFloatingObjectMiddleCenterAlignmentItem1
            // 
            this.setFloatingObjectMiddleCenterAlignmentItem1.Enabled = false;
            this.setFloatingObjectMiddleCenterAlignmentItem1.Id = 399;
            this.setFloatingObjectMiddleCenterAlignmentItem1.Name = "setFloatingObjectMiddleCenterAlignmentItem1";
            // 
            // setFloatingObjectMiddleRightAlignmentItem1
            // 
            this.setFloatingObjectMiddleRightAlignmentItem1.Enabled = false;
            this.setFloatingObjectMiddleRightAlignmentItem1.Id = 400;
            this.setFloatingObjectMiddleRightAlignmentItem1.Name = "setFloatingObjectMiddleRightAlignmentItem1";
            // 
            // setFloatingObjectBottomLeftAlignmentItem1
            // 
            this.setFloatingObjectBottomLeftAlignmentItem1.Enabled = false;
            this.setFloatingObjectBottomLeftAlignmentItem1.Id = 401;
            this.setFloatingObjectBottomLeftAlignmentItem1.Name = "setFloatingObjectBottomLeftAlignmentItem1";
            // 
            // setFloatingObjectBottomCenterAlignmentItem1
            // 
            this.setFloatingObjectBottomCenterAlignmentItem1.Enabled = false;
            this.setFloatingObjectBottomCenterAlignmentItem1.Id = 402;
            this.setFloatingObjectBottomCenterAlignmentItem1.Name = "setFloatingObjectBottomCenterAlignmentItem1";
            // 
            // setFloatingObjectBottomRightAlignmentItem1
            // 
            this.setFloatingObjectBottomRightAlignmentItem1.Enabled = false;
            this.setFloatingObjectBottomRightAlignmentItem1.Id = 403;
            this.setFloatingObjectBottomRightAlignmentItem1.Name = "setFloatingObjectBottomRightAlignmentItem1";
            // 
            // floatingObjectBringForwardSubItem1
            // 
            this.floatingObjectBringForwardSubItem1.Enabled = false;
            this.floatingObjectBringForwardSubItem1.Id = 404;
            this.floatingObjectBringForwardSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.floatingObjectBringForwardItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.floatingObjectBringToFrontItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.floatingObjectBringInFrontOfTextItem1)});
            this.floatingObjectBringForwardSubItem1.Name = "floatingObjectBringForwardSubItem1";
            // 
            // floatingObjectBringForwardItem1
            // 
            this.floatingObjectBringForwardItem1.Enabled = false;
            this.floatingObjectBringForwardItem1.Id = 405;
            this.floatingObjectBringForwardItem1.Name = "floatingObjectBringForwardItem1";
            // 
            // floatingObjectBringToFrontItem1
            // 
            this.floatingObjectBringToFrontItem1.Enabled = false;
            this.floatingObjectBringToFrontItem1.Id = 406;
            this.floatingObjectBringToFrontItem1.Name = "floatingObjectBringToFrontItem1";
            // 
            // floatingObjectBringInFrontOfTextItem1
            // 
            this.floatingObjectBringInFrontOfTextItem1.Enabled = false;
            this.floatingObjectBringInFrontOfTextItem1.Id = 407;
            this.floatingObjectBringInFrontOfTextItem1.Name = "floatingObjectBringInFrontOfTextItem1";
            // 
            // floatingObjectSendBackwardSubItem1
            // 
            this.floatingObjectSendBackwardSubItem1.Enabled = false;
            this.floatingObjectSendBackwardSubItem1.Id = 408;
            this.floatingObjectSendBackwardSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.floatingObjectSendBackwardItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.floatingObjectSendToBackItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.floatingObjectSendBehindTextItem1)});
            this.floatingObjectSendBackwardSubItem1.Name = "floatingObjectSendBackwardSubItem1";
            // 
            // floatingObjectSendBackwardItem1
            // 
            this.floatingObjectSendBackwardItem1.Enabled = false;
            this.floatingObjectSendBackwardItem1.Id = 409;
            this.floatingObjectSendBackwardItem1.Name = "floatingObjectSendBackwardItem1";
            // 
            // floatingObjectSendToBackItem1
            // 
            this.floatingObjectSendToBackItem1.Enabled = false;
            this.floatingObjectSendToBackItem1.Id = 410;
            this.floatingObjectSendToBackItem1.Name = "floatingObjectSendToBackItem1";
            // 
            // floatingObjectSendBehindTextItem1
            // 
            this.floatingObjectSendBehindTextItem1.Enabled = false;
            this.floatingObjectSendBehindTextItem1.Id = 411;
            this.floatingObjectSendBehindTextItem1.Name = "floatingObjectSendBehindTextItem1";
            // 
            // dashboardPopupMenu1
            // 
            this.dashboardPopupMenu1.ItemLinks.Add(this.showItemCaptionBarItem1);
            this.dashboardPopupMenu1.ItemLinks.Add(this.duplicateItemBarItem1, true);
            this.dashboardPopupMenu1.ItemLinks.Add(this.deleteItemBarItem1);
            this.dashboardPopupMenu1.ItemLinks.Add(this.convertDashboardItemTypeBarItem1);
            this.dashboardPopupMenu1.ItemLinks.Add(this.removeDataItemsBarItem1);
            this.dashboardPopupMenu1.ItemLinks.Add(this.transposeItemBarItem1);
            this.dashboardPopupMenu1.ItemLinks.Add(this.editRulesBarItem1);
            this.dashboardPopupMenu1.ItemLinks.Add(this.editItemNamesBarItem1, true);
            this.dashboardPopupMenu1.ItemLinks.Add(this.deleteGroupBarItem1, true);
            this.dashboardPopupMenu1.ItemLinks.Add(this.editFilterBarItem1, true);
            this.dashboardPopupMenu1.ItemLinks.Add(this.clearFilterBarItem1);
            this.dashboardPopupMenu1.ItemLinks.Add(this.updateDataBarItem1, true);
            this.dashboardPopupMenu1.ItemLinks.Add(this.mapLoadBarItem1, true);
            this.dashboardPopupMenu1.ItemLinks.Add(this.mapImportBarItem1);
            this.dashboardPopupMenu1.ItemLinks.Add(this.mapDefaultShapefileBarItem1);
            this.dashboardPopupMenu1.ItemLinks.Add(this.mapFullExtentBarItem1, true);
            this.dashboardPopupMenu1.ItemLinks.Add(this.imageLoadBarItem1, true);
            this.dashboardPopupMenu1.ItemLinks.Add(this.imageImportBarItem1);
            this.dashboardPopupMenu1.ItemLinks.Add(this.textBoxEditTextBarItem1, true);
            this.dashboardPopupMenu1.ItemLinks.Add(this.textBoxInsertFieldBarItem1);
            this.dashboardPopupMenu1.ItemLinks.Add(this.rangeFilterEditDateTimePeriodsBarItem1, true);
            this.dashboardPopupMenu1.ItemLinks.Add(this.pivotResetLayoutOptionsBarItem1, true);
            this.dashboardPopupMenu1.Name = "dashboardPopupMenu1";
            this.dashboardPopupMenu1.Ribbon = this.ribbonControl1;
            // 
            // dashboarddesigner
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.dashboardDesigner1);
            this.Controls.Add(this.ribbonControl1);
            this.Controls.Add(this.dashboardBackstageViewControl1);
            this.Name = "dashboarddesigner";
            this.Text = "dashboarddesigner";
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardBackstageViewControl1)).EndInit();
            this.dashboardBackstageViewControl1.ResumeLayout(false);
            this.backstageViewClientControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dashboardBarAndDockingController1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardBarController1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBoxEditorBarController1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemFontEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichEditFontSizeEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemBorderLineStyle1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemBorderLineWeight1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemFloatingObjectOutlineWeight1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardPopupMenu1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.DashboardWin.DashboardDesigner dashboardDesigner1;
        private DevExpress.DashboardWin.Native.DashboardBarAndDockingController dashboardBarAndDockingController1;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.DashboardWin.Bars.DashboardBackstageViewControl dashboardBackstageViewControl1;
        private DevExpress.XtraBars.Ribbon.BackstageViewClientControl backstageViewClientControl1;
        private DevExpress.DashboardWin.Bars.RecentDashboardsControl recentDashboardsControl1;
        private DevExpress.DashboardWin.Bars.DashboardBackstageRecentTab dashboardBackstageRecentTab1;
        private DevExpress.DashboardWin.Bars.DashboardBackstageNewButton dashboardBackstageNewButton1;
        private DevExpress.DashboardWin.Bars.DashboardBackstageOpenButton dashboardBackstageOpenButton1;
        private DevExpress.DashboardWin.Bars.DashboardBackstageSaveButton dashboardBackstageSaveButton1;
        private DevExpress.DashboardWin.Bars.DashboardBackstageSaveAsButton dashboardBackstageSaveAsButton1;
        private DevExpress.DashboardWin.Bars.FileNewBarItem fileNewBarItem1;
        private DevExpress.DashboardWin.Bars.FileOpenBarItem fileOpenBarItem1;
        private DevExpress.DashboardWin.Bars.FileSaveBarItem fileSaveBarItem1;
        private DevExpress.DashboardWin.Bars.FileSaveAsBarItem fileSaveAsBarItem1;
        private DevExpress.DashboardWin.Bars.QuickAccessUndoBarItem quickAccessUndoBarItem1;
        private DevExpress.DashboardWin.Bars.QuickAccessRedoBarItem quickAccessRedoBarItem1;
        private DevExpress.DashboardWin.Bars.UndoBarItem undoBarItem1;
        private DevExpress.DashboardWin.Bars.RedoBarItem redoBarItem1;
        private DevExpress.DashboardWin.Bars.InsertPivotBarItem insertPivotBarItem1;
        private DevExpress.DashboardWin.Bars.InsertGridBarItem insertGridBarItem1;
        private DevExpress.DashboardWin.Bars.InsertChartBarItem insertChartBarItem1;
        private DevExpress.DashboardWin.Bars.InsertScatterChartBarItem insertScatterChartBarItem1;
        private DevExpress.DashboardWin.Bars.InsertPiesBarItem insertPiesBarItem1;
        private DevExpress.DashboardWin.Bars.InsertGaugesBarItem insertGaugesBarItem1;
        private DevExpress.DashboardWin.Bars.InsertCardsBarItem insertCardsBarItem1;
        private DevExpress.DashboardWin.Bars.InsertTreemapBarItem insertTreemapBarItem1;
        private DevExpress.DashboardWin.Bars.InsertChoroplethMapBarItem insertChoroplethMapBarItem1;
        private DevExpress.DashboardWin.Bars.InsertGeoPointMapBarSubItem insertGeoPointMapBarSubItem1;
        private DevExpress.DashboardWin.Bars.InsertGeoPointMapBarItem insertGeoPointMapBarItem1;
        private DevExpress.DashboardWin.Bars.InsertBubbleMapBarItem insertBubbleMapBarItem1;
        private DevExpress.DashboardWin.Bars.InsertPieMapBarItem insertPieMapBarItem1;
        private DevExpress.DashboardWin.Bars.InsertRangeFilterBarItem insertRangeFilterBarItem1;
        private DevExpress.DashboardWin.Bars.InsertFilterElementSubItem insertFilterElementSubItem1;
        private DevExpress.DashboardWin.Bars.InsertComboBoxBarItem insertComboBoxBarItem1;
        private DevExpress.DashboardWin.Bars.InsertListBoxBarItem insertListBoxBarItem1;
        private DevExpress.DashboardWin.Bars.InsertTreeViewBarItem insertTreeViewBarItem1;
        private DevExpress.DashboardWin.Bars.InsertImagesBarSubItem insertImagesBarSubItem1;
        private DevExpress.DashboardWin.Bars.InsertImageBarItem insertImageBarItem1;
        private DevExpress.DashboardWin.Bars.InsertBoundImageBarItem insertBoundImageBarItem1;
        private DevExpress.DashboardWin.Bars.InsertTextBoxBarItem insertTextBoxBarItem1;
        private DevExpress.DashboardWin.Bars.InsertGroupBarItem insertGroupBarItem1;
        private DevExpress.DashboardWin.Bars.DuplicateItemBarItem duplicateItemBarItem1;
        private DevExpress.DashboardWin.Bars.DeleteItemBarItem deleteItemBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertDashboardItemTypeBarItem convertDashboardItemTypeBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToPivotBarItem convertToPivotBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToGridBarItem convertToGridBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToChartBarItem convertToChartBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToScatterChartBarItem convertToScatterChartBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToPieBarItem convertToPieBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToGaugeBarItem convertToGaugeBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToCardBarItem convertToCardBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToTreemapBarItem convertToTreemapBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToChoroplethMapBarItem convertToChoroplethMapBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertGeoPointMapBaseBarItem convertGeoPointMapBaseBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToGeoPointMapBarItem convertToGeoPointMapBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToBubbleMapBarItem convertToBubbleMapBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToPieMapBarItem convertToPieMapBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToRangeFilterBarItem convertToRangeFilterBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToFilterElementsBaseBarItem convertToFilterElementsBaseBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToComboBoxBarItem convertToComboBoxBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToListBoxBarItem convertToListBoxBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToTreeViewBarItem convertToTreeViewBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToBoundImageBarItem convertToBoundImageBarItem1;
        private DevExpress.DashboardWin.Bars.ConvertToTextBoxBarItem convertToTextBoxBarItem1;
        private DevExpress.DashboardWin.Bars.RemoveDataItemsBarItem removeDataItemsBarItem1;
        private DevExpress.DashboardWin.Bars.TransposeItemBarItem transposeItemBarItem1;
        private DevExpress.DashboardWin.Bars.EditRulesBarItem editRulesBarItem1;
        private DevExpress.DashboardWin.Bars.DeleteGroupBarItem deleteGroupBarItem1;
        private DevExpress.DashboardWin.Bars.DashboardTitleBarItem dashboardTitleBarItem1;
        private DevExpress.DashboardWin.Bars.SetCurrencyCultureBarItem setCurrencyCultureBarItem1;
        private DevExpress.DashboardWin.Bars.DashboardColorSchemeBarItem dashboardColorSchemeBarItem1;
        private DevExpress.DashboardWin.Bars.DashboardParametersBarItem dashboardParametersBarItem1;
        private DevExpress.DashboardWin.Bars.DashboardAutomaticUpdatesBarItem dashboardAutomaticUpdatesBarItem1;
        private DevExpress.DashboardWin.Bars.UpdateDataBarItem updateDataBarItem1;
        private DevExpress.DashboardWin.Bars.NewDataSourceBarItem newDataSourceBarItem1;
        private DevExpress.DashboardWin.Bars.EditSqlConnectionBarItem editSqlConnectionBarItem1;
        private DevExpress.DashboardWin.Bars.EditOlapConnectionBarItem editOlapConnectionBarItem1;
        private DevExpress.DashboardWin.Bars.EditObjectDataSourceBarItem editObjectDataSourceBarItem1;
        private DevExpress.DashboardWin.Bars.EditExcelDataSourceBarItem editExcelDataSourceBarItem1;
        private DevExpress.DashboardWin.Bars.EditEFDataSourceBarItem editEFDataSourceBarItem1;
        private DevExpress.DashboardWin.Bars.EditExtractOptionsBarItem editExtractOptionsBarItem1;
        private DevExpress.DashboardWin.Bars.RenameDataSourceBarItem renameDataSourceBarItem1;
        private DevExpress.DashboardWin.Bars.DeleteDataSourceBarItem deleteDataSourceBarItem1;
        private DevExpress.DashboardWin.Bars.ServerModeBarItem serverModeBarItem1;
        private DevExpress.DashboardWin.Bars.UpateDataExtractBarItem upateDataExtractBarItem1;
        private DevExpress.DashboardWin.Bars.AddCalculatedFieldBarItem addCalculatedFieldBarItem1;
        private DevExpress.DashboardWin.Bars.AddQueryBarItem addQueryBarItem1;
        private DevExpress.DashboardWin.Bars.EditQueryBarItem editQueryBarItem1;
        private DevExpress.DashboardWin.Bars.RenameQueryBarItem renameQueryBarItem1;
        private DevExpress.DashboardWin.Bars.EditQueryFilterBarItem editQueryFilterBarItem1;
        private DevExpress.DashboardWin.Bars.DeleteQueryBarItem deleteQueryBarItem1;
        private DevExpress.DashboardWin.Bars.EditExtractSourceConnectionBarItem editExtractSourceConnectionBarItem1;
        private DevExpress.DashboardWin.Bars.EditExtractSourceBarItem editExtractSourceBarItem1;
        private DevExpress.DashboardWin.Bars.EditExtractSourceQueryBarItem editExtractSourceQueryBarItem1;
        private DevExpress.DashboardWin.Bars.EditDataSourceFilterBarItem editDataSourceFilterBarItem1;
        private DevExpress.DashboardWin.Bars.ClearDataSourceFilterBarItem clearDataSourceFilterBarItem1;
        private DevExpress.DashboardWin.Bars.DashboardSkinsBarItem dashboardSkinsBarItem1;
        private DevExpress.DashboardWin.Bars.EditFilterBarItem editFilterBarItem1;
        private DevExpress.DashboardWin.Bars.ClearFilterBarItem clearFilterBarItem1;
        private DevExpress.DashboardWin.Bars.IgnoreMasterFiltersBarItem ignoreMasterFiltersBarItem1;
        private DevExpress.DashboardWin.Bars.ShowItemCaptionBarItem showItemCaptionBarItem1;
        private DevExpress.DashboardWin.Bars.EditItemNamesBarItem editItemNamesBarItem1;
        private DevExpress.DashboardWin.Bars.PivotInitialStateBarItem pivotInitialStateBarItem1;
        private DevExpress.DashboardWin.Bars.PivotAutoExpandColumnBarItem pivotAutoExpandColumnBarItem1;
        private DevExpress.DashboardWin.Bars.PivotAutoExpandRowBarItem pivotAutoExpandRowBarItem1;
        private DevExpress.DashboardWin.Bars.PivotShowTotalsBarItem pivotShowTotalsBarItem1;
        private DevExpress.DashboardWin.Bars.PivotShowColumnTotalsBarItem pivotShowColumnTotalsBarItem1;
        private DevExpress.DashboardWin.Bars.PivotShowRowTotalsBarItem pivotShowRowTotalsBarItem1;
        private DevExpress.DashboardWin.Bars.PivotShowGrandTotalsBarItem pivotShowGrandTotalsBarItem1;
        private DevExpress.DashboardWin.Bars.PivotShowColumnGrandTotalsBarItem pivotShowColumnGrandTotalsBarItem1;
        private DevExpress.DashboardWin.Bars.PivotShowRowGrandTotalsBarItem pivotShowRowGrandTotalsBarItem1;
        private DevExpress.DashboardWin.Bars.PivotLayoutTypeBarItem pivotLayoutTypeBarItem1;
        private DevExpress.DashboardWin.Bars.PivotLayoutTypeCompactBarItem pivotLayoutTypeCompactBarItem1;
        private DevExpress.DashboardWin.Bars.PivotLayoutTypeTabularBarItem pivotLayoutTypeTabularBarItem1;
        private DevExpress.DashboardWin.Bars.PivotRowTotalsPositionBarItem pivotRowTotalsPositionBarItem1;
        private DevExpress.DashboardWin.Bars.PivotRowTotalsPositionTopBarItem pivotRowTotalsPositionTopBarItem1;
        private DevExpress.DashboardWin.Bars.PivotRowTotalsPositionBottomBarItem pivotRowTotalsPositionBottomBarItem1;
        private DevExpress.DashboardWin.Bars.PivotColumnTotalsPositionBarItem pivotColumnTotalsPositionBarItem1;
        private DevExpress.DashboardWin.Bars.PivotColumnTotalsPositionNearBarItem pivotColumnTotalsPositionNearBarItem1;
        private DevExpress.DashboardWin.Bars.PivotColumnTotalsPositionFarBarItem pivotColumnTotalsPositionFarBarItem1;
        private DevExpress.DashboardWin.Bars.PivotValuesPositionBarItem pivotValuesPositionBarItem1;
        private DevExpress.DashboardWin.Bars.PivotValuesPositionColumnsBarItem pivotValuesPositionColumnsBarItem1;
        private DevExpress.DashboardWin.Bars.PivotValuesPositionRowsBarItem pivotValuesPositionRowsBarItem1;
        private DevExpress.DashboardWin.Bars.PivotResetLayoutOptionsBarItem pivotResetLayoutOptionsBarItem1;
        private DevExpress.DashboardWin.Bars.MasterFilterBarItem masterFilterBarItem1;
        private DevExpress.DashboardWin.Bars.MultipleValuesMasterFilterBarItem multipleValuesMasterFilterBarItem1;
        private DevExpress.DashboardWin.Bars.DrillDownBarItem drillDownBarItem1;
        private DevExpress.DashboardWin.Bars.CrossDataSourceFilteringBarItem crossDataSourceFilteringBarItem1;
        private DevExpress.DashboardWin.Bars.GridHorizontalLinesBarItem gridHorizontalLinesBarItem1;
        private DevExpress.DashboardWin.Bars.GridVerticalLinesBarItem gridVerticalLinesBarItem1;
        private DevExpress.DashboardWin.Bars.GridBandedRowsBarItem gridBandedRowsBarItem1;
        private DevExpress.DashboardWin.Bars.GridMergeCellsBarItem gridMergeCellsBarItem1;
        private DevExpress.DashboardWin.Bars.GridColumnHeadersBarItem gridColumnHeadersBarItem1;
        private DevExpress.DashboardWin.Bars.GridWordWrapBarItem gridWordWrapBarItem1;
        private DevExpress.DashboardWin.Bars.GridAutoFitToContentsColumnWidthModeBarItem gridAutoFitToContentsColumnWidthModeBarItem1;
        private DevExpress.DashboardWin.Bars.GridAutoFitToGridColumnWidthModeBarItem gridAutoFitToGridColumnWidthModeBarItem1;
        private DevExpress.DashboardWin.Bars.ManualGridColumnWidthModeBarItem manualGridColumnWidthModeBarItem1;
        private DevExpress.DashboardWin.Bars.ChartTargetDimensionsArgumentsBarItem chartTargetDimensionsArgumentsBarItem1;
        private DevExpress.DashboardWin.Bars.ChartTargetDimensionsSeriesBarItem chartTargetDimensionsSeriesBarItem1;
        private DevExpress.DashboardWin.Bars.ChartTargetDimensionsPointsBarItem chartTargetDimensionsPointsBarItem1;
        private DevExpress.DashboardWin.Bars.ChartRotateBarItem chartRotateBarItem1;
        private DevExpress.DashboardWin.Bars.ChartXAxisSettingsBarItem chartXAxisSettingsBarItem1;
        private DevExpress.DashboardWin.Bars.ChartYAxisSettingsBarItem chartYAxisSettingsBarItem1;
        private DevExpress.DashboardWin.Bars.ChartShowLegendBarItem chartShowLegendBarItem1;
        private DevExpress.DashboardWin.Bars.GalleryChartLegendPositionItem galleryChartLegendPositionItem1;
        private DevExpress.DashboardWin.Bars.GalleryChartSeriesTypeItem galleryChartSeriesTypeItem1;
        private DevExpress.DashboardWin.Bars.UseGlobalColorsBarItem useGlobalColorsBarItem1;
        private DevExpress.DashboardWin.Bars.UseLocalColorsBarItem useLocalColorsBarItem1;
        private DevExpress.DashboardWin.Bars.EditActualColorsBarItem editActualColorsBarItem1;
        private DevExpress.DashboardWin.Bars.ScatterChartRotateBarItem scatterChartRotateBarItem1;
        private DevExpress.DashboardWin.Bars.ScatterChartXAxisSettingsBarItem scatterChartXAxisSettingsBarItem1;
        private DevExpress.DashboardWin.Bars.ScatterChartYAxisSettingsBarItem scatterChartYAxisSettingsBarItem1;
        private DevExpress.DashboardWin.Bars.ScatterChartPointLabelOptionsBarItem scatterChartPointLabelOptionsBarItem1;
        private DevExpress.DashboardWin.Bars.ScatterChartShowLegendBarItem scatterChartShowLegendBarItem1;
        private DevExpress.DashboardWin.Bars.GalleryScatterChartLegendPositionItem galleryScatterChartLegendPositionItem1;
        private DevExpress.DashboardWin.Bars.PieTargetDimensionsArgumentsBarItem pieTargetDimensionsArgumentsBarItem1;
        private DevExpress.DashboardWin.Bars.PieTargetDimensionsSeriesBarItem pieTargetDimensionsSeriesBarItem1;
        private DevExpress.DashboardWin.Bars.PieTargetDimensionsPointsBarItem pieTargetDimensionsPointsBarItem1;
        private DevExpress.DashboardWin.Bars.ContentAutoArrangeBarItem contentAutoArrangeBarItem1;
        private DevExpress.DashboardWin.Bars.ContentArrangeInColumnsBarItem contentArrangeInColumnsBarItem1;
        private DevExpress.DashboardWin.Bars.ContentArrangeInRowsBarItem contentArrangeInRowsBarItem1;
        private DevExpress.DashboardWin.Bars.ContentArrangementCountBarItem contentArrangementCountBarItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit1;
        private DevExpress.DashboardWin.Bars.PieLabelsDataLabelsBarItem pieLabelsDataLabelsBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsDataLabelsNoneBarItem pieLabelsDataLabelsNoneBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsDataLabelArgumentBarItem pieLabelsDataLabelArgumentBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsDataLabelsValueBarItem pieLabelsDataLabelsValueBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsDataLabelsArgumentAndValueBarItem pieLabelsDataLabelsArgumentAndValueBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsDataLabelsPercentBarItem pieLabelsDataLabelsPercentBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsDataLabelsValueAndPercentBarItem pieLabelsDataLabelsValueAndPercentBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsDataLabelsArgumentAndPercentBarItem pieLabelsDataLabelsArgumentAndPercentBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsDataLabelsArgumentValueAndPercentBarItem pieLabelsDataLabelsArgumentValueAndPercentBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelPositionBarItem pieLabelPositionBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelPositionOutsideBarItem pieLabelPositionOutsideBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelPositionInsideBarItem pieLabelPositionInsideBarItem1;
        private DevExpress.DashboardWin.Bars.PieTooltipsBarItem pieTooltipsBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsTooltipsNoneBarItem pieLabelsTooltipsNoneBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsTooltipsArgumentBarItem pieLabelsTooltipsArgumentBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsTooltipsValueBarItem pieLabelsTooltipsValueBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsTooltipsArgumentAndValueBarItem pieLabelsTooltipsArgumentAndValueBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsTooltipsPercentBarItem pieLabelsTooltipsPercentBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsTooltipsValueAndPercentBarItem pieLabelsTooltipsValueAndPercentBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsTooltipsArgumentAndPercentBarItem pieLabelsTooltipsArgumentAndPercentBarItem1;
        private DevExpress.DashboardWin.Bars.PieLabelsTooltipsArgumentValueAndPercentBarItem pieLabelsTooltipsArgumentValueAndPercentBarItem1;
        private DevExpress.DashboardWin.Bars.PieStylePieBarItem pieStylePieBarItem1;
        private DevExpress.DashboardWin.Bars.PieStyleDonutBarItem pieStyleDonutBarItem1;
        private DevExpress.DashboardWin.Bars.PieShowCaptionsBarItem pieShowCaptionsBarItem1;
        private DevExpress.DashboardWin.Bars.GaugeStyleFullCircularBarItem gaugeStyleFullCircularBarItem1;
        private DevExpress.DashboardWin.Bars.GaugeStyleHalfCircularBarItem gaugeStyleHalfCircularBarItem1;
        private DevExpress.DashboardWin.Bars.GaugeStyleLeftQuarterCircularBarItem gaugeStyleLeftQuarterCircularBarItem1;
        private DevExpress.DashboardWin.Bars.GaugeStyleRightQuarterCircularBarItem gaugeStyleRightQuarterCircularBarItem1;
        private DevExpress.DashboardWin.Bars.GaugeStyleThreeForthCircularBarItem gaugeStyleThreeForthCircularBarItem1;
        private DevExpress.DashboardWin.Bars.GaugeStyleLinearHorizontalBarItem gaugeStyleLinearHorizontalBarItem1;
        private DevExpress.DashboardWin.Bars.GaugeStyleLinearVerticalBarItem gaugeStyleLinearVerticalBarItem1;
        private DevExpress.DashboardWin.Bars.GaugeShowCaptionsBarItem gaugeShowCaptionsBarItem1;
        private DevExpress.DashboardWin.Bars.GalleryRangeFilterSeriesTypeItem galleryRangeFilterSeriesTypeItem1;
        private DevExpress.DashboardWin.Bars.RangeFilterEditDateTimePeriodsBarItem rangeFilterEditDateTimePeriodsBarItem1;
        private DevExpress.DashboardWin.Bars.MapLoadBarItem mapLoadBarItem1;
        private DevExpress.DashboardWin.Bars.MapImportBarItem mapImportBarItem1;
        private DevExpress.DashboardWin.Bars.MapDefaultShapefileBarItem mapDefaultShapefileBarItem1;
        private DevExpress.DashboardWin.Bars.MapWorldCountriesBarItem mapWorldCountriesBarItem1;
        private DevExpress.DashboardWin.Bars.MapEuropeBarItem mapEuropeBarItem1;
        private DevExpress.DashboardWin.Bars.MapAsiaBarItem mapAsiaBarItem1;
        private DevExpress.DashboardWin.Bars.MapNorthAmericaBarItem mapNorthAmericaBarItem1;
        private DevExpress.DashboardWin.Bars.MapSouthAmericaBarItem mapSouthAmericaBarItem1;
        private DevExpress.DashboardWin.Bars.MapAfricaBarItem mapAfricaBarItem1;
        private DevExpress.DashboardWin.Bars.MapUSABarItem mapUSABarItem1;
        private DevExpress.DashboardWin.Bars.MapCanadaBarItem mapCanadaBarItem1;
        private DevExpress.DashboardWin.Bars.MapLockNavigationBarItem mapLockNavigationBarItem1;
        private DevExpress.DashboardWin.Bars.MapFullExtentBarItem mapFullExtentBarItem1;
        private DevExpress.DashboardWin.Bars.ChoroplethMapShapeLabelsAttributeBarItem choroplethMapShapeLabelsAttributeBarItem1;
        private DevExpress.DashboardWin.Bars.MapShowLegendBarItem mapShowLegendBarItem1;
        private DevExpress.DashboardWin.Bars.GalleryMapLegendPositionItem galleryMapLegendPositionItem1;
        private DevExpress.DashboardWin.Bars.GeoPointMapClusterizationBarItem geoPointMapClusterizationBarItem1;
        private DevExpress.DashboardWin.Bars.MapShapeTitleAttributeBarItem mapShapeTitleAttributeBarItem1;
        private DevExpress.DashboardWin.Bars.ChangeWeightedLegendTypeBarItem changeWeightedLegendTypeBarItem1;
        private DevExpress.DashboardWin.Bars.WeightedLegendNoneBarItem weightedLegendNoneBarItem1;
        private DevExpress.DashboardWin.Bars.WeightedLegendLinearBarItem weightedLegendLinearBarItem1;
        private DevExpress.DashboardWin.Bars.WeightedLegendNestedBarItem weightedLegendNestedBarItem1;
        private DevExpress.DashboardWin.Bars.GalleryWeightedLegendPositionItem galleryWeightedLegendPositionItem1;
        private DevExpress.DashboardWin.Bars.PieMapIsWeightedBarItem pieMapIsWeightedBarItem1;
        private DevExpress.DashboardWin.Bars.ComboBoxStandardTypeBarItem comboBoxStandardTypeBarItem1;
        private DevExpress.DashboardWin.Bars.ComboBoxCheckedTypeBarItem comboBoxCheckedTypeBarItem1;
        private DevExpress.DashboardWin.Bars.ListBoxCheckedTypeBarItem listBoxCheckedTypeBarItem1;
        private DevExpress.DashboardWin.Bars.ListBoxRadioTypeBarItem listBoxRadioTypeBarItem1;
        private DevExpress.DashboardWin.Bars.FilterElementShowAllValueBarItem filterElementShowAllValueBarItem1;
        private DevExpress.DashboardWin.Bars.FilterElementEnableSearchBarItem filterElementEnableSearchBarItem1;
        private DevExpress.DashboardWin.Bars.TreeViewAutoExpandBarItem treeViewAutoExpandBarItem1;
        private DevExpress.DashboardWin.Bars.ImageSizeModeClipBarItem imageSizeModeClipBarItem1;
        private DevExpress.DashboardWin.Bars.ImageSizeModeStretchBarItem imageSizeModeStretchBarItem1;
        private DevExpress.DashboardWin.Bars.ImageSizeModeSqueezeBarItem imageSizeModeSqueezeBarItem1;
        private DevExpress.DashboardWin.Bars.ImageSizeModeZoomBarItem imageSizeModeZoomBarItem1;
        private DevExpress.DashboardWin.Bars.ImageAlignmentTopLeftBarItem imageAlignmentTopLeftBarItem1;
        private DevExpress.DashboardWin.Bars.ImageAlignmentCenterLeftBarItem imageAlignmentCenterLeftBarItem1;
        private DevExpress.DashboardWin.Bars.ImageAlignmentBottomLeftBarItem imageAlignmentBottomLeftBarItem1;
        private DevExpress.DashboardWin.Bars.ImageAlignmentTopCenterBarItem imageAlignmentTopCenterBarItem1;
        private DevExpress.DashboardWin.Bars.ImageAlignmentCenterCenterBarItem imageAlignmentCenterCenterBarItem1;
        private DevExpress.DashboardWin.Bars.ImageAlignmentBottomCenterBarItem imageAlignmentBottomCenterBarItem1;
        private DevExpress.DashboardWin.Bars.ImageAlignmentTopRightBarItem imageAlignmentTopRightBarItem1;
        private DevExpress.DashboardWin.Bars.ImageAlignmentCenterRightBarItem imageAlignmentCenterRightBarItem1;
        private DevExpress.DashboardWin.Bars.ImageAlignmentBottomRightBarItem imageAlignmentBottomRightBarItem1;
        private DevExpress.DashboardWin.Bars.TextBoxEditTextBarItem textBoxEditTextBarItem1;
        private DevExpress.DashboardWin.Bars.TextBoxInsertFieldBarItem textBoxInsertFieldBarItem1;
        private DevExpress.DashboardWin.Bars.PivotToolsRibbonPageCategory pivotToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage1;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage1;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.PivotInitialStateRibbonPageGroup pivotInitialStateRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.PivotLayoutRibbonPageGroup pivotLayoutRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.GridToolsRibbonPageCategory gridToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage2;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup2;
        private DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup masterFilterRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup2;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage2;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup2;
        private DevExpress.DashboardWin.Bars.GridStyleRibbonPageGroup gridStyleRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.GridLayoutRibbonPageGroup gridLayoutRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.GridColumnWidthModeRibbonPageGroup gridColumnWidthModeRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.ChartToolsRibbonPageCategory chartToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage3;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup3;
        private DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup masterFilterRibbonPageGroup2;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup3;
        private DevExpress.DashboardWin.Bars.TargetDimensionsRibbonPageGroup targetDimensionsRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage3;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup3;
        private DevExpress.DashboardWin.Bars.ChartLayoutPageGroup chartLayoutPageGroup1;
        private DevExpress.DashboardWin.Bars.ChartLegendPositionPageGroup chartLegendPositionPageGroup1;
        private DevExpress.DashboardWin.Bars.ChartStylePageGroup chartStylePageGroup1;
        private DevExpress.DashboardWin.Bars.ColoringOptionsRibbonPageGroup coloringOptionsRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.ScatterChartToolsRibbonPageCategory scatterChartToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage4;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup4;
        private DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup masterFilterRibbonPageGroup3;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup4;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage4;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup4;
        private DevExpress.DashboardWin.Bars.ScatterChartLayoutPageGroup scatterChartLayoutPageGroup1;
        private DevExpress.DashboardWin.Bars.ScatterChartPointLabelPageGroup scatterChartPointLabelPageGroup1;
        private DevExpress.DashboardWin.Bars.ScatterChartLegendPositionPageGroup scatterChartLegendPositionPageGroup1;
        private DevExpress.DashboardWin.Bars.ColoringOptionsRibbonPageGroup coloringOptionsRibbonPageGroup2;
        private DevExpress.DashboardWin.Bars.PiesToolsRibbonPageCategory piesToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage5;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup5;
        private DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup masterFilterRibbonPageGroup4;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup5;
        private DevExpress.DashboardWin.Bars.TargetDimensionsRibbonPageGroup targetDimensionsRibbonPageGroup2;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage5;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup5;
        private DevExpress.DashboardWin.Bars.ContentArrangementRibbonPageGroup contentArrangementRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.PieLabelsRibbonPageGroup pieLabelsRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.PieStyleRibbonPageGroup pieStyleRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.ColoringOptionsRibbonPageGroup coloringOptionsRibbonPageGroup3;
        private DevExpress.DashboardWin.Bars.GaugesToolsRibbonPageCategory gaugesToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage6;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup6;
        private DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup masterFilterRibbonPageGroup5;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup6;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage6;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup6;
        private DevExpress.DashboardWin.Bars.ContentArrangementRibbonPageGroup contentArrangementRibbonPageGroup2;
        private DevExpress.DashboardWin.Bars.GaugeStyleRibbonPageGroup gaugeStyleRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.GaugesLabelsRibbonPageGroup gaugesLabelsRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.CardsToolsRibbonPageCategory cardsToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage7;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup7;
        private DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup masterFilterRibbonPageGroup6;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup7;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage7;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup7;
        private DevExpress.DashboardWin.Bars.ContentArrangementRibbonPageGroup contentArrangementRibbonPageGroup3;
        private DevExpress.DashboardWin.Bars.RangeFilterToolsRibbonPageCategory rangeFilterToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage8;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup8;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup8;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage8;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup8;
        private DevExpress.DashboardWin.Bars.RangeFilterSeriesTypeRibbonPageGroup rangeFilterSeriesTypeRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.RangeFilterInteractivityRibbonPageGroup rangeFilterInteractivityRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.ColoringOptionsRibbonPageGroup coloringOptionsRibbonPageGroup4;
        private DevExpress.DashboardWin.Bars.ChoroplethMapToolsRibbonPageCategory choroplethMapToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage9;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup9;
        private DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup masterFilterRibbonPageGroup7;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup9;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage9;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup9;
        private DevExpress.DashboardWin.Bars.MapShapefileRibbonPageGroup mapShapefileRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.MapNavigationPageGroup mapNavigationPageGroup1;
        private DevExpress.DashboardWin.Bars.MapShapeLabelsAttributePageGroup mapShapeLabelsAttributePageGroup1;
        private DevExpress.DashboardWin.Bars.MapLegendPositionPageGroup mapLegendPositionPageGroup1;
        private DevExpress.DashboardWin.Bars.GeoPointMapToolsRibbonPageCategory geoPointMapToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage10;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup10;
        private DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup masterFilterRibbonPageGroup8;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup10;
        private DevExpress.DashboardWin.Bars.GeoPointMapClusterizationRibbonPageGroup geoPointMapClusterizationRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage10;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup10;
        private DevExpress.DashboardWin.Bars.MapShapefileRibbonPageGroup mapShapefileRibbonPageGroup2;
        private DevExpress.DashboardWin.Bars.MapNavigationPageGroup mapNavigationPageGroup2;
        private DevExpress.DashboardWin.Bars.MapShapeLabelsAttributePageGroup mapShapeLabelsAttributePageGroup2;
        private DevExpress.DashboardWin.Bars.BubbleMapToolsRibbonPageCategory bubbleMapToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage11;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup11;
        private DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup masterFilterRibbonPageGroup9;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup11;
        private DevExpress.DashboardWin.Bars.GeoPointMapClusterizationRibbonPageGroup geoPointMapClusterizationRibbonPageGroup2;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage11;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup11;
        private DevExpress.DashboardWin.Bars.MapShapefileRibbonPageGroup mapShapefileRibbonPageGroup3;
        private DevExpress.DashboardWin.Bars.MapNavigationPageGroup mapNavigationPageGroup3;
        private DevExpress.DashboardWin.Bars.MapShapeLabelsAttributePageGroup mapShapeLabelsAttributePageGroup3;
        private DevExpress.DashboardWin.Bars.MapLegendPositionPageGroup mapLegendPositionPageGroup2;
        private DevExpress.DashboardWin.Bars.WeightedLegendPageGroup weightedLegendPageGroup1;
        private DevExpress.DashboardWin.Bars.PieMapToolsRibbonPageCategory pieMapToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage12;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup12;
        private DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup masterFilterRibbonPageGroup10;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup12;
        private DevExpress.DashboardWin.Bars.GeoPointMapClusterizationRibbonPageGroup geoPointMapClusterizationRibbonPageGroup3;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage12;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup12;
        private DevExpress.DashboardWin.Bars.MapShapefileRibbonPageGroup mapShapefileRibbonPageGroup4;
        private DevExpress.DashboardWin.Bars.MapNavigationPageGroup mapNavigationPageGroup4;
        private DevExpress.DashboardWin.Bars.MapShapeLabelsAttributePageGroup mapShapeLabelsAttributePageGroup4;
        private DevExpress.DashboardWin.Bars.MapLegendPositionPageGroup mapLegendPositionPageGroup3;
        private DevExpress.DashboardWin.Bars.WeightedLegendPageGroup weightedLegendPageGroup2;
        private DevExpress.DashboardWin.Bars.PieMapOptionsPageGroup pieMapOptionsPageGroup1;
        private DevExpress.DashboardWin.Bars.ColoringOptionsRibbonPageGroup coloringOptionsRibbonPageGroup5;
        private DevExpress.DashboardWin.Bars.FilterElementToolsRibbonPageCategory filterElementToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage13;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup13;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup13;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage13;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup13;
        private DevExpress.DashboardWin.Bars.FilterElementTypeRibbonPageGroup filterElementTypeRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.FilterElementItemOptionsRibbonPageGroup filterElementItemOptionsRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.TreeViewOptionsRibbonPageGroup treeViewOptionsRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.TreeViewLayoutRibbonPageGroup treeViewLayoutRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.BoundImageToolsRibbonPageCategory boundImageToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage14;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup14;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup14;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage14;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup14;
        private DevExpress.DashboardWin.Bars.ImageSizeModeRibbonPageGroup imageSizeModeRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.ImageAlignmentRibbonPageGroup imageAlignmentRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.TextBoxToolsRibbonPageCategory textBoxToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage15;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup15;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup15;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage15;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup15;
        private DevExpress.DashboardWin.Bars.TextBoxEditingRibbonPageGroup textBoxEditingRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.TreemapToolsRibbonPageCategory treemapToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage16;
        private DevExpress.DashboardWin.Bars.FilteringRibbonPageGroup filteringRibbonPageGroup16;
        private DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup masterFilterRibbonPageGroup11;
        private DevExpress.DashboardWin.Bars.InteractivitySettingsRibbonPageGroup interactivitySettingsRibbonPageGroup16;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage16;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup16;
        private DevExpress.DashboardWin.Bars.HomeRibbonPage homeRibbonPage1;
        private DevExpress.DashboardWin.Bars.FileRibbonPageGroup fileRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.QuickAccessHistoryRibbonPageGroup quickAccessHistoryRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.HistoryRibbonPageGroup historyRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.InsertRibbonPageGroup insertRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.ItemOperationRibbonPageGroup itemOperationRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.GroupOperationRibbonPageGroup groupOperationRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.DashboardDesignRibbonPageGroup dashboardDesignRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.DataSourceRibbonPage dataSourceRibbonPage1;
        private DevExpress.DashboardWin.Bars.DataSourceRibbonPageGroup dataSourceRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.SqlDataSourceQueryRibbonPageGroup sqlDataSourceQueryRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.ExtractSourceRibbonPageGroup extractSourceRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.DataSourceFilteringRibbonPageGroup dataSourceFilteringRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.ViewRibbonPage viewRibbonPage1;
        private DevExpress.DashboardWin.Bars.SkinsRibbonPageGroup skinsRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.DashboardBarController dashboardBarController1;
        private DevExpress.DashboardWin.Bars.TreemapSliceAndDiceLayoutAlgorithmBarItem treemapSliceAndDiceLayoutAlgorithmBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapSquarifiedLayoutAlgorithmBarItem treemapSquarifiedLayoutAlgorithmBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapStripedLayoutAlgorithmBarItem treemapStripedLayoutAlgorithmBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapLayoutDirectionBarItem treemapLayoutDirectionBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapBottomLeftToTopRightLayoutDirectionBarItem treemapBottomLeftToTopRightLayoutDirectionBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapBottomRightToTopLeftLayoutDirectionBarItem treemapBottomRightToTopLeftLayoutDirectionBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapTopLeftToBottomRightLayoutDirectionBarItem treemapTopLeftToBottomRightLayoutDirectionBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapTopRightToBottomLeftLayoutDirectionBarItem treemapTopRightToBottomLeftLayoutDirectionBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapTileLabelsBarItem treemapTileLabelsBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapTileLabelsNoneBarItem treemapTileLabelsNoneBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapTileLabelsArgumentBarItem treemapTileLabelsArgumentBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapTileLabelsValueBarItem treemapTileLabelsValueBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapTileLabelsArgumentAndValueBarItem treemapTileLabelsArgumentAndValueBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapTileTooltipsBarItem treemapTileTooltipsBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapTileTooltipsNoneBarItem treemapTileTooltipsNoneBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapTileTooltipsArgumentBarItem treemapTileTooltipsArgumentBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapTileTooltipsValueBarItem treemapTileTooltipsValueBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapTileTooltipsArgumentAndValueBarItem treemapTileTooltipsArgumentAndValueBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapGroupLabelsBarItem treemapGroupLabelsBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapGroupLabelsNoneBarItem treemapGroupLabelsNoneBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapGroupLabelsArgumentBarItem treemapGroupLabelsArgumentBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapGroupLabelsValueBarItem treemapGroupLabelsValueBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapGroupLabelsArgumentAndValueBarItem treemapGroupLabelsArgumentAndValueBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapGroupTooltipsBarItem treemapGroupTooltipsBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapGroupTooltipsNoneBarItem treemapGroupTooltipsNoneBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapGroupTooltipsArgumentBarItem treemapGroupTooltipsArgumentBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapGroupTooltipsValueBarItem treemapGroupTooltipsValueBarItem1;
        private DevExpress.DashboardWin.Bars.TreemapGroupTooltipsArgumentAndValueBarItem treemapGroupTooltipsArgumentAndValueBarItem1;
        private DevExpress.DashboardWin.Bars.ImageLoadBarItem imageLoadBarItem1;
        private DevExpress.DashboardWin.Bars.ImageImportBarItem imageImportBarItem1;
        private DevExpress.DashboardWin.Bars.GroupMasterFilterBarItem groupMasterFilterBarItem1;
        private DevExpress.DashboardWin.Bars.GroupIgnoreMasterFilterBarItem groupIgnoreMasterFilterBarItem1;
        private DevExpress.XtraRichEdit.UI.UndoItem undoItem1;
        private DevExpress.XtraRichEdit.UI.RedoItem redoItem1;
        private DevExpress.XtraRichEdit.UI.FileOpenItem fileOpenItem1;
        private DevExpress.XtraRichEdit.UI.PasteItem pasteItem1;
        private DevExpress.XtraRichEdit.UI.CutItem cutItem1;
        private DevExpress.XtraRichEdit.UI.CopyItem copyItem1;
        private DevExpress.XtraRichEdit.UI.PasteSpecialItem pasteSpecialItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup1;
        private DevExpress.XtraRichEdit.UI.ChangeFontNameItem changeFontNameItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemFontEdit repositoryItemFontEdit1;
        private DevExpress.XtraRichEdit.UI.ChangeFontSizeItem changeFontSizeItem1;
        private DevExpress.XtraRichEdit.Design.RepositoryItemRichEditFontSizeEdit repositoryItemRichEditFontSizeEdit1;
        private DevExpress.XtraRichEdit.UI.FontSizeIncreaseItem fontSizeIncreaseItem1;
        private DevExpress.XtraRichEdit.UI.FontSizeDecreaseItem fontSizeDecreaseItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup2;
        private DevExpress.XtraRichEdit.UI.ToggleFontBoldItem toggleFontBoldItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontItalicItem toggleFontItalicItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontUnderlineItem toggleFontUnderlineItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontDoubleUnderlineItem toggleFontDoubleUnderlineItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontStrikeoutItem toggleFontStrikeoutItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontDoubleStrikeoutItem toggleFontDoubleStrikeoutItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontSuperscriptItem toggleFontSuperscriptItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontSubscriptItem toggleFontSubscriptItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup3;
        private DevExpress.XtraRichEdit.UI.ChangeFontColorItem changeFontColorItem1;
        private DevExpress.XtraRichEdit.UI.ChangeFontHighlightColorItem changeFontHighlightColorItem1;
        private DevExpress.XtraRichEdit.UI.ChangeTextCaseItem changeTextCaseItem1;
        private DevExpress.XtraRichEdit.UI.MakeTextUpperCaseItem makeTextUpperCaseItem1;
        private DevExpress.XtraRichEdit.UI.MakeTextLowerCaseItem makeTextLowerCaseItem1;
        private DevExpress.XtraRichEdit.UI.CapitalizeEachWordCaseItem capitalizeEachWordCaseItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTextCaseItem toggleTextCaseItem1;
        private DevExpress.XtraRichEdit.UI.ClearFormattingItem clearFormattingItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup4;
        private DevExpress.XtraRichEdit.UI.ToggleBulletedListItem toggleBulletedListItem1;
        private DevExpress.XtraRichEdit.UI.ToggleNumberingListItem toggleNumberingListItem1;
        private DevExpress.XtraRichEdit.UI.ToggleMultiLevelListItem toggleMultiLevelListItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup5;
        private DevExpress.XtraRichEdit.UI.DecreaseIndentItem decreaseIndentItem1;
        private DevExpress.XtraRichEdit.UI.IncreaseIndentItem increaseIndentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleShowWhitespaceItem toggleShowWhitespaceItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup6;
        private DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentLeftItem toggleParagraphAlignmentLeftItem1;
        private DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentCenterItem toggleParagraphAlignmentCenterItem1;
        private DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentRightItem toggleParagraphAlignmentRightItem1;
        private DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentJustifyItem toggleParagraphAlignmentJustifyItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup7;
        private DevExpress.XtraRichEdit.UI.ChangeParagraphLineSpacingItem changeParagraphLineSpacingItem1;
        private DevExpress.XtraRichEdit.UI.SetSingleParagraphSpacingItem setSingleParagraphSpacingItem1;
        private DevExpress.XtraRichEdit.UI.SetSesquialteralParagraphSpacingItem setSesquialteralParagraphSpacingItem1;
        private DevExpress.XtraRichEdit.UI.SetDoubleParagraphSpacingItem setDoubleParagraphSpacingItem1;
        private DevExpress.XtraRichEdit.UI.ShowLineSpacingFormItem showLineSpacingFormItem1;
        private DevExpress.XtraRichEdit.UI.AddSpacingBeforeParagraphItem addSpacingBeforeParagraphItem1;
        private DevExpress.XtraRichEdit.UI.RemoveSpacingBeforeParagraphItem removeSpacingBeforeParagraphItem1;
        private DevExpress.XtraRichEdit.UI.AddSpacingAfterParagraphItem addSpacingAfterParagraphItem1;
        private DevExpress.XtraRichEdit.UI.RemoveSpacingAfterParagraphItem removeSpacingAfterParagraphItem1;
        private DevExpress.XtraRichEdit.UI.ChangeParagraphBackColorItem changeParagraphBackColorItem1;
        private DevExpress.XtraRichEdit.UI.GalleryChangeStyleItem galleryChangeStyleItem1;
        private DevExpress.XtraRichEdit.UI.FindItem findItem1;
        private DevExpress.XtraRichEdit.UI.ReplaceItem replaceItem1;
        private DevExpress.XtraRichEdit.UI.InsertTableItem insertTableItem1;
        private DevExpress.XtraRichEdit.UI.InsertPictureItem insertPictureItem1;
        private DevExpress.XtraRichEdit.UI.InsertFloatingPictureItem insertFloatingPictureItem1;
        private DevExpress.XtraRichEdit.UI.InsertBookmarkItem insertBookmarkItem1;
        private DevExpress.XtraRichEdit.UI.InsertHyperlinkItem insertHyperlinkItem1;
        private DevExpress.XtraRichEdit.UI.InsertSymbolItem insertSymbolItem1;
        private DevExpress.XtraRichEdit.UI.ChangePageColorItem changePageColorItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFirstRowItem toggleFirstRowItem1;
        private DevExpress.XtraRichEdit.UI.ToggleLastRowItem toggleLastRowItem1;
        private DevExpress.XtraRichEdit.UI.ToggleBandedRowsItem toggleBandedRowsItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFirstColumnItem toggleFirstColumnItem1;
        private DevExpress.XtraRichEdit.UI.ToggleLastColumnItem toggleLastColumnItem1;
        private DevExpress.XtraRichEdit.UI.ToggleBandedColumnsItem toggleBandedColumnsItem1;
        private DevExpress.XtraRichEdit.UI.GalleryChangeTableStyleItem galleryChangeTableStyleItem1;
        private DevExpress.XtraRichEdit.UI.ChangeTableBorderLineStyleItem changeTableBorderLineStyleItem1;
        private DevExpress.XtraRichEdit.Forms.Design.RepositoryItemBorderLineStyle repositoryItemBorderLineStyle1;
        private DevExpress.XtraRichEdit.UI.ChangeTableBorderLineWeightItem changeTableBorderLineWeightItem1;
        private DevExpress.XtraRichEdit.Forms.Design.RepositoryItemBorderLineWeight repositoryItemBorderLineWeight1;
        private DevExpress.XtraRichEdit.UI.ChangeTableBorderColorItem changeTableBorderColorItem1;
        private DevExpress.XtraRichEdit.UI.ChangeTableBordersItem changeTableBordersItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomBorderItem toggleTableCellsBottomBorderItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsTopBorderItem toggleTableCellsTopBorderItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsLeftBorderItem toggleTableCellsLeftBorderItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsRightBorderItem toggleTableCellsRightBorderItem1;
        private DevExpress.XtraRichEdit.UI.ResetTableCellsAllBordersItem resetTableCellsAllBordersItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsAllBordersItem toggleTableCellsAllBordersItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsOutsideBorderItem toggleTableCellsOutsideBorderItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsInsideBorderItem toggleTableCellsInsideBorderItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsInsideHorizontalBorderItem toggleTableCellsInsideHorizontalBorderItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsInsideVerticalBorderItem toggleTableCellsInsideVerticalBorderItem1;
        private DevExpress.XtraRichEdit.UI.ToggleShowTableGridLinesItem toggleShowTableGridLinesItem1;
        private DevExpress.XtraRichEdit.UI.ChangeTableCellsShadingItem changeTableCellsShadingItem1;
        private DevExpress.XtraRichEdit.UI.SelectTableElementsItem selectTableElementsItem1;
        private DevExpress.XtraRichEdit.UI.SelectTableCellItem selectTableCellItem1;
        private DevExpress.XtraRichEdit.UI.SelectTableColumnItem selectTableColumnItem1;
        private DevExpress.XtraRichEdit.UI.SelectTableRowItem selectTableRowItem1;
        private DevExpress.XtraRichEdit.UI.SelectTableItem selectTableItem1;
        private DevExpress.XtraRichEdit.UI.ShowTablePropertiesFormItem showTablePropertiesFormItem1;
        private DevExpress.XtraRichEdit.UI.DeleteTableElementsItem deleteTableElementsItem1;
        private DevExpress.XtraRichEdit.UI.ShowDeleteTableCellsFormItem showDeleteTableCellsFormItem1;
        private DevExpress.XtraRichEdit.UI.DeleteTableColumnsItem deleteTableColumnsItem1;
        private DevExpress.XtraRichEdit.UI.DeleteTableRowsItem deleteTableRowsItem1;
        private DevExpress.XtraRichEdit.UI.DeleteTableItem deleteTableItem1;
        private DevExpress.XtraRichEdit.UI.InsertTableRowAboveItem insertTableRowAboveItem1;
        private DevExpress.XtraRichEdit.UI.InsertTableRowBelowItem insertTableRowBelowItem1;
        private DevExpress.XtraRichEdit.UI.InsertTableColumnToLeftItem insertTableColumnToLeftItem1;
        private DevExpress.XtraRichEdit.UI.InsertTableColumnToRightItem insertTableColumnToRightItem1;
        private DevExpress.XtraRichEdit.UI.MergeTableCellsItem mergeTableCellsItem1;
        private DevExpress.XtraRichEdit.UI.ShowSplitTableCellsForm showSplitTableCellsForm1;
        private DevExpress.XtraRichEdit.UI.SplitTableItem splitTableItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableAutoFitItem toggleTableAutoFitItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableAutoFitContentsItem toggleTableAutoFitContentsItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableAutoFitWindowItem toggleTableAutoFitWindowItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableFixedColumnWidthItem toggleTableFixedColumnWidthItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsTopLeftAlignmentItem toggleTableCellsTopLeftAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsMiddleLeftAlignmentItem toggleTableCellsMiddleLeftAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomLeftAlignmentItem toggleTableCellsBottomLeftAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsTopCenterAlignmentItem toggleTableCellsTopCenterAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsMiddleCenterAlignmentItem toggleTableCellsMiddleCenterAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomCenterAlignmentItem toggleTableCellsBottomCenterAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsTopRightAlignmentItem toggleTableCellsTopRightAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsMiddleRightAlignmentItem toggleTableCellsMiddleRightAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomRightAlignmentItem toggleTableCellsBottomRightAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ShowTableOptionsFormItem showTableOptionsFormItem1;
        private DevExpress.XtraRichEdit.UI.ChangeFloatingObjectFillColorItem changeFloatingObjectFillColorItem1;
        private DevExpress.XtraRichEdit.UI.ChangeFloatingObjectOutlineColorItem changeFloatingObjectOutlineColorItem1;
        private DevExpress.XtraRichEdit.UI.ChangeFloatingObjectOutlineWeightItem changeFloatingObjectOutlineWeightItem1;
        private DevExpress.XtraRichEdit.Forms.Design.RepositoryItemFloatingObjectOutlineWeight repositoryItemFloatingObjectOutlineWeight1;
        private DevExpress.XtraRichEdit.UI.ChangeFloatingObjectTextWrapTypeItem changeFloatingObjectTextWrapTypeItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectSquareTextWrapTypeItem setFloatingObjectSquareTextWrapTypeItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectTightTextWrapTypeItem setFloatingObjectTightTextWrapTypeItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectThroughTextWrapTypeItem setFloatingObjectThroughTextWrapTypeItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectTopAndBottomTextWrapTypeItem setFloatingObjectTopAndBottomTextWrapTypeItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectBehindTextWrapTypeItem setFloatingObjectBehindTextWrapTypeItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectInFrontOfTextWrapTypeItem setFloatingObjectInFrontOfTextWrapTypeItem1;
        private DevExpress.XtraRichEdit.UI.ChangeFloatingObjectAlignmentItem changeFloatingObjectAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectTopLeftAlignmentItem setFloatingObjectTopLeftAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectTopCenterAlignmentItem setFloatingObjectTopCenterAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectTopRightAlignmentItem setFloatingObjectTopRightAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectMiddleLeftAlignmentItem setFloatingObjectMiddleLeftAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectMiddleCenterAlignmentItem setFloatingObjectMiddleCenterAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectMiddleRightAlignmentItem setFloatingObjectMiddleRightAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectBottomLeftAlignmentItem setFloatingObjectBottomLeftAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectBottomCenterAlignmentItem setFloatingObjectBottomCenterAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectBottomRightAlignmentItem setFloatingObjectBottomRightAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectBringForwardSubItem floatingObjectBringForwardSubItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectBringForwardItem floatingObjectBringForwardItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectBringToFrontItem floatingObjectBringToFrontItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectBringInFrontOfTextItem floatingObjectBringInFrontOfTextItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectSendBackwardSubItem floatingObjectSendBackwardSubItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectSendBackwardItem floatingObjectSendBackwardItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectSendToBackItem floatingObjectSendToBackItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectSendBehindTextItem floatingObjectSendBehindTextItem1;
        private DevExpress.DashboardWin.Bars.TreemapLayoutRibbonPageGroup treemapLayoutRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.TreemapTileLabelsRibbonPageGroup treemapTileLabelsRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.TreemapGroupLabelsRibbonPageGroup treemapGroupLabelsRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.ColoringOptionsRibbonPageGroup coloringOptionsRibbonPageGroup6;
        private DevExpress.DashboardWin.Bars.ImageToolsRibbonPageCategory imageToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage17;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup17;
        private DevExpress.DashboardWin.Bars.ImageOpenRibbonPageGroup imageOpenRibbonPageGroup1;
        private DevExpress.DashboardWin.Bars.ImageSizeModeRibbonPageGroup imageSizeModeRibbonPageGroup2;
        private DevExpress.DashboardWin.Bars.ImageAlignmentRibbonPageGroup imageAlignmentRibbonPageGroup2;
        private DevExpress.DashboardWin.Bars.GroupToolsRibbonPageCategory groupToolsRibbonPageCategory1;
        private DevExpress.DashboardWin.Bars.DataRibbonPage dataRibbonPage17;
        private DevExpress.DashboardWin.Bars.MasterFilterRibbonPageGroup masterFilterRibbonPageGroup12;
        private DevExpress.DashboardWin.Bars.DashboardItemDesignRibbonPage dashboardItemDesignRibbonPage18;
        private DevExpress.DashboardWin.Bars.CommonItemDesignRibbonPageGroup commonItemDesignRibbonPageGroup18;
        private DevExpress.DashboardWin.Bars.TextBoxEditorRibbonPageCategory textBoxEditorRibbonPageCategory1;
        private DevExpress.XtraRichEdit.UI.FileRibbonPage fileRibbonPage1;
        private DevExpress.XtraRichEdit.UI.CommonRibbonPageGroup commonRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.HomeRibbonPage homeRibbonPage2;
        private DevExpress.XtraRichEdit.UI.ClipboardRibbonPageGroup clipboardRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.FontRibbonPageGroup fontRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.ParagraphRibbonPageGroup paragraphRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.StylesRibbonPageGroup stylesRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.EditingRibbonPageGroup editingRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.InsertRibbonPage insertRibbonPage1;
        private DevExpress.XtraRichEdit.UI.TablesRibbonPageGroup tablesRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.IllustrationsRibbonPageGroup illustrationsRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.LinksRibbonPageGroup linksRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.SymbolsRibbonPageGroup symbolsRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.PageLayoutRibbonPage pageLayoutRibbonPage1;
        private DevExpress.XtraRichEdit.UI.PageBackgroundRibbonPageGroup pageBackgroundRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableDesignRibbonPage tableDesignRibbonPage1;
        private DevExpress.XtraRichEdit.UI.TableStyleOptionsRibbonPageGroup tableStyleOptionsRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableStylesRibbonPageGroup tableStylesRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableDrawBordersRibbonPageGroup tableDrawBordersRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableLayoutRibbonPage tableLayoutRibbonPage1;
        private DevExpress.XtraRichEdit.UI.TableTableRibbonPageGroup tableTableRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableRowsAndColumnsRibbonPageGroup tableRowsAndColumnsRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableMergeRibbonPageGroup tableMergeRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableCellSizeRibbonPageGroup tableCellSizeRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableAlignmentRibbonPageGroup tableAlignmentRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.FloatingPictureToolsFormatPage floatingPictureToolsFormatPage1;
        private DevExpress.XtraRichEdit.UI.FloatingPictureToolsShapeStylesPageGroup floatingPictureToolsShapeStylesPageGroup1;
        private DevExpress.XtraRichEdit.UI.FloatingPictureToolsArrangePageGroup floatingPictureToolsArrangePageGroup1;
        private DevExpress.DashboardWin.DashboardPopupMenu dashboardPopupMenu1;
        private DevExpress.DashboardWin.Bars.TextBoxEditorBarController textBoxEditorBarController1;
    }
}