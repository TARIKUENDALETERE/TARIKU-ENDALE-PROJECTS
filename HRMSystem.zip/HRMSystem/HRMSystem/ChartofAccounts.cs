﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.OleDb;
namespace HRMSystem
{
    public partial class ChartofAccounts : DevExpress.XtraEditors.XtraForm
    {
        string con = ConfigurationManager.ConnectionStrings["HRMS"].ToString();
        public ChartofAccounts()
        {
            InitializeComponent();
        }

        private void groupControl1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" & textBox2.Text == "")
            {
                MessageBox.Show("Please Fill both Required Fields!", "HRMS Application", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                using (SqlConnection cn = new SqlConnection(con))
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO ChartofAccounts VALUES('" + textBox1.Text + "','" + textBox2.Text + "','" + DateTime.Now.ToShortDateString() + "')", cn);
                    cmd.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Chart of Account Successfully Added!", "HRMS Application", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    gridControl1.RefreshDataSource();
                }
                this.Refresh();
            }
        }
        private void ChartofAccounts_Load(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM HRMS.dbo.ChartofAccounts", cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                gridControl1.DataSource = dt;
            }
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void simpleButton3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please Fill the first TextBox infront of Chart Account to Delete!", "HRMS Application", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                using (SqlConnection cn = new SqlConnection(con))
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand("Delete from HRMS.dbo.ChartofAccounts where  HRMS.dbo.ChartofAccounts.caid='" + textBox1.Text + "'", cn);
                    cmd.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Data with '" + textBox1.Text + "' ID has been deleted successfully!", "HRMS Application", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

    }
}