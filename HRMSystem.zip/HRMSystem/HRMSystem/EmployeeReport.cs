﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace HRMSystem
{
    public partial class EmployeeReport : DevExpress.XtraEditors.XtraForm
    {
        public EmployeeReport()
        {
            InitializeComponent();
        }
    }
}