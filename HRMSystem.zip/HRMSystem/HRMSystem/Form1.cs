﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
namespace HRMSystem
{
    public partial class Form1 : DevExpress.XtraEditors.XtraForm
    {
        string con = ConfigurationManager.ConnectionStrings["HRMS"].ToString();
        public Form1()
        {
            InitializeComponent();
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            this.textBox2.UseSystemPasswordChar = true;
        }

        private void pictureEdit3_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "") && (this.textBox2.Text == ""))
            {
                MessageBox.Show("Please Fill the Fields with Correct UserName and Password!", "HRMS Application", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if ((textBox1.Text != "") && (this.textBox2.Text == ""))
            {
                MessageBox.Show("You left the Password Empty! Please Fill it to Proceed!","HRMS Application",  MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if((textBox1.Text == "") && (this.textBox2.Text != ""))
            {
                MessageBox.Show("You left UserName Empty! Please Fill it to Proceed!", "HRMS Application",  MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                using (SqlConnection cn = new SqlConnection(con))
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand("select UserName,Email,Password from HRMS.dbo.Employee where HRMS.dbo.Employee.UserName='" + textBox1.Text + "' and HRMS.dbo.Employee.Password='" + textBox2.Text + "'", cn);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        Form2 f2 = new Form2();
                        f2.Text = "Human Resource Management System-" + textBox1.Text;
                        f2.Show();
                    }
                        
                    else

                    {
                        MessageBox.Show("You tried to login with wrong username and Password. Please Contact your System Administrator!", "HRMS Application", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        this.Show();
                    }
                }
            }
        }
    }
}
