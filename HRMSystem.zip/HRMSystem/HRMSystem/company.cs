﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;
namespace HRMSystem
{
    public partial class company : DevExpress.XtraEditors.XtraForm
    {
        string oldText = string.Empty;
        string con = ConfigurationManager.ConnectionStrings["HRMS"].ToString();
        static string filename;
        public company()
        {
            InitializeComponent();
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            string saveDirectory = Path.GetDirectoryName(Application.ExecutablePath) + @"image";
            using (OpenFileDialog openFileDialog1 = new OpenFileDialog())
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    if (!Directory.Exists(saveDirectory))
                    {
                        Directory.CreateDirectory(saveDirectory);
                    }
                    filename = Path.GetFileName(openFileDialog1.FileName);
                    string FileSave = Path.Combine(saveDirectory, filename);
                    File.Copy(openFileDialog1.FileName, FileSave, true);
                    pictureBox1.Image = new Bitmap(openFileDialog1.FileName);
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    //textBox1.Text = filename.ToString();
                }
            }
        }

        private void labelControl7_Click(object sender, EventArgs e)
        {

        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
                    
        }

        private void simpleButton2_Click_1(object sender, EventArgs e)
        {
            if (cn.Text == "" & sim.Text == "" & maqaa.Text == "" & ad.Text == "" & tn.Text == "" & mn.Text == "" & fn.Text == "" & email.Text == "" & web.Text == "" & box.Text == "")
            {
                MessageBox.Show("Please Fill all the Required Fields to add a Company!", "HRMS Application!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                using (SqlConnection cnn = new SqlConnection(con))
                {
                    cnn.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO HRMS.dbo.Company VALUES('" + Path.GetFileName(filename).ToString() + "','" + cn.Text + "','" + sim.Text + "','" + maqaa.Text + "','" + ad.Text + "','" + tn.Text + "','" + mn.Text + "','" + fn.Text + "','" + email.Text + "','" + web.Text + "','" + box.Text + "')", cnn);
                    cmd.ExecuteNonQuery();
                    cnn.Close();
                    MessageBox.Show("The Company has been added Successfully!", "HRMS Application!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        private void company_Load(object sender, EventArgs e)
        {
            using (SqlConnection cnn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select * from HRMS.dbo.Company", cnn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                gridControl1.DataSource = dt;
                
            }
        }

        private void gridControl1_Click(object sender, EventArgs e)
        {

        }

        private void simpleButton3_Click(object sender, EventArgs e)
        {
            cn.Clear();
            sim.Clear();
            maqaa.Clear();
            ad.Clear();
            tn.Clear();
            mn.Clear();
            fn.Clear();
            box.Clear();
            web.Clear();
            email.Clear();

        }

        private void simpleButton4_Click(object sender, EventArgs e)
        {
            cn.ClearUndo();
            sim.ClearUndo();
            maqaa.ClearUndo();
            ad.ClearUndo();
            tn.ClearUndo();
            mn.ClearUndo();
            fn.ClearUndo();
            box.ClearUndo();
            web.ClearUndo();
            email.ClearUndo();
        }
    }
}