﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;
using AForge.Video;
using AForge.Video.DirectShow;
namespace HRMSystem
{
    public partial class employeeregistration : DevExpress.XtraEditors.XtraForm
    {
        string oldText = string.Empty;
        string con = ConfigurationManager.ConnectionStrings["HRMS"].ToString();
        static string filename;
        FilterInfoCollection filterInfoCollection;
        VideoCaptureDevice videoCaptureDevice;
        
        public employeeregistration()
        {
            InitializeComponent();
        }

        private void employeeregistration_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(con))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT CID FROM HRMS.dbo.Company", conn);
                SqlDataAdapter sad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sad.Fill(dt);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    // Label2.Text = dr["Maqaa"].ToString();
                    cid.Items.Add(dr["CID"].ToString());
                    //Label3.Text = "Contact Details:  Tele: " + dr["Telephone"].ToString();
                }
            }
            using (SqlConnection conn = new SqlConnection(con))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT Position FROM HRMS.dbo.Position", conn);
                SqlDataAdapter sad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sad.Fill(dt);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    // Label2.Text = dr["Maqaa"].ToString();
                    ce.Items.Add(dr["Position"].ToString());
                    //Label3.Text = "Contact Details:  Tele: " + dr["Telephone"].ToString();
                }
            }
            using (SqlConnection conn = new SqlConnection(con))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT sid FROM HRMS.dbo.School", conn);
                SqlDataAdapter sad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sad.Fill(dt);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    // Label2.Text = dr["Maqaa"].ToString();
                    sid.Items.Add(dr["sid"].ToString());
                    //Label3.Text = "Contact Details:  Tele: " + dr["Telephone"].ToString();
                }
            }
            filterInfoCollection = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo filterinfo in filterInfoCollection)
            {
                cam.Items.Add(filterinfo.Name);
                cam.SelectedIndex = 0;
                videoCaptureDevice = new VideoCaptureDevice();
            }
            using (SqlConnection cn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select HRMS.dbo.Employee.EID,HRMS.dbo.Employee.EMPID,HRMS.dbo.Employee.FirstName,HRMS.dbo.Employee.MiddleName,HRMS.dbo.Employee.LastName,HRMS.dbo.Employee.Sex as Gender, HRMS.dbo.Employee.Educational_Level as [Educational Level],HRMS.dbo.Employee.Current_Position as [Position], HRMS.dbo.Employee.Email from HRMS.dbo.Employee", cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                gridControl1.DataSource = dt;
                //gridControl1.DataBindings();

            }
            }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string saveDirectory = Path.GetDirectoryName(Application.ExecutablePath) + @"image";
            using (OpenFileDialog openFileDialog1 = new OpenFileDialog())
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    if (!Directory.Exists(saveDirectory))
                    {
                        Directory.CreateDirectory(saveDirectory);
                    }
                    filename = Path.GetFileName(openFileDialog1.FileName);
                    string FileSave = Path.Combine(saveDirectory, filename);
                    File.Copy(openFileDialog1.FileName, FileSave, true);
                    pic.Image = new Bitmap(openFileDialog1.FileName);
                    pic.SizeMode = PictureBoxSizeMode.StretchImage;
                    //textBox1.Text = filename.ToString();
                }
            }
        }
        
        private void simpleButton1_Click(object sender, EventArgs e)
        {
            videoCaptureDevice = new VideoCaptureDevice(filterInfoCollection[cam.SelectedIndex].MonikerString);
            videoCaptureDevice.NewFrame += VideoCaptureDevice_NewFrame;
            videoCaptureDevice.Start();

        }
        private void VideoCaptureDevice_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            pic.Image = (Bitmap)eventArgs.Frame.Clone();
        }
        private void fn_TextChanged(object sender, EventArgs e)
        {
            if (fn.Text.All(chr => char.IsLetter(chr)))
            {
                oldText = fn.Text;
                fn.Text = oldText;

                fn.BackColor = System.Drawing.Color.White;
                fn.ForeColor = System.Drawing.Color.Black;
            }
            else
            {
                fn.Text = oldText;
                fn.BackColor = System.Drawing.Color.Red;
                fn.ForeColor = System.Drawing.Color.White;
            }

        }

        private void mn_TextChanged(object sender, EventArgs e)
        {
            if (mn.Text.All(chr => char.IsLetter(chr)))
            {
                oldText = mn.Text;
                mn.Text = oldText;

                mn.BackColor = System.Drawing.Color.White;
                mn.ForeColor = System.Drawing.Color.Black;
            }
            else
            {
                mn.Text = oldText;
                mn.BackColor = System.Drawing.Color.Red;
                mn.ForeColor = System.Drawing.Color.White;
            }

        }

        private void ln_TextChanged(object sender, EventArgs e)
        {
            if (ln.Text.All(chr => char.IsLetter(chr)))
            {
                oldText = ln.Text;
                ln.Text = oldText;

                ln.BackColor = System.Drawing.Color.White;
                ln.ForeColor = System.Drawing.Color.Black;
            }
            else
            {
                ln.Text = oldText;
                ln.BackColor = System.Drawing.Color.Red;
                ln.ForeColor = System.Drawing.Color.White;
            }

        }

        private void dob_ValueChanged(object sender, EventArgs e)
        {
            int year = dob.Value.Year;
            int cyear = DateTime.Now.Year;
            if (dob.Value.ToShortDateString() != "")
            {
                age.Text = Convert.ToString(cyear - year);
            }
        }

        private void simpleButton4_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    doc.Text = ofd.FileName;
                }
            }
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
          
            using (SqlConnection cn = new SqlConnection(con))
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO HRMS.dbo.Employee Select '" + Path.GetFileName(filename).ToString() + "',concat(substring(HRMS.dbo.Company.Name,1,1),substring(HRMS.dbo.Company.Name,2,1),'/',substring(HRMS.dbo.School.Name,1,1),substring(HRMS.dbo.School.Name,2,1),'/',Max(HRMS.dbo.Employee.EID)+1,'/',year(getdate())),'" + fn.Text + "','" + mn.Text + "','" + ln.Text + "','" + sex.Text + "','" + dob.Value.ToShortDateString() + "','" + age.Text + "','" + pob.Text + "','" + ca.Text + "','" + el.Text + "','" + mru.Text + "','" + gd.Value.ToShortDateString() + "','" + te.Text + "','" + ce.Text + "','" + gs.Text + "','" + email.Text + "','" + un.Text + "','" + pd.Text + "','" + doc.Text + "','" + DateTime.Now.ToShortDateString() + "','" + cid.Text + "','" + sid.Text + "' from HRMS.dbo.Company  inner join HRMS.dbo.Employee ON HRMS.dbo.Company.CID='" + cid.Text + "' inner join HRMS.dbo.School ON HRMS.dbo.School.sid='"+sid.Text+"' GROUP BY HRMS.dbo.Company.Name,HRMS.dbo.Employee.EID,HRMS.dbo.Company.CID,HRMS.dbo.School.Name", cn); 
                cmd.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Employee has been added Successfully!", "HRMS Application", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            
        }

        private void employeeregistration_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (videoCaptureDevice.IsRunning == true)
            {
                videoCaptureDevice.Stop();
            }
        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void simpleButton3_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select HRMS.dbo.Employee.EID,HRMS.dbo.Employee.EMPID,HRMS.dbo.Employee.FirstName,HRMS.dbo.Employee.MiddleName,HRMS.dbo.Employee.LastName,HRMS.dbo.Employee.Sex as Gender, HRMS.dbo.Employee.Educational_Level as [Educational Level],HRMS.dbo.Employee.Current_Position as [Position], HRMS.dbo.Employee.Email from HRMS.dbo.Employee WHERE HRMS.dbo.Employee.FirstName like '%"+textBox1.Text+"%'", cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                gridControl1.DataSource = dt;
            }
        }

       
    }
}