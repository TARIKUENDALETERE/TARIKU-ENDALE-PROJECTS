﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.OleDb;
namespace HRMSystem
{
    public partial class income : DevExpress.XtraEditors.XtraForm
    {
        string con = ConfigurationManager.ConnectionStrings["HRMS"].ToString();
        public income()
        {
            InitializeComponent();
        }

        private void income_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(con))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT Chart_Account FROM HRMS.dbo.ChartofAccounts", conn);
                SqlDataAdapter sad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sad.Fill(dt);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    // Label2.Text = dr["Maqaa"].ToString();
                    comboBox1.Items.Add(dr["Chart_Account"].ToString());
                    //Label3.Text = "Contact Details:  Tele: " + dr["Telephone"].ToString();
                }
            }
            using (SqlConnection conn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM HRMS.dbo.income", conn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                gridControl1.DataSource = dt;
            }
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection(con))
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO HRMS.dbo.income VALUES('" + comboBox1.Text + "','" + textBox1.Text + "','" + textBox2.Text + "','" + DateTime.Now.ToShortDateString() + "','" + DateTime.Now.ToShortTimeString() + "')", cn);
                cmd.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("You added the Income Successfully!", "HRMS", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            textBox1.Clear();
        }
    }
}