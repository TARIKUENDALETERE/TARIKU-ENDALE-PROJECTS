﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;
namespace HRMSystem
{
    public partial class AddBankAccount : DevExpress.XtraEditors.XtraForm
    {
        string con = ConfigurationManager.ConnectionStrings["HRMS"].ToString();
        string oldText = string.Empty;
        public AddBankAccount()
        {
            InitializeComponent();
        }

        private void AddBankAccount_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(con))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT CID FROM HRMS.dbo.Company", conn);
                SqlDataAdapter sad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sad.Fill(dt);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    // Label2.Text = dr["Maqaa"].ToString();
                    comboBox1.Items.Add(dr["CID"].ToString());
                    //Label3.Text = "Contact Details:  Tele: " + dr["Telephone"].ToString();
                }

            }
        
            using (SqlConnection conn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM HRMS.dbo.Bank_Accounts", conn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                gridControl1.DataSource = dt;
            }
        }
        private void simpleButton1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "")
            {
                MessageBox.Show("Please Fill the following Information to Add a Bank Account!", "HRMS Application", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                using (SqlConnection cn = new SqlConnection(con))
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO HRMS.dbo.Bank_Accounts VALUES ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + comboBox1.Text + "')", cn);
                    cmd.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("You added a Bank Account Successfully!", "HRMS Application", MessageBoxButtons.OK, MessageBoxIcon.Information);


                }
            }
        }
        private void simpleButton2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.All(chr => char.IsLetter(chr)))
            {
                oldText = textBox1.Text;
                textBox1.Text = oldText;

                textBox1.BackColor = System.Drawing.Color.White;
                textBox1.ForeColor = System.Drawing.Color.Black;
            }
            else
            {
                textBox1.Text = oldText;
                textBox1.BackColor = System.Drawing.Color.Red;
                textBox1.ForeColor = System.Drawing.Color.White;
            }
        }
    }
}