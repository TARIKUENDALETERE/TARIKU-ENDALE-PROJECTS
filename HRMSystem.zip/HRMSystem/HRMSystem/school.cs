﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
namespace HRMSystem
{
    public partial class school : DevExpress.XtraEditors.XtraForm
    {
        string oldText = string.Empty;
        string con = ConfigurationManager.ConnectionStrings["HRMS"].ToString();
        static string filename;
        public school()
        {
            InitializeComponent();
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection(con))
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO HRMS.dbo.School VALUES('"+Path.GetFileName(filename).ToString()+"','"+sn.Text+"','"+sim.Text+"','"+maqaa.Text+"','"+sa.Text+"','"+sw.Text+"','"+st.Text+"','"+sl.Text+"','"+tn.Text+"','"+mn.Text+"','"+fn.Text+"','"+box.Text+"','"+sid.Text+"','"+cid.Text+"','"+DateTime.Now.ToShortDateString()+"')", cn);
                cmd.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("School has been added to the database successfully!", "HRMS Application!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void labelControl12_Click(object sender, EventArgs e)
        {

        }

        private void simpleButton4_Click(object sender, EventArgs e)
        {
            string saveDirectory = Path.GetDirectoryName(Application.ExecutablePath) + @"image";
            using (OpenFileDialog openFileDialog1 = new OpenFileDialog())
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    if (!Directory.Exists(saveDirectory))
                    {
                        Directory.CreateDirectory(saveDirectory);
                    }
                    filename = Path.GetFileName(openFileDialog1.FileName);
                    string FileSave = Path.Combine(saveDirectory, filename);
                    File.Copy(openFileDialog1.FileName, FileSave, true);
                    pictureBox2.Image = new Bitmap(openFileDialog1.FileName);
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                    //textBox1.Text = filename.ToString();
                }
            }
        }

        private void school_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(con))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT CID FROM HRMS.dbo.Company", conn);
                SqlDataAdapter sad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sad.Fill(dt);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    // Label2.Text = dr["Maqaa"].ToString();
                    cid.Items.Add(dr["CID"].ToString());
                    //Label3.Text = "Contact Details:  Tele: " + dr["Telephone"].ToString();
                }
            }
            using (SqlConnection conn = new SqlConnection(con))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT kid FROM HRMS.dbo.Kifleketema", conn);
                SqlDataAdapter sad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sad.Fill(dt);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    // Label2.Text = dr["Maqaa"].ToString();
                    sid.Items.Add(dr["kid"].ToString());
                    //Label3.Text = "Contact Details:  Tele: " + dr["Telephone"].ToString();
                }
            }
            using (SqlConnection cn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("  select HRMS.dbo.School.Name as [School Name],HRMS.dbo.School.Maqaa as [Name in Afan Oromo],HRMS.dbo.School.Address,HRMS.dbo.School.Type,HRMS.dbo.School.Level,HRMS.dbo.School.Telephone,HRMS.dbo.School.Mobile,HRMS.dbo.School.Fax,HRMS.dbo.School.POBox from HRMS.dbo.School", cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                gridControl1.DataSource = dt;
            }

        }
        

    }
}

