﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Entity;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Data.SqlClient;
using System.Configuration;
namespace HRMSystem
{
    public partial class OtEntry : DevExpress.XtraEditors.XtraForm
    {
        string con = ConfigurationManager.ConnectionStrings["HRMS"].ToString();
        public OtEntry()
        {
            InitializeComponent();
        }
        OverTime ot;
        private void OtEntry_Load(object sender, EventArgs e)
        {
            
            using (SqlConnection cn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select HRMS.dbo.Employee.EID,concat(HRMS.dbo.Employee.FirstName,'  ',HRMS.dbo.Employee.MiddleName,'  ',HRMS.dbo.Employee.LastName) as FullName,HRMS.dbo.Employee.Sex,HRMS.dbo.Employee.Current_Position as Position from HRMS.dbo.Employee GROUP BY HRMS.dbo.Employee.EID,HRMS.dbo.Employee.Sex,HRMS.dbo.Employee.Current_Position,HRMS.dbo.Employee.FirstName,HRMS.dbo.Employee.MiddleName,HRMS.dbo.Employee.LastName", cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView2.DataSource = dt;


            }
            using (SqlConnection cn = new SqlConnection(con))
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("select pid from HRMS.dbo.Period", cn);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    comboBox1.Items.Add(dr["pid"].ToString());
                }
            }
            dateTimePicker1.Enabled = false;
        }

        private void panelControl1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {

            
            }
        }
    }
