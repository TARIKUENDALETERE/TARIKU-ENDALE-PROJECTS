﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Data.SqlClient;
using System.Configuration;
namespace HRMSystem
{
    public partial class schooldetail : DevExpress.XtraEditors.XtraForm
    {
        string con = ConfigurationManager.ConnectionStrings["HRMS"].ToString();
        public schooldetail()
        {
            InitializeComponent();
        }

        private void schooldetail_Load(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select HRMS.dbo.School.SID,HRMS.dbo.School.Name,HRMS.dbo.School.Address,HRMS.dbo.School.Woreda,HRMS.dbo.School.Type,HRMS.dbo.School.Level,HRMS.dbo.School.Telephone,HRMS.dbo.School.Mobile,HRMS.dbo.School.Fax,HRMS.dbo.School.POBox,HRMS.dbo.KifleKetema.KKName as [Name of Subcity],HRMS.dbo.Company.Name from HRMS.dbo.School inner join HRMS.dbo.KifleKetema ON HRMS.dbo.School.kkid=HRMS.dbo.School.kkid inner join HRMS.dbo.Company ON HRMS.dbo.School.CID=HRMS.dbo.Company.CID", cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select HRMS.dbo.School.SID,HRMS.dbo.School.Name,HRMS.dbo.School.Address,HRMS.dbo.School.Woreda,HRMS.dbo.School.Type,HRMS.dbo.School.Level,HRMS.dbo.School.Telephone,HRMS.dbo.School.Mobile,HRMS.dbo.School.Fax,HRMS.dbo.School.POBox,HRMS.dbo.KifleKetema.KKName as [Name of Subcity],HRMS.dbo.Company.Name from HRMS.dbo.School inner join HRMS.dbo.KifleKetema ON HRMS.dbo.School.kkid=HRMS.dbo.School.kkid inner join HRMS.dbo.Company ON HRMS.dbo.School.CID=HRMS.dbo.Company.CID and HRMS.dbo.School.Name LIKE '%" + textBox1.Text + "%' OR HRMS.dbo.School.Telephone LIKE '%"+textBox1.Text+"%'", cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select HRMS.dbo.School.SID,HRMS.dbo.School.Name,HRMS.dbo.School.Address,HRMS.dbo.School.Woreda,HRMS.dbo.School.Type,HRMS.dbo.School.Level,HRMS.dbo.School.Telephone,HRMS.dbo.School.Mobile,HRMS.dbo.School.Fax,HRMS.dbo.School.POBox,HRMS.dbo.KifleKetema.KKName as [Name of Subcity],HRMS.dbo.Company.Name from HRMS.dbo.School inner join HRMS.dbo.KifleKetema ON HRMS.dbo.School.kkid=HRMS.dbo.School.kkid inner join HRMS.dbo.Company ON HRMS.dbo.School.CID=HRMS.dbo.Company.CID and HRMS.dbo.School.Name LIKE '%" + textBox1.Text + "%' OR HRMS.dbo.School.Telephone LIKE '%" + textBox1.Text + "%'", cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
    }
}