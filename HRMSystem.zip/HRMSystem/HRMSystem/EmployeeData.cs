﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
namespace HRMSystem
{
    public partial class EmployeeData : Form
    {
        string con = ConfigurationManager.ConnectionStrings["HRMS"].ToString();
        public EmployeeData()
        {
            InitializeComponent();
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select * from HRMS.dbo.Employee_Position", cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
                //gridControl1.DataBindings();

            }
        }
    }
}
