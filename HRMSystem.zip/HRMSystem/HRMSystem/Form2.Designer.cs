﻿namespace HRMSystem
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.filToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.designToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dashboardDesignerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportDesignerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.actionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.payrollToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeDetalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.schoolDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.dashboardViewer1 = new DevExpress.DashboardWin.DashboardViewer(this.components);
            this.addNewEmployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addSubcityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCompanyBureauToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addSchoolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.incomeRegistrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.addChartsOfAccountsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.overtimeConfigurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeReportBasedSchoolConstraintToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportBasedOnGenderCategoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardViewer1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.menuStrip1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.filToolStripMenuItem,
            this.designToolStripMenuItem,
            this.actionsToolStripMenuItem,
            this.payrollToolStripMenuItem,
            this.employeeDetalToolStripMenuItem,
            this.reportsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1370, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // filToolStripMenuItem
            // 
            this.filToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewEmployeeToolStripMenuItem,
            this.addSubcityToolStripMenuItem,
            this.addCompanyBureauToolStripMenuItem,
            this.addSchoolToolStripMenuItem,
            this.settingsToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.filToolStripMenuItem.Name = "filToolStripMenuItem";
            this.filToolStripMenuItem.Size = new System.Drawing.Size(46, 23);
            this.filToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.exitToolStripMenuItem.Checked = true;
            this.exitToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(229, 24);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // designToolStripMenuItem
            // 
            this.designToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dashboardDesignerToolStripMenuItem,
            this.reportDesignerToolStripMenuItem});
            this.designToolStripMenuItem.Name = "designToolStripMenuItem";
            this.designToolStripMenuItem.Size = new System.Drawing.Size(65, 23);
            this.designToolStripMenuItem.Text = "Design";
            // 
            // dashboardDesignerToolStripMenuItem
            // 
            this.dashboardDesignerToolStripMenuItem.Name = "dashboardDesignerToolStripMenuItem";
            this.dashboardDesignerToolStripMenuItem.Size = new System.Drawing.Size(209, 24);
            this.dashboardDesignerToolStripMenuItem.Text = "Dashboard Designer";
            this.dashboardDesignerToolStripMenuItem.Click += new System.EventHandler(this.dashboardDesignerToolStripMenuItem_Click);
            // 
            // reportDesignerToolStripMenuItem
            // 
            this.reportDesignerToolStripMenuItem.Name = "reportDesignerToolStripMenuItem";
            this.reportDesignerToolStripMenuItem.Size = new System.Drawing.Size(209, 24);
            this.reportDesignerToolStripMenuItem.Text = "Report Designer";
            this.reportDesignerToolStripMenuItem.Click += new System.EventHandler(this.reportDesignerToolStripMenuItem_Click);
            // 
            // actionsToolStripMenuItem
            // 
            this.actionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.incomeRegistrationToolStripMenuItem,
            this.toolStripMenuItem1,
            this.addChartsOfAccountsToolStripMenuItem});
            this.actionsToolStripMenuItem.Name = "actionsToolStripMenuItem";
            this.actionsToolStripMenuItem.Size = new System.Drawing.Size(77, 23);
            this.actionsToolStripMenuItem.Text = "Finance ";
            // 
            // payrollToolStripMenuItem
            // 
            this.payrollToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.overtimeConfigurationToolStripMenuItem});
            this.payrollToolStripMenuItem.Name = "payrollToolStripMenuItem";
            this.payrollToolStripMenuItem.Size = new System.Drawing.Size(67, 23);
            this.payrollToolStripMenuItem.Text = "Payroll";
            // 
            // employeeDetalToolStripMenuItem
            // 
            this.employeeDetalToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeeDetailToolStripMenuItem,
            this.schoolDetailsToolStripMenuItem});
            this.employeeDetalToolStripMenuItem.Name = "employeeDetalToolStripMenuItem";
            this.employeeDetalToolStripMenuItem.Size = new System.Drawing.Size(66, 23);
            this.employeeDetalToolStripMenuItem.Text = "Details";
            // 
            // employeeDetailToolStripMenuItem
            // 
            this.employeeDetailToolStripMenuItem.Name = "employeeDetailToolStripMenuItem";
            this.employeeDetailToolStripMenuItem.Size = new System.Drawing.Size(184, 24);
            this.employeeDetailToolStripMenuItem.Text = "Employee Detail";
            this.employeeDetailToolStripMenuItem.Click += new System.EventHandler(this.employeeDetailToolStripMenuItem_Click);
            // 
            // schoolDetailsToolStripMenuItem
            // 
            this.schoolDetailsToolStripMenuItem.Name = "schoolDetailsToolStripMenuItem";
            this.schoolDetailsToolStripMenuItem.Size = new System.Drawing.Size(184, 24);
            this.schoolDetailsToolStripMenuItem.Text = "School Details";
            this.schoolDetailsToolStripMenuItem.Click += new System.EventHandler(this.schoolDetailsToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 725);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1370, 24);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(507, 19);
            this.toolStripStatusLabel1.Text = "Human Resource Management System:  Email: endalett2022ephi@gmail.com";
            // 
            // groupControl1
            // 
            this.groupControl1.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.groupControl1.Appearance.Options.UseBackColor = true;
            this.groupControl1.AppearanceCaption.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupControl1.AppearanceCaption.FontStyleDelta = System.Drawing.FontStyle.Italic;
            this.groupControl1.AppearanceCaption.Options.UseFont = true;
            this.groupControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.groupControl1.Controls.Add(this.dashboardViewer1);
            this.groupControl1.Location = new System.Drawing.Point(0, 31);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(1370, 652);
            this.groupControl1.TabIndex = 2;
            this.groupControl1.Text = "Human Resource Management System Dashboard";
            this.groupControl1.Paint += new System.Windows.Forms.PaintEventHandler(this.groupControl1_Paint);
            // 
            // dashboardViewer1
            // 
            this.dashboardViewer1.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.dashboardViewer1.AllowDrop = true;
            this.dashboardViewer1.AllowPrintDashboardItems = true;
            this.dashboardViewer1.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashboardViewer1.Appearance.Options.UseFont = true;
            this.dashboardViewer1.AutoSize = true;
            this.dashboardViewer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dashboardViewer1.DashboardSource = new System.Uri("C:\\HRMSystem\\HRMSystem\\dashboard.xml", System.UriKind.Absolute);
            this.dashboardViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dashboardViewer1.ExcelExportOptions.ExportFilters = true;
            this.dashboardViewer1.ImageExportOptions.ExportFilters = true;
            this.dashboardViewer1.ImageExportOptions.ShowTitle = DevExpress.Utils.DefaultBoolean.True;
            this.dashboardViewer1.Location = new System.Drawing.Point(2, 26);
            this.dashboardViewer1.Margin = new System.Windows.Forms.Padding(4);
            this.dashboardViewer1.Name = "dashboardViewer1";
            this.dashboardViewer1.PopulateUnusedDataSources = true;
            this.dashboardViewer1.Size = new System.Drawing.Size(1366, 624);
            this.dashboardViewer1.TabIndex = 0;
            // 
            // addNewEmployeeToolStripMenuItem
            // 
            this.addNewEmployeeToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.addNewEmployeeToolStripMenuItem.Checked = true;
            this.addNewEmployeeToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.addNewEmployeeToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addNewEmployeeToolStripMenuItem.Image = global::HRMSystem.Properties.Resources.administrator;
            this.addNewEmployeeToolStripMenuItem.Name = "addNewEmployeeToolStripMenuItem";
            this.addNewEmployeeToolStripMenuItem.Size = new System.Drawing.Size(229, 24);
            this.addNewEmployeeToolStripMenuItem.Text = "Add New Employee";
            this.addNewEmployeeToolStripMenuItem.Click += new System.EventHandler(this.addNewEmployeeToolStripMenuItem_Click);
            // 
            // addSubcityToolStripMenuItem
            // 
            this.addSubcityToolStripMenuItem.BackColor = System.Drawing.Color.DarkCyan;
            this.addSubcityToolStripMenuItem.ForeColor = System.Drawing.Color.Cornsilk;
            this.addSubcityToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("addSubcityToolStripMenuItem.Image")));
            this.addSubcityToolStripMenuItem.Name = "addSubcityToolStripMenuItem";
            this.addSubcityToolStripMenuItem.Size = new System.Drawing.Size(229, 24);
            this.addSubcityToolStripMenuItem.Text = "Add Subcity";
            this.addSubcityToolStripMenuItem.Click += new System.EventHandler(this.addSubcityToolStripMenuItem_Click);
            // 
            // addCompanyBureauToolStripMenuItem
            // 
            this.addCompanyBureauToolStripMenuItem.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.addCompanyBureauToolStripMenuItem.Checked = true;
            this.addCompanyBureauToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.addCompanyBureauToolStripMenuItem.ForeColor = System.Drawing.Color.Cornsilk;
            this.addCompanyBureauToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("addCompanyBureauToolStripMenuItem.Image")));
            this.addCompanyBureauToolStripMenuItem.Name = "addCompanyBureauToolStripMenuItem";
            this.addCompanyBureauToolStripMenuItem.Size = new System.Drawing.Size(229, 24);
            this.addCompanyBureauToolStripMenuItem.Text = "Add Company (Bureau)";
            this.addCompanyBureauToolStripMenuItem.Click += new System.EventHandler(this.addCompanyBureauToolStripMenuItem_Click);
            // 
            // addSchoolToolStripMenuItem
            // 
            this.addSchoolToolStripMenuItem.BackColor = System.Drawing.Color.DarkGray;
            this.addSchoolToolStripMenuItem.ForeColor = System.Drawing.Color.DarkBlue;
            this.addSchoolToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("addSchoolToolStripMenuItem.Image")));
            this.addSchoolToolStripMenuItem.Name = "addSchoolToolStripMenuItem";
            this.addSchoolToolStripMenuItem.Size = new System.Drawing.Size(229, 24);
            this.addSchoolToolStripMenuItem.Text = "Add School";
            this.addSchoolToolStripMenuItem.Click += new System.EventHandler(this.addSchoolToolStripMenuItem_Click);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.settingsToolStripMenuItem.Checked = true;
            this.settingsToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.settingsToolStripMenuItem.Image = global::HRMSystem.Properties.Resources.icon_view_setting_32;
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(229, 24);
            this.settingsToolStripMenuItem.Text = "Settings";
            this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
            // 
            // incomeRegistrationToolStripMenuItem
            // 
            this.incomeRegistrationToolStripMenuItem.BackColor = System.Drawing.Color.DarkKhaki;
            this.incomeRegistrationToolStripMenuItem.Checked = true;
            this.incomeRegistrationToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.incomeRegistrationToolStripMenuItem.ForeColor = System.Drawing.Color.DarkBlue;
            this.incomeRegistrationToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("incomeRegistrationToolStripMenuItem.Image")));
            this.incomeRegistrationToolStripMenuItem.Name = "incomeRegistrationToolStripMenuItem";
            this.incomeRegistrationToolStripMenuItem.Size = new System.Drawing.Size(232, 24);
            this.incomeRegistrationToolStripMenuItem.Text = "Income Registration ";
            this.incomeRegistrationToolStripMenuItem.Click += new System.EventHandler(this.incomeRegistrationToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.toolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem1.Image")));
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(232, 24);
            this.toolStripMenuItem1.Text = "Add Banks";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // addChartsOfAccountsToolStripMenuItem
            // 
            this.addChartsOfAccountsToolStripMenuItem.BackColor = System.Drawing.Color.DarkKhaki;
            this.addChartsOfAccountsToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("addChartsOfAccountsToolStripMenuItem.Image")));
            this.addChartsOfAccountsToolStripMenuItem.Name = "addChartsOfAccountsToolStripMenuItem";
            this.addChartsOfAccountsToolStripMenuItem.Size = new System.Drawing.Size(232, 24);
            this.addChartsOfAccountsToolStripMenuItem.Text = "Add Charts of Accounts";
            this.addChartsOfAccountsToolStripMenuItem.Click += new System.EventHandler(this.addChartsOfAccountsToolStripMenuItem_Click_1);
            // 
            // overtimeConfigurationToolStripMenuItem
            // 
            this.overtimeConfigurationToolStripMenuItem.BackColor = System.Drawing.Color.DarkCyan;
            this.overtimeConfigurationToolStripMenuItem.Checked = true;
            this.overtimeConfigurationToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.overtimeConfigurationToolStripMenuItem.ForeColor = System.Drawing.Color.Cornsilk;
            this.overtimeConfigurationToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("overtimeConfigurationToolStripMenuItem.Image")));
            this.overtimeConfigurationToolStripMenuItem.Name = "overtimeConfigurationToolStripMenuItem";
            this.overtimeConfigurationToolStripMenuItem.Size = new System.Drawing.Size(233, 24);
            this.overtimeConfigurationToolStripMenuItem.Text = "Overtime Configuration";
            this.overtimeConfigurationToolStripMenuItem.Click += new System.EventHandler(this.overtimeConfigurationToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeeToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(70, 23);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // employeeToolStripMenuItem
            // 
            this.employeeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeeReportBasedSchoolConstraintToolStripMenuItem,
            this.reportBasedOnGenderCategoryToolStripMenuItem});
            this.employeeToolStripMenuItem.Name = "employeeToolStripMenuItem";
            this.employeeToolStripMenuItem.Size = new System.Drawing.Size(152, 24);
            this.employeeToolStripMenuItem.Text = "Employee";
            // 
            // employeeReportBasedSchoolConstraintToolStripMenuItem
            // 
            this.employeeReportBasedSchoolConstraintToolStripMenuItem.Name = "employeeReportBasedSchoolConstraintToolStripMenuItem";
            this.employeeReportBasedSchoolConstraintToolStripMenuItem.Size = new System.Drawing.Size(349, 24);
            this.employeeReportBasedSchoolConstraintToolStripMenuItem.Text = "Employee Report based School Constraint";
            this.employeeReportBasedSchoolConstraintToolStripMenuItem.Click += new System.EventHandler(this.employeeReportBasedSchoolConstraintToolStripMenuItem_Click);
            // 
            // reportBasedOnGenderCategoryToolStripMenuItem
            // 
            this.reportBasedOnGenderCategoryToolStripMenuItem.Name = "reportBasedOnGenderCategoryToolStripMenuItem";
            this.reportBasedOnGenderCategoryToolStripMenuItem.Size = new System.Drawing.Size(349, 24);
            this.reportBasedOnGenderCategoryToolStripMenuItem.Text = "Report based on Gender Category";
            // 
            // Form2
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.groupControl1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form2";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardViewer1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem filToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewEmployeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private System.Windows.Forms.ToolStripMenuItem designToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dashboardDesignerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportDesignerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem actionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem incomeRegistrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem addChartsOfAccountsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCompanyBureauToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addSchoolToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addSubcityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem payrollToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem overtimeConfigurationToolStripMenuItem;
        public DevExpress.DashboardWin.DashboardViewer dashboardViewer1;
        private System.Windows.Forms.ToolStripMenuItem employeeDetalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem schoolDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeReportBasedSchoolConstraintToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportBasedOnGenderCategoryToolStripMenuItem;
    }
}