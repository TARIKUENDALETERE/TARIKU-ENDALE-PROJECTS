﻿namespace HRMSystem
{
    partial class employeeregistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(employeeregistration));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.ce = new System.Windows.Forms.ComboBox();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cam = new System.Windows.Forms.ComboBox();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.cid = new System.Windows.Forms.ComboBox();
            this.simpleButton4 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton3 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.doc = new System.Windows.Forms.TextBox();
            this.un = new System.Windows.Forms.TextBox();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.te = new System.Windows.Forms.ComboBox();
            this.pd = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.TextBox();
            this.gs = new System.Windows.Forms.TextBox();
            this.gd = new System.Windows.Forms.DateTimePicker();
            this.mru = new System.Windows.Forms.TextBox();
            this.el = new System.Windows.Forms.ComboBox();
            this.ca = new System.Windows.Forms.TextBox();
            this.pob = new System.Windows.Forms.TextBox();
            this.age = new System.Windows.Forms.TextBox();
            this.dob = new System.Windows.Forms.DateTimePicker();
            this.sex = new System.Windows.Forms.ComboBox();
            this.ln = new System.Windows.Forms.TextBox();
            this.mn = new System.Windows.Forms.TextBox();
            this.fn = new System.Windows.Forms.TextBox();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.pic = new System.Windows.Forms.PictureBox();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.sid = new System.Windows.Forms.ComboBox();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 725);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1370, 24);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            this.statusStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip1_ItemClicked);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(507, 19);
            this.toolStripStatusLabel1.Text = "Human Resource Management System:  Email: endalett2022ephi@gmail.com";
            // 
            // groupControl1
            // 
            this.groupControl1.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupControl1.Appearance.Options.UseFont = true;
            this.groupControl1.AppearanceCaption.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupControl1.AppearanceCaption.Options.UseFont = true;
            this.groupControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.HotFlat;
            this.groupControl1.ButtonInterval = 5;
            this.groupControl1.CaptionImageOptions.ImageUri.Uri = "DoubleNext";
            this.groupControl1.Controls.Add(this.labelControl22);
            this.groupControl1.Controls.Add(this.sid);
            this.groupControl1.Controls.Add(this.ce);
            this.groupControl1.Controls.Add(this.labelControl21);
            this.groupControl1.Controls.Add(this.textBox1);
            this.groupControl1.Controls.Add(this.cam);
            this.groupControl1.Controls.Add(this.labelControl20);
            this.groupControl1.Controls.Add(this.cid);
            this.groupControl1.Controls.Add(this.simpleButton4);
            this.groupControl1.Controls.Add(this.simpleButton3);
            this.groupControl1.Controls.Add(this.simpleButton2);
            this.groupControl1.Controls.Add(this.doc);
            this.groupControl1.Controls.Add(this.un);
            this.groupControl1.Controls.Add(this.labelControl19);
            this.groupControl1.Controls.Add(this.te);
            this.groupControl1.Controls.Add(this.pd);
            this.groupControl1.Controls.Add(this.email);
            this.groupControl1.Controls.Add(this.gs);
            this.groupControl1.Controls.Add(this.gd);
            this.groupControl1.Controls.Add(this.mru);
            this.groupControl1.Controls.Add(this.el);
            this.groupControl1.Controls.Add(this.ca);
            this.groupControl1.Controls.Add(this.pob);
            this.groupControl1.Controls.Add(this.age);
            this.groupControl1.Controls.Add(this.dob);
            this.groupControl1.Controls.Add(this.sex);
            this.groupControl1.Controls.Add(this.ln);
            this.groupControl1.Controls.Add(this.mn);
            this.groupControl1.Controls.Add(this.fn);
            this.groupControl1.Controls.Add(this.labelControl18);
            this.groupControl1.Controls.Add(this.labelControl17);
            this.groupControl1.Controls.Add(this.labelControl16);
            this.groupControl1.Controls.Add(this.labelControl15);
            this.groupControl1.Controls.Add(this.labelControl14);
            this.groupControl1.Controls.Add(this.labelControl13);
            this.groupControl1.Controls.Add(this.labelControl12);
            this.groupControl1.Controls.Add(this.labelControl11);
            this.groupControl1.Controls.Add(this.labelControl10);
            this.groupControl1.Controls.Add(this.labelControl9);
            this.groupControl1.Controls.Add(this.labelControl8);
            this.groupControl1.Controls.Add(this.labelControl7);
            this.groupControl1.Controls.Add(this.labelControl6);
            this.groupControl1.Controls.Add(this.labelControl5);
            this.groupControl1.Controls.Add(this.labelControl4);
            this.groupControl1.Controls.Add(this.labelControl3);
            this.groupControl1.Controls.Add(this.labelControl2);
            this.groupControl1.Controls.Add(this.simpleButton1);
            this.groupControl1.Controls.Add(this.linkLabel1);
            this.groupControl1.Controls.Add(this.pic);
            this.groupControl1.Controls.Add(this.labelControl1);
            this.groupControl1.Location = new System.Drawing.Point(3, 2);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(1358, 360);
            this.groupControl1.TabIndex = 3;
            this.groupControl1.Text = "Please Fill all the required fields to add new Employee";
            // 
            // ce
            // 
            this.ce.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ce.FormattingEnabled = true;
            this.ce.Location = new System.Drawing.Point(836, 136);
            this.ce.Name = "ce";
            this.ce.Size = new System.Drawing.Size(195, 27);
            this.ce.TabIndex = 48;
            // 
            // labelControl21
            // 
            this.labelControl21.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl21.Appearance.Options.UseFont = true;
            this.labelControl21.Location = new System.Drawing.Point(1038, 297);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(206, 19);
            this.labelControl21.TabIndex = 47;
            this.labelControl21.Text = "Enter the First Name of Employee";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(1035, 322);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(227, 26);
            this.textBox1.TabIndex = 46;
            // 
            // cam
            // 
            this.cam.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cam.FormattingEnabled = true;
            this.cam.Location = new System.Drawing.Point(223, 109);
            this.cam.Name = "cam";
            this.cam.Size = new System.Drawing.Size(114, 27);
            this.cam.TabIndex = 45;
            // 
            // labelControl20
            // 
            this.labelControl20.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl20.Appearance.Options.UseFont = true;
            this.labelControl20.Location = new System.Drawing.Point(1072, 60);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(82, 19);
            this.labelControl20.TabIndex = 44;
            this.labelControl20.Text = "Company ID:";
            // 
            // cid
            // 
            this.cid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cid.FormattingEnabled = true;
            this.cid.Location = new System.Drawing.Point(1176, 55);
            this.cid.Name = "cid";
            this.cid.Size = new System.Drawing.Size(134, 27);
            this.cid.TabIndex = 43;
            // 
            // simpleButton4
            // 
            this.simpleButton4.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton4.ImageOptions.Image")));
            this.simpleButton4.Location = new System.Drawing.Point(886, 322);
            this.simpleButton4.Name = "simpleButton4";
            this.simpleButton4.Size = new System.Drawing.Size(63, 34);
            this.simpleButton4.TabIndex = 42;
            this.simpleButton4.Text = "...";
            this.simpleButton4.Click += new System.EventHandler(this.simpleButton4_Click);
            // 
            // simpleButton3
            // 
            this.simpleButton3.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleButton3.Appearance.Options.UseFont = true;
            this.simpleButton3.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton3.ImageOptions.Image")));
            this.simpleButton3.Location = new System.Drawing.Point(1268, 313);
            this.simpleButton3.Name = "simpleButton3";
            this.simpleButton3.Size = new System.Drawing.Size(85, 38);
            this.simpleButton3.TabIndex = 41;
            this.simpleButton3.Text = "Search";
            this.simpleButton3.Click += new System.EventHandler(this.simpleButton3_Click);
            // 
            // simpleButton2
            // 
            this.simpleButton2.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleButton2.Appearance.Options.UseFont = true;
            this.simpleButton2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton2.ImageOptions.Image")));
            this.simpleButton2.Location = new System.Drawing.Point(1129, 144);
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.Size = new System.Drawing.Size(181, 34);
            this.simpleButton2.TabIndex = 40;
            this.simpleButton2.Text = "Add New Employee";
            this.simpleButton2.Click += new System.EventHandler(this.simpleButton2_Click);
            // 
            // doc
            // 
            this.doc.Location = new System.Drawing.Point(432, 325);
            this.doc.Name = "doc";
            this.doc.ReadOnly = true;
            this.doc.Size = new System.Drawing.Size(448, 26);
            this.doc.TabIndex = 39;
            // 
            // un
            // 
            this.un.Location = new System.Drawing.Point(835, 251);
            this.un.Name = "un";
            this.un.Size = new System.Drawing.Size(196, 26);
            this.un.TabIndex = 38;
            // 
            // labelControl19
            // 
            this.labelControl19.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl19.Appearance.Options.UseFont = true;
            this.labelControl19.Location = new System.Drawing.Point(728, 258);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(73, 19);
            this.labelControl19.TabIndex = 37;
            this.labelControl19.Text = "User Name:";
            // 
            // te
            // 
            this.te.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.te.FormattingEnabled = true;
            this.te.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40"});
            this.te.Location = new System.Drawing.Point(835, 95);
            this.te.Name = "te";
            this.te.Size = new System.Drawing.Size(134, 27);
            this.te.TabIndex = 36;
            // 
            // pd
            // 
            this.pd.Location = new System.Drawing.Point(836, 285);
            this.pd.Name = "pd";
            this.pd.Size = new System.Drawing.Size(196, 26);
            this.pd.TabIndex = 35;
            this.pd.UseSystemPasswordChar = true;
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(835, 215);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(196, 26);
            this.email.TabIndex = 34;
            // 
            // gs
            // 
            this.gs.Location = new System.Drawing.Point(835, 180);
            this.gs.Name = "gs";
            this.gs.Size = new System.Drawing.Size(196, 26);
            this.gs.TabIndex = 33;
            // 
            // gd
            // 
            this.gd.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.gd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.gd.Location = new System.Drawing.Point(835, 53);
            this.gd.Name = "gd";
            this.gd.Size = new System.Drawing.Size(196, 26);
            this.gd.TabIndex = 30;
            // 
            // mru
            // 
            this.mru.Location = new System.Drawing.Point(513, 255);
            this.mru.Name = "mru";
            this.mru.Size = new System.Drawing.Size(196, 26);
            this.mru.TabIndex = 29;
            // 
            // el
            // 
            this.el.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.el.FormattingEnabled = true;
            this.el.Items.AddRange(new object[] {
            "Certificate",
            "TVET Graduate",
            "BSc",
            "BA",
            "MSc",
            "MA",
            "MBA",
            "PhD",
            "Post Doctoral",
            "Others"});
            this.el.Location = new System.Drawing.Point(513, 215);
            this.el.Name = "el";
            this.el.Size = new System.Drawing.Size(134, 27);
            this.el.TabIndex = 28;
            // 
            // ca
            // 
            this.ca.Location = new System.Drawing.Point(513, 176);
            this.ca.Name = "ca";
            this.ca.Size = new System.Drawing.Size(196, 26);
            this.ca.TabIndex = 27;
            // 
            // pob
            // 
            this.pob.Location = new System.Drawing.Point(513, 137);
            this.pob.Name = "pob";
            this.pob.Size = new System.Drawing.Size(196, 26);
            this.pob.TabIndex = 22;
            // 
            // age
            // 
            this.age.Location = new System.Drawing.Point(513, 96);
            this.age.Name = "age";
            this.age.ReadOnly = true;
            this.age.Size = new System.Drawing.Size(196, 26);
            this.age.TabIndex = 26;
            // 
            // dob
            // 
            this.dob.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dob.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dob.Location = new System.Drawing.Point(513, 52);
            this.dob.Name = "dob";
            this.dob.Size = new System.Drawing.Size(196, 26);
            this.dob.TabIndex = 25;
            this.dob.ValueChanged += new System.EventHandler(this.dob_ValueChanged);
            // 
            // sex
            // 
            this.sex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sex.FormattingEnabled = true;
            this.sex.Items.AddRange(new object[] {
            "",
            "Male",
            "Female",
            "Others"});
            this.sex.Location = new System.Drawing.Point(117, 254);
            this.sex.Name = "sex";
            this.sex.Size = new System.Drawing.Size(114, 27);
            this.sex.TabIndex = 24;
            // 
            // ln
            // 
            this.ln.Location = new System.Drawing.Point(117, 216);
            this.ln.Name = "ln";
            this.ln.Size = new System.Drawing.Size(220, 26);
            this.ln.TabIndex = 23;
            this.ln.TextChanged += new System.EventHandler(this.ln_TextChanged);
            // 
            // mn
            // 
            this.mn.Location = new System.Drawing.Point(117, 180);
            this.mn.Name = "mn";
            this.mn.Size = new System.Drawing.Size(220, 26);
            this.mn.TabIndex = 22;
            this.mn.TextChanged += new System.EventHandler(this.mn_TextChanged);
            // 
            // fn
            // 
            this.fn.Location = new System.Drawing.Point(117, 142);
            this.fn.Name = "fn";
            this.fn.Size = new System.Drawing.Size(220, 26);
            this.fn.TabIndex = 21;
            this.fn.TextChanged += new System.EventHandler(this.fn_TextChanged);
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl18.Appearance.Options.UseFont = true;
            this.labelControl18.Location = new System.Drawing.Point(9, 331);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(417, 19);
            this.labelControl18.TabIndex = 20;
            this.labelControl18.Text = "Please scan and attach all the documents as a single PDF Documents:";
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl17.Appearance.Options.UseFont = true;
            this.labelControl17.Location = new System.Drawing.Point(728, 292);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(61, 19);
            this.labelControl17.TabIndex = 19;
            this.labelControl17.Text = "Password";
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl16.Appearance.Options.UseFont = true;
            this.labelControl16.Location = new System.Drawing.Point(728, 223);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(36, 19);
            this.labelControl16.TabIndex = 18;
            this.labelControl16.Text = "Email:";
            // 
            // labelControl15
            // 
            this.labelControl15.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl15.Appearance.Options.UseFont = true;
            this.labelControl15.Location = new System.Drawing.Point(728, 183);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(78, 19);
            this.labelControl15.TabIndex = 17;
            this.labelControl15.Text = "Gross Salary";
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl14.Appearance.Options.UseFont = true;
            this.labelControl14.Location = new System.Drawing.Point(728, 144);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(99, 19);
            this.labelControl14.TabIndex = 16;
            this.labelControl14.Text = "Current Position";
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl13.Appearance.Options.UseFont = true;
            this.labelControl13.Location = new System.Drawing.Point(728, 103);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(102, 19);
            this.labelControl13.TabIndex = 15;
            this.labelControl13.Text = "Total Experience";
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl12.Appearance.Options.UseFont = true;
            this.labelControl12.Location = new System.Drawing.Point(728, 59);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(92, 19);
            this.labelControl12.TabIndex = 14;
            this.labelControl12.Text = "Graduate Date:";
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl11.Appearance.Options.UseFont = true;
            this.labelControl11.Location = new System.Drawing.Point(358, 262);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(142, 19);
            this.labelControl11.TabIndex = 13;
            this.labelControl11.Text = "Most Recent University";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl10.Appearance.Options.UseFont = true;
            this.labelControl10.Location = new System.Drawing.Point(358, 223);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(98, 19);
            this.labelControl10.TabIndex = 12;
            this.labelControl10.Text = "Education Level";
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl9.Appearance.Options.UseFont = true;
            this.labelControl9.Location = new System.Drawing.Point(358, 183);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(101, 19);
            this.labelControl9.TabIndex = 11;
            this.labelControl9.Text = "Current Address";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl8.Appearance.Options.UseFont = true;
            this.labelControl8.Location = new System.Drawing.Point(358, 144);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(83, 19);
            this.labelControl8.TabIndex = 10;
            this.labelControl8.Text = "Place of Birth";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl7.Appearance.Options.UseFont = true;
            this.labelControl7.Location = new System.Drawing.Point(358, 103);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(25, 19);
            this.labelControl7.TabIndex = 9;
            this.labelControl7.Text = "Age";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl6.Appearance.Options.UseFont = true;
            this.labelControl6.Location = new System.Drawing.Point(358, 59);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(79, 19);
            this.labelControl6.TabIndex = 8;
            this.labelControl6.Text = "Date of Birth";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl5.Appearance.Options.UseFont = true;
            this.labelControl5.Location = new System.Drawing.Point(9, 262);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(23, 19);
            this.labelControl5.TabIndex = 7;
            this.labelControl5.Text = "Sex";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Appearance.Options.UseFont = true;
            this.labelControl4.Location = new System.Drawing.Point(9, 223);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(67, 19);
            this.labelControl4.TabIndex = 6;
            this.labelControl4.Text = "Last Name";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Appearance.Options.UseFont = true;
            this.labelControl3.Location = new System.Drawing.Point(9, 183);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(84, 19);
            this.labelControl3.TabIndex = 5;
            this.labelControl3.Text = "Middle Name";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Appearance.Options.UseFont = true;
            this.labelControl2.Location = new System.Drawing.Point(9, 144);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(68, 19);
            this.labelControl2.TabIndex = 4;
            this.labelControl2.Text = "First Name";
            // 
            // simpleButton1
            // 
            this.simpleButton1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton1.ImageOptions.Image")));
            this.simpleButton1.Location = new System.Drawing.Point(223, 69);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(52, 36);
            this.simpleButton1.TabIndex = 3;
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(224, 43);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(56, 19);
            this.linkLabel1.TabIndex = 2;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Browse";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // pic
            // 
            this.pic.Location = new System.Drawing.Point(117, 42);
            this.pic.Name = "pic";
            this.pic.Size = new System.Drawing.Size(100, 80);
            this.pic.TabIndex = 1;
            this.pic.TabStop = false;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Appearance.Options.UseFont = true;
            this.labelControl1.Location = new System.Drawing.Point(9, 59);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(101, 19);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "Employee Image";
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.gridControl1);
            this.groupControl2.Location = new System.Drawing.Point(3, 368);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(1358, 323);
            this.groupControl2.TabIndex = 5;
            this.groupControl2.Text = "Lists of all Employee";
            // 
            // gridControl1
            // 
            this.gridControl1.EmbeddedNavigator.AllowDrop = true;
            this.gridControl1.EmbeddedNavigator.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridControl1.EmbeddedNavigator.Appearance.Options.UseFont = true;
            this.gridControl1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridControl1.Location = new System.Drawing.Point(9, 23);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(1346, 295);
            this.gridControl1.TabIndex = 0;
            this.gridControl1.UseEmbeddedNavigator = true;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsView.ShowFooter = true;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl22.Appearance.Options.UseFont = true;
            this.labelControl22.Location = new System.Drawing.Point(1082, 101);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(65, 19);
            this.labelControl22.TabIndex = 50;
            this.labelControl22.Text = "School ID:";
            // 
            // sid
            // 
            this.sid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sid.FormattingEnabled = true;
            this.sid.Location = new System.Drawing.Point(1176, 96);
            this.sid.Name = "sid";
            this.sid.Size = new System.Drawing.Size(134, 27);
            this.sid.TabIndex = 49;
            // 
            // employeeregistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.groupControl2);
            this.Controls.Add(this.groupControl1);
            this.Controls.Add(this.statusStrip1);
            this.IsMdiContainer = true;
            this.KeyPreview = true;
            this.Name = "employeeregistration";
            this.ShowIcon = false;
            this.Text = "Human Resource Management System- Employee Registration Form";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.employeeregistration_FormClosing);
            this.Load += new System.EventHandler(this.employeeregistration_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.PictureBox pic;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        public System.Windows.Forms.ComboBox sex;
        private System.Windows.Forms.TextBox ln;
        private System.Windows.Forms.TextBox mn;
        private System.Windows.Forms.TextBox fn;
        public System.Windows.Forms.TextBox ca;
        public System.Windows.Forms.TextBox pob;
        public System.Windows.Forms.TextBox age;
        public System.Windows.Forms.DateTimePicker dob;
        public System.Windows.Forms.TextBox mru;
        public System.Windows.Forms.ComboBox el;
        public System.Windows.Forms.ComboBox te;
        public System.Windows.Forms.TextBox pd;
        public System.Windows.Forms.TextBox email;
        public System.Windows.Forms.TextBox gs;
        public System.Windows.Forms.DateTimePicker gd;
        private DevExpress.XtraEditors.SimpleButton simpleButton4;
        private DevExpress.XtraEditors.SimpleButton simpleButton3;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        public System.Windows.Forms.TextBox un;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        public System.Windows.Forms.TextBox doc;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        public System.Windows.Forms.ComboBox cid;
        public System.Windows.Forms.ComboBox cam;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        public System.Windows.Forms.TextBox textBox1;
        public DevExpress.XtraGrid.GridControl gridControl1;
        public System.Windows.Forms.ComboBox ce;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        public System.Windows.Forms.ComboBox sid;
    }
}