﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
namespace HRMSystem
{
    public partial class Form3 : Form
    {
        string con = ConfigurationManager.ConnectionStrings["HRMS"].ToString();
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {


            using (SqlConnection conn = new SqlConnection(con))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT Name FROM HRMS.dbo.School", conn);
                SqlDataAdapter sad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sad.Fill(dt);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    // Label2.Text = dr["Maqaa"].ToString();
                    school.Items.Add(dr["Name"].ToString());
                    //Label3.Text = "Contact Details:  Tele: " + dr["Telephone"].ToString();
                }
            }
            using (SqlConnection conn = new SqlConnection(con))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT Position FROM HRMS.dbo.Position", conn);
                SqlDataAdapter sad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sad.Fill(dt);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    // Label2.Text = dr["Maqaa"].ToString();
                    po.Items.Add(dr["Position"].ToString());
                    //Label3.Text = "Contact Details:  Tele: " + dr["Telephone"].ToString();
                }
            }
            using (SqlConnection cn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select distinct HRMS.dbo.Employee_All_Report.SchoolName,HRMS.dbo.Female.[Total Female] as Female,HRMS.dbo.Male.[Total Male] as Male from HRMS.dbo.Employee_All_Report Inner join HRMS.dbo.Female on HRMS.dbo.Employee_All_Report.SchoolName LIKE HRMS.dbo.Female.SchoolName INNER JOIN HRMS.dbo.Male on HRMS.dbo.Male.SchoolName LIKE HRMS.dbo.Employee_All_Report.SchoolName", cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

            }
        }
        private void simpleButton1_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter(" select distinct HRMS.dbo.Employee_All_Report.EMPID,HRMS.dbo.Employee_All_Report.FullName,HRMS.dbo.Employee_All_Report.Sex,HRMS.dbo.Employee_All_Report.Age,HRMS.dbo.Employee_All_Report.Employee_Email as Email,HRMS.dbo.Employee_All_Report.ELevel as [Education Level],HRMS.dbo.Employee_All_Report.Documents,HRMS.dbo.Employee_All_Report.Position,HRMS.dbo.Employee_All_Report.EDate as [Employment Date],HRMS.dbo.Employee_All_Report.SchoolName from HRMS.dbo.Employee_All_Report", cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
                
            }
        }
   private void dataGridView1_CellFormatting(object sender,System.Windows.Forms.DataGridViewCellFormattingEventArgs e)
    {
        // Set the background to red for negative values in the Balance column.
        if (dataGridView1.Columns[e.ColumnIndex].Name.Equals("Balance"))
        {
            Int32 intValue;
            if (Int32.TryParse((String)e.Value, out intValue) &&
                (intValue < 0))
            {
                e.CellStyle.BackColor = Color.Red;
                e.CellStyle.SelectionBackColor = Color.DarkRed;
            }
        }

        // Replace string values in the Priority column with images.
        if (dataGridView1.Columns[e.ColumnIndex].Name.Equals("Priority"))
        {
            // Ensure that the value is a string.
            String stringValue = e.Value as string;
            if (stringValue == null) return;

            // Set the cell ToolTip to the text value.
            DataGridViewCell cell = dataGridView1[e.ColumnIndex, e.RowIndex];
            cell.ToolTipText = stringValue;

            // Replace the string value with the image value.
            
           
            }
        }

   private void groupControl1_Paint(object sender, PaintEventArgs e)
   {

   }

   private void simpleButton2_Click(object sender, EventArgs e)
   {
       using (SqlConnection cn = new SqlConnection(con))
       {
           cn.Open();
           for (int i = 0; i < dataGridView1.Rows.Count; i++)
           {
               SqlCommand cmd = new SqlCommand("INSERT INTO School_Employee_Sex VALUES ('"+dataGridView1.Rows[i].Cells[0].Value.ToString()+"','"+dataGridView1.Rows[i].Cells[1].Value.ToString()+"','"+dataGridView1.Rows[i].Cells[2].Value.ToString()+"','"+DateTime.Now.ToShortDateString()+"','"+DateTime.Now.ToShortTimeString()+"')", cn);
               cmd.ExecuteNonQuery();
               MessageBox.Show("Report Saved Successfully!", "HRMS Application", MessageBoxButtons.OK, MessageBoxIcon.Information);
           }
           cn.Close();
       }
   }
    }
}
