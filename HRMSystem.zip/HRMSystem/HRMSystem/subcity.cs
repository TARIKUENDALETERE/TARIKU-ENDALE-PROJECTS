﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;
namespace HRMSystem
{
    public partial class subcity : DevExpress.XtraEditors.XtraForm
    {
        string oldText = string.Empty;
        string con = ConfigurationManager.ConnectionStrings["HRMS"].ToString();
        public subcity()
        {
            InitializeComponent();
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            if (sc.Text == "" & ci.Text == "")
            {
                MessageBox.Show("Please Fill Both Subcity Name and City to Add!", "HRMS Application", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                using (SqlConnection cn = new SqlConnection(con))
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO HRMS.dbo.KifleKetema VALUES('" + sc.Text + "','" + ci.Text + "','" + DateTime.Now.ToShortDateString() + "')", cn);
                    cmd.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("You added the Subcity Successfully!", "HRMS Application", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void simpleButton4_Click(object sender, EventArgs e)
        {
            using (SqlConnection cnn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select * from HRMS.dbo.Kifleketema WHERE HRMS.dbo.Kifleketema.KKName LIKE '" + search.Text + "'", cnn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                gridControl1.DataSource = dt;

            }
        }

        private void subcity_Load(object sender, EventArgs e)
        {
            using (SqlConnection cnn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select * from HRMS.dbo.Kifleketema", cnn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                gridControl1.DataSource = dt;

            }
            gridControl1.BackColor = Color.Aquamarine;
        }

        private void search_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection cnn = new SqlConnection(con))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select * from HRMS.dbo.Kifleketema WHERE HRMS.dbo.Kifleketema.KKName LIKE '" + search.Text + "'", cnn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                gridControl1.DataSource = dt;

            }
        }

        private void simpleButton3_Click(object sender, EventArgs e)
        {
            sc.Clear();
            ci.Clear();
        }
    }
}