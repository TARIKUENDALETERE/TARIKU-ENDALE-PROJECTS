﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Data.SqlClient;
using System.Configuration;
using AForge.Video;
using AForge.Video.DirectShow;
namespace HRMSystem
{
    public partial class Form2 : DevExpress.XtraEditors.XtraForm
    {
        string con = ConfigurationManager.ConnectionStrings["HRMS"].ToString();
        public Form2()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void addNewEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            employeeregistration er = new employeeregistration();
            er.Show();
        }

        private void dashboardViewer3_Load(object sender, EventArgs e)
        {

        }

        private void dashboardDesignerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dashboarddesigner dd = new dashboarddesigner();
            dd.Show();
        }

        private void addBanksToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void addChartsOfAccountsToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void incomeRegistrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            income ic = new income();
            ic.Show();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AddBankAccount adb = new AddBankAccount();
            adb.Show();
        }

        private void addChartsOfAccountsToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            ChartofAccounts ca = new ChartofAccounts();
            ca.Show();

        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void addCompanyBureauToolStripMenuItem_Click(object sender, EventArgs e)
        {
            company co = new company();
            co.Show();
        }

        private void addSubcityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            subcity sc = new subcity();
            sc.Show();
        }

        private void addSchoolToolStripMenuItem_Click(object sender, EventArgs e)
        {
            school sc = new school();
            sc.Show();
        }

        private void groupControl1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void overtimeConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OtEntry ot = new OtEntry();
            ot.Show();
        }

        private void reportDesignerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EmployeeReport er = new EmployeeReport();
            er.Show();
        }

        private void employeeDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EmployeeData ad = new EmployeeData();
            ad.Show();
        }

        private void schoolDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            schooldetail sd = new schooldetail();
            sd.Show();
        }

        private void employeeReportBasedSchoolConstraintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
        }

        }
    }
